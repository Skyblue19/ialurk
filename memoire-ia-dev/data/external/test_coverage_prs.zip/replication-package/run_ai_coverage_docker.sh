#!/bin/bash
# Run AI Agents coverage analysis inside Docker
#
# Usage: ./run_ai_coverage_docker.sh [ai_only|coauthor|human] [limit] [workers] [flags]
#
# Flags:
#   --resume    Keep existing data (append mode)
#   --quiet     Silent mode - only show progress every 40 min
#   --silent    No output at all (check with ./check_progress.sh)
#
# Examples:
#   ./run_ai_coverage_docker.sh coauthor              # Normal with full logs
#   ./run_ai_coverage_docker.sh coauthor 0 6 --quiet  # Progress every 40min
#   ./run_ai_coverage_docker.sh coauthor 0 6 --silent # No output (background)
#   ./run_ai_coverage_docker.sh human 0 6             # Run human PRs
#
# IMPORTANT: By default, this script CLEANS ALL CACHE before running!

TYPE="${1:-ai_only}"
LIMIT="${2:-}"
WORKERS="${3:-6}"
FLAG1="${4:-}"
FLAG2="${5:-}"

# Parse flags
RESUME_FLAG=""
QUIET_MODE=""
SILENT_MODE=""
for flag in "$FLAG1" "$FLAG2"; do
    case "$flag" in
        --resume) RESUME_FLAG="--resume" ;;
        --quiet) QUIET_MODE="1" ;;
        --silent) SILENT_MODE="1" ;;
    esac
done

# Log file for quiet/silent modes
LOG_FILE="coverage_analyzer/output/${TYPE}_execution.log"
PROGRESS_FILE="coverage_analyzer/output/${TYPE}_progress.txt"

echo "=========================================="
echo " AI Agents Coverage Analysis (Docker)"
echo "=========================================="
echo "Type: $TYPE"
echo "Limit: ${LIMIT:-all}"
echo "Workers: $WORKERS"
echo "Resume: $([ -z "$RESUME_FLAG" ] && echo 'No (CLEAN ALL DATA)' || echo 'Yes (keep existing)')"
echo "Mode: $([ -n "$SILENT_MODE" ] && echo 'SILENT' || ([ -n "$QUIET_MODE" ] && echo 'QUIET (40min intervals)' || echo 'Normal'))"
echo ""

if [ -n "$QUIET_MODE" ] || [ -n "$SILENT_MODE" ]; then
    echo "📝 Log file: $LOG_FILE"
    echo "📊 Check progress: ./check_progress.sh $TYPE"
    echo ""
fi

# Check GITHUB_TOKEN
if [ -z "$GITHUB_TOKEN" ]; then
    echo "❌ ERROR: GITHUB_TOKEN not set"
    echo "   Run: export GITHUB_TOKEN=your_token"
    exit 1
fi

# Check disk space (require at least 100GB free)
echo "[1/5] Checking disk space..."
AVAILABLE_GB=$(df -BG /home | tail -1 | awk '{print $4}' | tr -d 'G')
echo "   Available: ${AVAILABLE_GB}GB"
if [ "$AVAILABLE_GB" -lt 100 ]; then
    echo "⚠️  WARNING: Less than 100GB available!"
    echo "   Recommended: At least 100GB free for full analysis"
    echo ""
fi

# CLEAN ALL CACHE unless --resume is specified
if [ "$RESUME_FLAG" != "--resume" ]; then
    echo "[2/5] 🧹 CLEANING ALL PREVIOUS DATA (fresh run)..."
    
    # Clean host cache
    echo "   Removing ~/.cache/coverage_analyzer/repos..."
    rm -rf ~/.cache/coverage_analyzer/repos 2>/dev/null || sudo rm -rf ~/.cache/coverage_analyzer/repos 2>/dev/null || true
    
    echo "   Removing ~/.cache/coverage_analyzer/working..."
    rm -rf ~/.cache/coverage_analyzer/working 2>/dev/null || sudo rm -rf ~/.cache/coverage_analyzer/working 2>/dev/null || true
    
    # Clean Docker volume
    echo "   Cleaning Docker volume..."
    sudo rm -rf /var/lib/docker/volumes/coverage-cache-repos/_data/* 2>/dev/null || true
    
    # Clean output CSV
    OUTPUT_FILE="coverage_analyzer/output/${TYPE}_coverage_analysis.csv"
    if [ -f "$OUTPUT_FILE" ]; then
        echo "   Removing old output: $OUTPUT_FILE"
        rm -f "$OUTPUT_FILE"
    fi
    
    # Clean logs
    echo "   Cleaning logs..."
    rm -rf coverage_analyzer/output/logs/* 2>/dev/null || true
    
    echo "   ✅ Cache cleaned!"
else
    echo "[2/5] Keeping existing cache (--resume mode)"
fi

# Create fresh directories with correct permissions
echo "[3/5] Preparing directories..."
mkdir -p ~/.cache/coverage_analyzer/{repos,pip,working}
chmod -R 777 ~/.cache/coverage_analyzer 2>/dev/null || sudo chmod -R 777 ~/.cache/coverage_analyzer 2>/dev/null || true

# Build image if needed
echo "[4/5] Building Docker image..."
docker build -t coverage-analyzer . || exit 1

# Prepare command with cleanup fix (no --resume = clean CSV)
CMD="python -m ai_agents.run_coverage --type $TYPE --workers $WORKERS"
if [ -n "$LIMIT" ]; then
    CMD="$CMD --limit $LIMIT"
fi
if [ "$RESUME_FLAG" = "--resume" ]; then
    CMD="$CMD --resume"
fi

# Ensure output directory exists and is writable
mkdir -p "$(pwd)/coverage_analyzer/output"
chmod 777 "$(pwd)/coverage_analyzer/output" 2>/dev/null || true

echo "[5/5] Running coverage analysis..."
echo "Command: $CMD"
echo ""

# Output file for progress tracking
OUTPUT_FILE="coverage_analyzer/output/${TYPE}_coverage_analysis.csv"

# Function to show progress
show_progress() {
    local lines=0
    [ -f "$OUTPUT_FILE" ] && lines=$(wc -l < "$OUTPUT_FILE" 2>/dev/null || echo 0)
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Progress: $lines lines processed | Disk: $(df -h /home | tail -1 | awk '{print $4}') free"
}

# Save progress function for status file
save_progress() {
    {
        echo "Type: $TYPE"
        echo "Started: $(date)"
        echo "Log: $LOG_FILE"
        show_progress
    } > "$PROGRESS_FILE"
}

if [ -n "$SILENT_MODE" ]; then
    # SILENT MODE: Run in background, log to file
    echo "🔇 Running in SILENT mode..."
    echo "   Use: ./check_progress.sh $TYPE  (to check progress)"
    echo "   Use: tail -f $LOG_FILE          (to see logs)"
    echo ""
    
    save_progress
    
    docker run --rm \
        --name "coverage-ai-$TYPE" \
        -e GITHUB_TOKEN="$GITHUB_TOKEN" \
        -v "$(pwd)/ai_agents/output:/app/ai_agents/output:ro" \
        -v "$(pwd)/human/output:/app/human/output:ro" \
        -v "$(pwd)/coverage_analyzer/output:/workspace/coverage_analyzer/output" \
        -v ~/.cache/coverage_analyzer:/cache \
        coverage-analyzer \
        $CMD > "$LOG_FILE" 2>&1 &
    
    DOCKER_PID=$!
    echo "Container started (PID: $DOCKER_PID)"
    echo "Container name: coverage-ai-$TYPE"
    
    # Detach immediately
    disown $DOCKER_PID 2>/dev/null || true
    
    echo ""
    echo "To monitor:"
    echo "  ./check_progress.sh $TYPE"
    echo "  docker logs -f coverage-ai-$TYPE"
    echo "  tail -f $LOG_FILE"
    
    exit 0

elif [ -n "$QUIET_MODE" ]; then
    # QUIET MODE: Log to file, show progress every 40 minutes
    echo "🔕 Running in QUIET mode (updates every 40 min)..."
    echo ""
    
    save_progress
    
    docker run --rm \
        --name "coverage-ai-$TYPE" \
        -e GITHUB_TOKEN="$GITHUB_TOKEN" \
        -v "$(pwd)/ai_agents/output:/app/ai_agents/output:ro" \
        -v "$(pwd)/human/output:/app/human/output:ro" \
        -v "$(pwd)/coverage_analyzer/output:/workspace/coverage_analyzer/output" \
        -v ~/.cache/coverage_analyzer:/cache \
        coverage-analyzer \
        $CMD > "$LOG_FILE" 2>&1 &
    
    DOCKER_PID=$!
    
    # Monitor loop: show progress every 40 minutes
    INTERVAL=2400  # 40 minutes in seconds
    while kill -0 $DOCKER_PID 2>/dev/null; do
        sleep $INTERVAL
        if kill -0 $DOCKER_PID 2>/dev/null; then
            show_progress
            save_progress
        fi
    done
    
    wait $DOCKER_PID 2>/dev/null
    DOCKER_EXIT=$?
    
    echo ""
    echo "🏁 Execution finished!"
    show_progress

else
    # NORMAL MODE: Show all logs
    docker run --rm \
        --name "coverage-ai-$TYPE" \
        -e GITHUB_TOKEN="$GITHUB_TOKEN" \
        -v "$(pwd)/ai_agents/output:/app/ai_agents/output:ro" \
        -v "$(pwd)/human/output:/app/human/output:ro" \
        -v "$(pwd)/coverage_analyzer/output:/workspace/coverage_analyzer/output" \
        -v ~/.cache/coverage_analyzer:/cache \
        coverage-analyzer \
        $CMD
    
    DOCKER_EXIT=$?
fi

echo ""

# Fix permissions if output was created by root inside container
OUTPUT_FILE="coverage_analyzer/output/${TYPE}_coverage_analysis.csv"
if [ -f "$OUTPUT_FILE" ]; then
    sudo chown $(id -u):$(id -g) "$OUTPUT_FILE" 2>/dev/null || true
    chmod 644 "$OUTPUT_FILE" 2>/dev/null || true
fi

echo "=========================================="
if [ $DOCKER_EXIT -eq 0 ]; then
    if [ -f "$OUTPUT_FILE" ]; then
        echo "✅ SUCCESS!"
        echo "Output: $OUTPUT_FILE"
        echo "Lines: $(wc -l < "$OUTPUT_FILE")"
        echo ""
        echo "Disk space remaining: $(df -h /home | tail -1 | awk '{print $4}')"
    fi
else
    echo "❌ FAILED (exit code: $DOCKER_EXIT)"
    echo ""
    echo "Common issues:"
    echo "  - Disk space: $(df -h /home | tail -1 | awk '{print $4}') remaining"
    echo "  - Try with smaller limit: ./run_ai_coverage_docker.sh $TYPE 100"
    exit $DOCKER_EXIT
fi
echo "=========================================="

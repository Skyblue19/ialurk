# MD5 Checksums for Non-Regeneratable Data

These checksums verify the integrity of manually evaluated data (RQ2):

## RQ2 Human Evaluation Data
```
1799142f57ec7453686affff646c4b17  data/rq2_evaluation/evaluation_kit_participant_1_v3_rebalanced.csv
1cb932123547651de9ff41cff7fe5495  data/rq2_evaluation/evaluation_kit_participant_2_v3_rebalanced.csv
243eec87f87e21b1862c5d26ff030892  data/rq2_evaluation/evaluation_kit_participant_3_v3_rebalanced.csv
2c45d2dd8a456fee90849bf95a83b4cc  data/rq2_evaluation/golden_set_testfiles_v3.csv
```

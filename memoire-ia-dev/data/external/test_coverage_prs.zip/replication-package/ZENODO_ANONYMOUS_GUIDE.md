# Guia: Como Publicar Anonimamente no Zenodo

## ✅ Passo a Passo para Manter Anonimato

### 1. **Criar/Usar Conta Zenodo Neutra**
- Use email genérico (não institucional)
- OU use conta institucional, mas configure o registro como anônimo

### 2. **Preencher Metadados no Zenodo**

#### **Basic Information**
```
Upload type: Dataset
Title: Replication Package: Test Coverage of Code Changes in AI-Generated Pull Requests
Publication date: December 2024
Description: [Cole a descrição abaixo]
```

**Descrição (copiar e colar):**
```
This replication package contains all code, data, and analysis scripts for reproducing 
the results reported in the paper "Test Coverage of Code Changes in AI-Generated Pull 
Requests" submitted to MSR 2026 Mining Challenge.

The package includes:
- Source code for test detection and coverage analysis
- Pre-computed coverage data (2,314 PRs, ~204 hours computation time)
- Manual evaluation data from 3 independent evaluators (non-regeneratable)
- Statistical analysis notebooks reproducing all tables and figures in the paper

Data Source: AIDev dataset v2 (August 2025), DOI: 10.5281/zenodo.16919051

See README.md inside the package for detailed reproduction instructions.

NOTE: This upload is anonymized for double-blind peer review. Author information 
will be updated after paper acceptance.
```

#### **Creators** ⚠️ IMPORTANTE
```
Click "Add creator"
→ Select: "Person" (radio button)
→ Family name: Anonymous
→ Given names: [deixe em branco ou "Authors"]
→ Affiliations: [deixe em branco]
→ ORCID: [deixe em branco]
→ Click "Save"
```

**Resultado esperado:**
```
Creator: Anonymous
```

#### **Contributors** (opcional - deixar vazio)

#### **Keywords**
```
software testing
test coverage
AI coding agents
autonomous agents
pull requests
code quality
empirical software engineering
mining software repositories
```

#### **Related Identifiers**
```
Click "Add related identifier"

1. Identifier: https://doi.org/10.5281/zenodo.16919051
   Relation: is supplement to
   Resource type: Dataset

2. Identifier: https://arxiv.org/abs/2507.15003
   Relation: cites
   Resource type: Publication - Article

3. [Após submeter o paper, adicionar o arXiv preprint se houver]
```

#### **License**
```
Creative Commons Attribution 4.0 International (CC BY 4.0)
```

#### **Version**
```
1.0
```

#### **Language**
```
English
```

#### **Access**
```
Access right: Open Access
```

### 3. **Upload do Arquivo**
```
Arraste: msr-2026-replication-package.zip
```

### 4. **Reserve DOI (ANTES de publicar)**
```
Click "Save" (salvar rascunho)
→ Você verá o DOI: 10.5281/zenodo.18018890
→ Copie este DOI para usar no paper
```

### 5. **Publicar**
```
Click "Publish"
⚠️ AVISO: Após publicar, não pode deletar (apenas criar nova versão)
```

## 🔍 Verificação de Anonimato

Antes de publicar, verifique:

✅ Creator = "Anonymous" (sem nomes reais)  
✅ Description menciona "anonymized for review"  
✅ Nenhum email institucional visível  
✅ Nenhuma URL para repositório pessoal  
✅ Arquivo ZIP não contém .git/ (histórico de commits)

## 📝 Após Aceitação do Paper

1. **Acesse** o registro no Zenodo
2. **Click** em "Edit" (ou "New version")
3. **Atualize** os creators com nomes/ORCIDs reais:
   ```
   Creator 1: [Seu Nome Completo]
   ORCID: [seu ORCID]
   Affiliation: [sua instituição]
   
   Creator 2: [Coautor]
   ...
   ```
4. **Atualize** a descrição (remova "anonymized for review")
5. **Adicione** o DOI do paper publicado em "Related Identifiers"
6. **Publique** a nova versão

## ⚠️ Notas Importantes

- **O Zenodo aceita "Anonymous" como creator** - é prática comum para peer review
- Após publicar, o DOI é **permanente** e **imutável**
- Você pode criar **novas versões** que compartilham o mesmo concept DOI
- O registro **não revela** seu endereço IP ou metadados de upload
- Se usar conta institucional, o registro **não mostra** sua associação

## 📧 Suporte

Se tiver problemas:
- Email Zenodo: info@zenodo.org
- Mencione: "Anonymous upload for double-blind review (MSR 2026)"

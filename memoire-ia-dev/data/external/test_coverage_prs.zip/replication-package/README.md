# Replication Package: Test Coverage of Code Changes in AI-Generated Pull Requests

This replication package accompanies the paper **"Test Coverage of Code Changes in AI-Generated Pull Requests"** submitted to MSR 2026.

## Overview

This study analyzes test coverage and assertion quality across three authorship types:
- **AI-Only**: 100% autonomous agent commits (N=474 PRs)
- **Coauthor**: Human-AI collaboration (N=1,559 PRs)
- **Human**: Baseline human-authored PRs (N=281 PRs)

**Key Findings:**
- AI-Only PRs achieve 19.96% mean diff-coverage vs. 13.09% for Human PRs (p<0.0001)
- 80.4% of AI-Only PRs include measurable test coverage vs. 66.2% for Human PRs
- Assertion quality is comparable across all groups (>90% L3+L4 assertions)

## Repository Structure

```
replication-package/
├── README.md                    # This file
├── requirements.txt             # Python dependencies
│
├── scripts/                     # Source code
│   ├── ai_agents/               # PR classification and test detection
│   │   ├── config.py
│   │   ├── extract_ai_prs.py    # Classify PRs as AI-Only/Coauthor
│   │   ├── detect_tests.py      # Detect test files via GitHub API
│   │   └── run_coverage.py      # Orchestrate coverage analysis
│   ├── coverage_analyzer/       # Diff-coverage measurement
│   │   ├── config.py
│   │   ├── main.py              # Entry point
│   │   ├── diff_coverage.py     # Core coverage algorithm
│   │   ├── pr_processor.py      # Process individual PRs
│   │   ├── git_manager.py       # Git operations
│   │   ├── coverage_runner.py   # Run pytest with coverage
│   │   └── failure_diagnosis.py # Diagnose test failures
│   ├── human/                   # Human PR processing
│   │   ├── config.py
│   │   ├── main.py
│   │   ├── github_api.py
│   │   └── utils.py
│   └── shared/                  # Shared utilities
│       ├── __init__.py
│       ├── config.py
│       ├── github_api.py
│       └── utils.py
│
├── analysis/                    # Jupyter notebooks for analysis
│   ├── coauthorship_analysis.ipynb     # Extract Human PRs from AIDev
│   ├── 03_rq1_coverage_analysis.ipynb  # RQ1: Coverage statistics
│   ├── 04_rq2_assertion_quality.ipynb  # RQ2: Sample generation
│   └── 05_rq2_results_analysis.ipynb   # RQ2: Inter-rater reliability
│
├── data/                        # Data files
│   ├── test_detection/          # Input: PRs with test files (~10h to regenerate)
│   │   ├── ai_only_prs_test_detection.csv   (537 PRs with test files)
│   │   ├── coauthor_prs_test_detection.csv  (1,765 PRs with test files)
│   │   └── human_prs_test_detection.csv     (358 PRs with test files)
│   ├── rq1_coverage/            # Coverage analysis results (~204h to regenerate)
│   │   ├── ai_only_coverage_analysis.csv   (474 PRs, 735 test observations)
│   │   ├── coauthor_coverage_analysis.csv  (1,559 PRs, 2,416 test observations)
│   │   └── human_coverage_analysis.csv     (281 PRs, 525 test observations)
│   ├── rq2_evaluation/          # Human evaluation data (NON-REGENERATABLE)
│   │   ├── evaluation_kit_participant_1_v3_rebalanced.csv
│   │   ├── evaluation_kit_participant_2_v3_rebalanced.csv
│   │   ├── evaluation_kit_participant_3_v3_rebalanced.csv
│   │   └── golden_set_testfiles_v3.csv     (30 items for Fleiss' κ)
│   └── rq2_assertions/          # Test diffs for assertion analysis
│       ├── rq2_ai_only_assertions.csv
│       ├── rq2_coauthor_assertions.csv
│       └── rq2_human_assertions.csv
│
├── results/                     # Final results (reported in paper)
│   ├── rq1_coverage_statistics.csv      # Table 2: Coverage by authorship
│   ├── rq1_summary_statistics.csv       # Aggregated statistics
│   ├── methodology_sample_summary.csv   # Table 1: Sample sizes
│   ├── rq2_consolidated_classifications.csv  # All 255 classifications
│   ├── rq2_crosstab.csv                 # Table 3: Assertion distribution
│   ├── rq2_golden_set_analysis.csv      # Fleiss' κ = 0.586
│   ├── rq2_summary_statistics.csv       # RQ2 summary
│   ├── latex_coverage_table.tex         # LaTeX for Table 2
│   ├── rq2_table.tex                    # LaTeX for Table 3
│   └── figures/
│       ├── fig1_coverage_distribution_kde.png
│       ├── fig2_coverage_boxplot.png
│       ├── fig3_coverage_categories.png    # Figure 1 in paper
│       ├── fig4_agent_coverage.png
│       └── rq2_assertion_distribution.png
│
└── paper/
    ├── msr-coverage.tex         # Paper source
    └── references.bib           # Bibliography
```

## Prerequisites

- **Python 3.9+**
- **Docker** (for coverage analysis execution)
- **GitHub API Token** (for test detection via API)
- **AIDev Dataset v2** (August 2025) from HuggingFace

## Installation

```bash
# Clone the repository
git clone https://github.com/anonymous/msr-coverage-replication.git
cd msr-coverage-replication

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/macOS
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt
```

## Data Source: AIDev Dataset

This study uses the **AIDev dataset version 2 (August 2025)** available at:
- **DOI**: https://doi.org/10.5281/zenodo.16919051
- **HuggingFace**: https://huggingface.co/datasets/hao-li/AIDev

The dataset is licensed under CC BY 4.0.

**Citation:**
```bibtex
@article{li2025aidev,
  title={The Rise of AI Teammates in Software Engineering (SE) 3.0},
  author={Li, Hao and Zhang, Haoxiang and Hassan, Ahmed E.},
  journal={arXiv preprint arXiv:2507.15003},
  year={2025},
  doi={10.5281/zenodo.16919051}
}
```

To download and query the dataset:
```python
import duckdb

# Connect to AIDev parquet files
con = duckdb.connect()
con.execute("INSTALL httpfs; LOAD httpfs;")

# Query Python repositories with AI PRs
query = """
SELECT * FROM 'hf://datasets/hao-li/AIDev/agentic_pull_request/*.parquet'
WHERE language = 'Python'
"""
df = con.execute(query).fetchdf()
```

## Reproducing Results

### RQ1: Test Coverage Analysis

The coverage data is pre-computed in `data/rq1_coverage/` (~204 hours to regenerate).

To reproduce the statistical analysis:
```bash
cd analysis
jupyter notebook 03_rq1_coverage_analysis.ipynb
```

To regenerate coverage data from scratch (requires Docker + GitHub token):
```bash
# 1. Extract AI PRs from AIDev
cd scripts/ai_agents
python extract_ai_prs.py

# 2. Detect test files via GitHub API (~10 hours, rate-limited)
export GITHUB_TOKEN=your_token_here
python detect_tests.py
# Output: data/test_detection/*.csv

# 3. Run coverage analysis (using test_detection CSVs as input)
# AI-Only: ~48 hours
python run_coverage.py --input ../../data/test_detection/ai_only_prs_test_detection.csv \
                       --agent-type ai-only \
                       --output ../../data/rq1_coverage/ai_only_coverage_analysis.csv

# Coauthor: ~120 hours
python run_coverage.py --input ../../data/test_detection/coauthor_prs_test_detection.csv \
                       --agent-type coauthor \
                       --output ../../data/rq1_coverage/coauthor_coverage_analysis.csv

# Human: ~36 hours
cd ../coverage_analyzer
python main.py --input ../../data/test_detection/human_prs_test_detection.csv \
               --output ../../data/rq1_coverage/human_coverage_analysis.csv
```

### RQ2: Assertion Quality

The human evaluation data in `data/rq2_evaluation/` is **non-regeneratable** (manual work by 3 evaluators).

To reproduce the statistical analysis:
```bash
cd analysis
jupyter notebook 05_rq2_results_analysis.ipynb
```

To generate new evaluation kits (for new samples):
```bash
jupyter notebook 04_rq2_assertion_quality.ipynb
```

## Mapping Results to Paper

| Paper Element | Data Source |
|---------------|-------------|
| Table 1: Sample sizes | `results/methodology_sample_summary.csv` |
| Table 2: Coverage statistics | `results/rq1_coverage_statistics.csv` |
| Table 3: Assertion distribution | `results/rq2_crosstab.csv` |
| Figure 1: Coverage categories | `results/figures/fig3_coverage_categories.png` |
| Fleiss' κ = 0.586 | `results/rq2_golden_set_analysis.csv` |
| Kruskal-Wallis H=39.05 | `analysis/03_rq1_coverage_analysis.ipynb` |
| Chi-square χ²=12.68 | `analysis/05_rq2_results_analysis.ipynb` |

## Execution Time Estimates

| Component | Estimated Time | Notes |
|-----------|---------------|-------|
| Extract AI PRs | ~5 minutes | DuckDB queries |
| Detect tests (all PRs) | ~10 hours | GitHub API rate-limited |
| Coverage (AI-Only) | ~48 hours | Docker + pytest |
| Coverage (Coauthor) | ~120 hours | Docker + pytest |
| Coverage (Human) | ~36 hours | Docker + pytest |
| RQ1 Analysis | ~10 minutes | Statistical tests |
| RQ2 Evaluation | **Manual** | 3 evaluators × 105 items |
| RQ2 Analysis | ~5 minutes | Statistical tests |
| **Total** | **~218 hours + manual** | |

## File Checksums (Integrity Verification)

Critical non-regeneratable files (RQ2 human evaluation data):

```bash
# MD5 checksums - see CHECKSUMS.md for full list
1799142f57ec7453686affff646c4b17  data/rq2_evaluation/evaluation_kit_participant_1_v3_rebalanced.csv
1cb932123547651de9ff41cff7fe5495  data/rq2_evaluation/evaluation_kit_participant_2_v3_rebalanced.csv
243eec87f87e21b1862c5d26ff030892  data/rq2_evaluation/evaluation_kit_participant_3_v3_rebalanced.csv
2c45d2dd8a456fee90849bf95a83b4cc  data/rq2_evaluation/golden_set_testfiles_v3.csv
```

To verify:
```bash
cd replication-package
md5sum -c CHECKSUMS.md
```

## License

- **Code**: MIT License
- **Data**: CC BY 4.0 (following AIDev dataset license)
- **Paper**: Copyright reserved

## Citation

If you use this replication package, please cite:

```bibtex
@inproceedings{anonymous2026testcoverage,
  title={Test Coverage of Code Changes in AI-Generated Pull Requests},
  author={Anonymous},
  booktitle={Proceedings of the 23rd International Conference on Mining Software Repositories (MSR '26)},
  year={2026},
  publisher={ACM}
}

@misc{anonymous2024replication,
  author    = {{Anonymous}},
  title     = {{Replication Package: Test Coverage of Code Changes in AI-Generated Pull Requests}},
  year      = {2024},
  publisher = {Zenodo},
  doi       = {10.5281/zenodo.18018890},
  url       = {https://doi.org/10.5281/zenodo.18018890}
}
```

## Contact

For questions about this replication package, please open an issue on the repository.

"""Configuration for AI Agents PR GitHub API Analyzer."""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add parent to path for shared imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Load environment variables
load_dotenv()

# GitHub API Configuration
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# Paths
PROJECT_ROOT = Path(__file__).parent
MSR_ROOT = PROJECT_ROOT.parent
OUTPUT_DIR = PROJECT_ROOT / "output"

# Input CSVs (from extract_ai_prs.py)
AI_ONLY_INPUT_CSV = OUTPUT_DIR / "ai_only_for_github_api.csv"
COAUTHOR_INPUT_CSV = OUTPUT_DIR / "coauthor_for_github_api.csv"
ALL_AI_INPUT_CSV = OUTPUT_DIR / "all_ai_for_github_api.csv"

# Output files - DIFFERENT names to not overwrite human data
AI_ONLY_OUTPUT_CSV = OUTPUT_DIR / "ai_only_prs_test_detection.csv"
COAUTHOR_OUTPUT_CSV = OUTPUT_DIR / "coauthor_prs_test_detection.csv"
ALL_AI_OUTPUT_CSV = OUTPUT_DIR / "all_ai_prs_test_detection.csv"

ERROR_LOG = OUTPUT_DIR / "errors.log"
PROGRESS_LOG = OUTPUT_DIR / "progress.log"

# Test frameworks to detect
TEST_FRAMEWORKS = {
    "pytest": [r"import pytest", r"from pytest", r"@pytest\.", r"pytest\."],
    "unittest": [r"import unittest", r"from unittest", r"TestCase"],
    "mock": [r"import mock", r"from mock", r"from unittest\.mock"],
    "hypothesis": [r"import hypothesis", r"from hypothesis", r"@hypothesis\."],
    "nose": [r"import nose", r"from nose"],
}

# Batch Processing
BATCH_SIZE = 50  # Process 50 PRs before saving checkpoint
CHECKPOINT_INTERVAL = 100  # Save progress every 100 PRs

# Create output directory if it doesn't exist
OUTPUT_DIR.mkdir(exist_ok=True)

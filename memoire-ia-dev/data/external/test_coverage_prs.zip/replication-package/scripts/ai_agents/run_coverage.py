#!/usr/bin/env python3
"""
Run coverage analysis on AI Agent PRs.

This script adapts the output from detect_tests.py to run through coverage_analyzer.
It handles:
- Filtering for PRs with tests (status=success)
- Generating pr_id from owner/repo/pr_number
- Mapping column names to coverage_analyzer format
- Running coverage analysis with configurable workers
"""

import argparse
import csv
import logging
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

# Add parent directory for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from ai_agents.config import (
    AI_ONLY_OUTPUT_CSV,
    COAUTHOR_OUTPUT_CSV,
    OUTPUT_DIR as AI_AGENTS_OUTPUT_DIR,
)
from coverage_analyzer.config import (
    OUTPUT_DIR as COVERAGE_OUTPUT_DIR,
    DEFAULT_WORKERS,
)
from coverage_analyzer.main import process_pr_worker, setup_logging

logger = logging.getLogger(__name__)

# Output file names - use /workspace paths when in Docker, otherwise local paths
def get_output_paths():
    """Get correct paths based on environment (Docker vs local)."""
    # Check if running in Docker by looking for /workspace
    if Path("/workspace").exists() and Path("/app").exists():
        # Inside Docker
        ai_input_dir = Path("/app/ai_agents/output")
        human_input_dir = Path("/app/human/output")
        output_dir = Path("/workspace/coverage_analyzer/output")
    else:
        # Local execution
        ai_input_dir = AI_AGENTS_OUTPUT_DIR
        human_input_dir = Path(__file__).parent.parent / "human" / "output"
        output_dir = COVERAGE_OUTPUT_DIR
    
    return {
        "ai_only_input": ai_input_dir / "ai_only_prs_test_detection.csv",
        "coauthor_input": ai_input_dir / "coauthor_prs_test_detection.csv",
        "human_input": human_input_dir / "human_prs_test_detection.csv",
        "ai_only_output": output_dir / "ai_only_coverage_analysis.csv",
        "coauthor_output": output_dir / "coauthor_coverage_analysis.csv",
        "human_output": output_dir / "human_coverage_analysis.csv",
    }

# Legacy variables for compatibility
AI_ONLY_COVERAGE_OUTPUT = COVERAGE_OUTPUT_DIR / "ai_only_coverage_analysis.csv"
COAUTHOR_COVERAGE_OUTPUT = COVERAGE_OUTPUT_DIR / "coauthor_coverage_analysis.csv"


def load_and_prepare_prs(input_csv: Path, limit: int = None) -> list:
    """
    Load PRs from detect_tests output and prepare for coverage_analyzer.
    
    Args:
        input_csv: Path to detect_tests output CSV.
        limit: Optional limit on number of PRs.
        
    Returns:
        List of PR dictionaries ready for coverage_analyzer.
    """
    prs = []
    
    with open(input_csv, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Only process PRs with detected tests
            if row.get("status") != "success":
                continue
            
            # Generate pr_id from owner_repo_pr_number
            owner = row.get("owner", "")
            repo = row.get("repo", "")
            pr_number = row.get("pr_number", "")
            pr_id = f"{owner}_{repo}_{pr_number}"
            
            # Map to coverage_analyzer format
            pr = {
                "pr_id": pr_id,
                "pr_number": pr_number,
                "repo_owner": owner,  # coverage_analyzer also accepts 'owner'
                "repo_name": repo,    # coverage_analyzer also accepts 'repo'
                "html_url": row.get("html_url", ""),
                "agent": row.get("agent", ""),
                "authorship_type": row.get("authorship_type", ""),
                # Preserve other useful columns
                "test_files_modified": row.get("test_files_modified", ""),
                "test_frameworks": row.get("test_frameworks", ""),
                "python_files_modified": row.get("python_files_modified", ""),
            }
            prs.append(pr)
    
    logger.info(f"Loaded {len(prs)} PRs with tests from {input_csv}")
    
    if limit:
        prs = prs[:limit]
        logger.info(f"Limited to {len(prs)} PRs")
    
    return prs


def run_coverage_analysis(
    prs: list,
    output_csv: Path,
    workers: int = DEFAULT_WORKERS,
    use_docker: bool = False,
    resume: bool = False,
) -> dict:
    """
    Run coverage analysis on a list of PRs.
    
    Args:
        prs: List of PR dictionaries.
        output_csv: Path to output CSV.
        workers: Number of parallel workers.
        use_docker: Whether to use Docker execution.
        resume: If False, will delete existing output CSV to start fresh.
        
    Returns:
        Dictionary with summary statistics.
    """
    stats = {
        "total": len(prs),
        "successful": 0,
        "partial": 0,
        "failed": 0,
        "no_test_files": 0,
    }
    
    start_time = time.time()
    
    # Ensure output directory exists
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    
    # Clean output CSV if not resuming
    if not resume and output_csv.exists():
        logger.info(f"🧹 Cleaning existing output CSV (resume=False): {output_csv}")
        output_csv.unlink()
        logger.info(f"✅ Removed: {output_csv}")
    
    logger.info(f"Starting coverage analysis for {len(prs)} PRs with {workers} workers")
    logger.info(f"Output: {output_csv}")
    logger.info(f"Resume: {resume}")
    
    try:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(
                    process_pr_worker,
                    pr,
                    None,  # input_csv_path not used
                    output_csv.parent,
                    use_docker,
                    output_csv,  # Pass the output CSV path
                ): pr
                for pr in prs
            }
            
            with tqdm(total=len(prs), desc="Analyzing PRs") as pbar:
                for future in as_completed(futures):
                    pr = futures[future]
                    try:
                        result = future.result()
                        status = result.get("status", "unknown")
                        
                        if status == "success":
                            stats["successful"] += 1
                        elif status == "partial":
                            stats["partial"] += 1
                        elif status == "no_test_files":
                            stats["no_test_files"] += 1
                        else:
                            stats["failed"] += 1
                            
                    except Exception as e:
                        logger.error(f"Worker exception for PR {pr.get('pr_id')}: {e}")
                        stats["failed"] += 1
                    
                    pbar.update(1)
                    
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        raise
    
    stats["elapsed_seconds"] = time.time() - start_time
    stats["elapsed_minutes"] = stats["elapsed_seconds"] / 60
    
    return stats


def print_summary(stats: dict, authorship_type: str):
    """Print summary statistics."""
    print("\n" + "=" * 60)
    print(f" COVERAGE ANALYSIS SUMMARY - {authorship_type.upper()}")
    print("=" * 60)
    print(f"  Total PRs processed: {stats['total']}")
    print(f"  ✅ Successful: {stats['successful']}")
    print(f"  ⚠️  Partial: {stats['partial']}")
    print(f"  ❌ Failed: {stats['failed']}")
    print(f"  ○  No test files: {stats['no_test_files']}")
    print(f"  ⏱️  Time: {stats['elapsed_minutes']:.1f} minutes")
    print("=" * 60 + "\n")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Run coverage analysis on AI Agent PRs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Test with 20 AI-Only PRs
  python -m ai_agents.run_coverage --type ai_only --limit 20

  # Run all AI-Only PRs with 6 workers
  python -m ai_agents.run_coverage --type ai_only --workers 6

  # Run all Coauthor PRs
  python -m ai_agents.run_coverage --type coauthor --workers 6

  # Run Human PRs
  python -m ai_agents.run_coverage --type human --workers 6

  # Run all types (ai_only, coauthor, and human)
  python -m ai_agents.run_coverage --type all --workers 6
        """,
    )
    
    parser.add_argument(
        "--type",
        choices=["ai_only", "coauthor", "human", "all"],
        default="ai_only",
        help="Which PR type to process (default: ai_only)",
    )
    
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Limit number of PRs to process (for testing)",
    )
    
    parser.add_argument(
        "--workers",
        type=int,
        default=6,
        help="Number of parallel workers (default: 6)",
    )
    
    parser.add_argument(
        "--use-docker",
        action="store_true",
        help="Use Docker for test execution (experimental)",
    )
    
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be processed without running",
    )

    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume from previous run (append to existing CSV instead of replacing)",
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging()
    
    print("\n" + "=" * 60)
    print(" AI Agent PR Coverage Analysis")
    print("=" * 60)
    
    # Check GitHub token
    if not os.getenv("GITHUB_TOKEN"):
        print("❌ ERROR: GITHUB_TOKEN not set")
        sys.exit(1)
    
    # Get correct paths for environment
    paths = get_output_paths()
    print(f"   Input dir: {paths['ai_only_input'].parent}")
    print(f"   Output dir: {paths['ai_only_output'].parent}")
    
    # Process based on type
    if args.type in ["ai_only", "all"]:
        input_csv = paths["ai_only_input"]
        output_csv = paths["ai_only_output"]
        
        if input_csv.exists():
            print(f"\n📂 Loading AI-Only PRs from: {input_csv}")
            prs = load_and_prepare_prs(input_csv, args.limit)
            
            if args.dry_run:
                print(f"   [DRY-RUN] Would process {len(prs)} PRs")
                for pr in prs[:5]:
                    print(f"     - PR#{pr['pr_number']} ({pr['agent']}): {pr['repo_owner']}/{pr['repo_name']}")
                if len(prs) > 5:
                    print(f"     ... and {len(prs) - 5} more")
            else:
                stats = run_coverage_analysis(
                    prs,
                    output_csv,
                    workers=args.workers,
                    use_docker=args.use_docker,
                    resume=args.resume,
                )
                print_summary(stats, "ai_only")
        else:
            print(f"⚠️  AI-Only input not found: {input_csv}")
    
    if args.type in ["coauthor", "all"]:
        input_csv = paths["coauthor_input"]
        output_csv = paths["coauthor_output"]
        
        if input_csv.exists():
            print(f"\n📂 Loading Coauthor PRs from: {input_csv}")
            prs = load_and_prepare_prs(input_csv, args.limit)
            
            if args.dry_run:
                print(f"   [DRY-RUN] Would process {len(prs)} PRs")
                for pr in prs[:5]:
                    print(f"     - PR#{pr['pr_number']} ({pr['agent']}): {pr['repo_owner']}/{pr['repo_name']}")
                if len(prs) > 5:
                    print(f"     ... and {len(prs) - 5} more")
            else:
                stats = run_coverage_analysis(
                    prs,
                    output_csv,
                    workers=args.workers,
                    use_docker=args.use_docker,
                    resume=args.resume,
                )
                print_summary(stats, "coauthor")
        else:
            print(f"⚠️  Coauthor input not found: {input_csv}")
    
    if args.type in ["human", "all"]:
        input_csv = paths["human_input"]
        output_csv = paths["human_output"]
        
        if input_csv.exists():
            print(f"\n📂 Loading Human PRs from: {input_csv}")
            prs = load_and_prepare_prs(input_csv, args.limit)
            
            if args.dry_run:
                print(f"   [DRY-RUN] Would process {len(prs)} PRs")
                for pr in prs[:5]:
                    print(f"     - PR#{pr['pr_number']}: {pr['repo_owner']}/{pr['repo_name']}")
                if len(prs) > 5:
                    print(f"     ... and {len(prs) - 5} more")
            else:
                stats = run_coverage_analysis(
                    prs,
                    output_csv,
                    workers=args.workers,
                    use_docker=args.use_docker,
                    resume=args.resume,
                )
                print_summary(stats, "human")
        else:
            print(f"⚠️  Human input not found: {input_csv}")
    
    print("\n✅ Done!\n")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Extract AI Agent PRs (AI-Only and Coauthor) from AIDev dataset.
Generates CSV files compatible with the human/ module for GitHub API test detection.
"""

import duckdb
import pandas as pd
from pathlib import Path

# Output directory
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

# AIDev dataset paths
DATASET_BASE = "hf://datasets/hao-li/AIDev"
PULL_REQUEST = f"{DATASET_BASE}/pull_request.parquet"
PR_COMMITS = f"{DATASET_BASE}/pr_commits.parquet"
REPOSITORY = f"{DATASET_BASE}/repository.parquet"


def classify_author_type(author: str) -> str:
    """Classify commit author as bot or human."""
    if author is None:
        return "unknown"
    author_lower = author.lower()
    
    # Bot patterns
    if "[bot]" in author_lower:
        return "bot"
    if author_lower in ["copilot", "github copilot"]:
        return "bot"
    if "cursor" in author_lower and "agent" in author_lower:
        return "bot"
    if "devin" in author_lower:
        return "bot"
    if author_lower == "cursoragent":
        return "bot"
    
    return "human"


def extract_ai_prs_with_classification():
    """
    Extract all AI Agent PRs from Python repos and classify as AI-Only or Coauthor.
    
    Classification rules:
    - AI-Only: ALL commits in the PR are from bot/agent authors
    - Coauthor: At least one commit from a human author
    """
    print("=" * 80)
    print(" Extracting AI Agent PRs with Authorship Classification")
    print("=" * 80)
    
    # Step 1: Get all AI PRs from Python repos
    print("\n[1/4] Fetching AI PRs from Python repositories...")
    
    query_prs = """
    SELECT 
        pr.id as pr_id,
        pr.number as pr_number,
        pr.agent,
        pr.state as pr_state,
        pr.merged_at,
        pr.html_url,
        pr.repo_url
    FROM read_parquet($pr_path) pr
    JOIN read_parquet($repo_path) r ON pr.repo_url = r.url
    WHERE r.language = 'Python'
      AND pr.agent IS NOT NULL
    """
    
    prs_df = duckdb.execute(query_prs, {
        "pr_path": PULL_REQUEST,
        "repo_path": REPOSITORY
    }).fetchdf()
    
    print(f"   Found {len(prs_df)} AI PRs in Python repos")
    
    # Step 2: Get all commits for these PRs
    print("\n[2/4] Fetching commits for all PRs...")
    
    pr_ids = prs_df['pr_id'].tolist()
    
    # Query commits in batches to avoid memory issues
    query_commits = """
    SELECT 
        pr_id,
        author,
        committer
    FROM read_parquet($commits_path)
    WHERE pr_id IN (SELECT UNNEST($pr_ids))
    """
    
    commits_df = duckdb.execute(query_commits, {
        "commits_path": PR_COMMITS,
        "pr_ids": pr_ids
    }).fetchdf()
    
    print(f"   Found {len(commits_df)} commits across all PRs")
    
    # Step 3: Classify each commit author
    print("\n[3/4] Classifying commit authors...")
    
    commits_df['author_type'] = commits_df['author'].apply(classify_author_type)
    
    # Aggregate by PR
    pr_author_stats = commits_df.groupby('pr_id').agg({
        'author_type': lambda x: list(x)
    }).reset_index()
    
    def classify_pr(author_types):
        """Classify PR based on commit author types.
        
        Note: All PRs in this dataset are AI Agent PRs (from AIDev).
        - ai_only: ALL commits from bot/agent authors (truly autonomous)
        - coauthor: Any human commits (human used AI tools to help write code)
        
        We classify 'human_only' as 'coauthor' because the PR is in the 
        AI Agent dataset, meaning AI tools were used even if commits are human-authored.
        This is common for tools like Codex where humans commit AI-generated code.
        """
        if all(t == 'bot' for t in author_types):
            return 'ai_only'
        else:
            # Any human involvement = coauthor (AI assisted but human commits)
            return 'coauthor'
    
    pr_author_stats['authorship_type'] = pr_author_stats['author_type'].apply(classify_pr)
    pr_author_stats['commit_count'] = pr_author_stats['author_type'].apply(len)
    pr_author_stats['bot_commits'] = pr_author_stats['author_type'].apply(lambda x: sum(1 for t in x if t == 'bot'))
    pr_author_stats['human_commits'] = pr_author_stats['author_type'].apply(lambda x: sum(1 for t in x if t == 'human'))
    
    # Step 4: Merge with PR data
    print("\n[4/4] Merging and generating output files...")
    
    result_df = prs_df.merge(
        pr_author_stats[['pr_id', 'authorship_type', 'commit_count', 'bot_commits', 'human_commits']],
        on='pr_id',
        how='left'
    )
    
    # Parse repo owner and name from URL
    result_df['repo_owner'] = result_df['repo_url'].apply(lambda x: x.split('/')[-2] if x else None)
    result_df['repo_name'] = result_df['repo_url'].apply(lambda x: x.split('/')[-1] if x else None)
    
    # Determine if merged
    result_df['pr_merged'] = result_df['merged_at'].notna()
    
    # Fill NaN authorship (PRs without commits in pr_commits table)
    result_df['authorship_type'] = result_df['authorship_type'].fillna('unknown')
    
    # Summary
    print("\n" + "=" * 80)
    print(" CLASSIFICATION SUMMARY")
    print("=" * 80)
    
    summary = result_df.groupby(['agent', 'authorship_type']).size().unstack(fill_value=0)
    print(f"\n{summary}")
    
    totals = result_df['authorship_type'].value_counts()
    print(f"\nTotal by authorship type:")
    for auth_type, count in totals.items():
        print(f"  {auth_type}: {count}")
    
    # Split into AI-Only and Coauthor
    ai_only_df = result_df[result_df['authorship_type'] == 'ai_only'].copy()
    coauthor_df = result_df[result_df['authorship_type'] == 'coauthor'].copy()
    
    print(f"\nAI-Only PRs: {len(ai_only_df)}")
    print(f"Coauthor PRs: {len(coauthor_df)}")
    
    # Select columns for output (compatible with human/ module)
    output_columns = [
        'pr_id', 'pr_number', 'repo_owner', 'repo_name', 'html_url',
        'agent', 'authorship_type', 'pr_state', 'pr_merged',
        'commit_count', 'bot_commits', 'human_commits'
    ]
    
    # Save AI-Only PRs
    ai_only_output = ai_only_df[output_columns]
    ai_only_path = OUTPUT_DIR / "ai_only_prs.csv"
    ai_only_output.to_csv(ai_only_path, index=False)
    print(f"\n✓ Saved: {ai_only_path}")
    
    # Save Coauthor PRs
    coauthor_output = coauthor_df[output_columns]
    coauthor_path = OUTPUT_DIR / "coauthor_prs.csv"
    coauthor_output.to_csv(coauthor_path, index=False)
    print(f"✓ Saved: {coauthor_path}")
    
    # Save combined for reference
    combined_output = result_df[output_columns]
    combined_path = OUTPUT_DIR / "all_ai_prs_classified.csv"
    combined_output.to_csv(combined_path, index=False)
    print(f"✓ Saved: {combined_path}")
    
    # Breakdown by agent
    print("\n" + "=" * 80)
    print(" BREAKDOWN BY AGENT")
    print("=" * 80)
    
    for agent in result_df['agent'].unique():
        agent_df = result_df[result_df['agent'] == agent]
        ai_only = len(agent_df[agent_df['authorship_type'] == 'ai_only'])
        coauthor = len(agent_df[agent_df['authorship_type'] == 'coauthor'])
        merged = len(agent_df[agent_df['pr_merged']])
        print(f"\n{agent}:")
        print(f"  Total: {len(agent_df)}")
        print(f"  AI-Only: {ai_only} ({100*ai_only/len(agent_df):.1f}%)")
        print(f"  Coauthor: {coauthor} ({100*coauthor/len(agent_df):.1f}%)")
        print(f"  Merged: {merged} ({100*merged/len(agent_df):.1f}%)")
    
    return ai_only_df, coauthor_df


def generate_github_api_input():
    """
    Generate input files for GitHub API test detection.
    Format compatible with human/ module.
    """
    print("\n" + "=" * 80)
    print(" Generating GitHub API Input Files")
    print("=" * 80)
    
    # Read the classified PRs
    ai_only_path = OUTPUT_DIR / "ai_only_prs.csv"
    coauthor_path = OUTPUT_DIR / "coauthor_prs.csv"
    
    if not ai_only_path.exists() or not coauthor_path.exists():
        print("Running classification first...")
        extract_ai_prs_with_classification()
    
    ai_only_df = pd.read_csv(ai_only_path)
    coauthor_df = pd.read_csv(coauthor_path)
    
    # Format for GitHub API (same as human/ module expects)
    # Columns: pr_number, repo_owner, repo_name, html_url
    
    api_columns = ['pr_number', 'repo_owner', 'repo_name', 'html_url', 'agent']
    
    ai_only_api = ai_only_df[api_columns].copy()
    ai_only_api_path = OUTPUT_DIR / "ai_only_for_github_api.csv"
    ai_only_api.to_csv(ai_only_api_path, index=False)
    print(f"✓ Saved: {ai_only_api_path} ({len(ai_only_api)} PRs)")
    
    coauthor_api = coauthor_df[api_columns].copy()
    coauthor_api_path = OUTPUT_DIR / "coauthor_for_github_api.csv"
    coauthor_api.to_csv(coauthor_api_path, index=False)
    print(f"✓ Saved: {coauthor_api_path} ({len(coauthor_api)} PRs)")
    
    # Combined for convenience
    combined_api = pd.concat([ai_only_api, coauthor_api])
    combined_api['authorship_type'] = ['ai_only'] * len(ai_only_api) + ['coauthor'] * len(coauthor_api)
    combined_api_path = OUTPUT_DIR / "all_ai_for_github_api.csv"
    combined_api.to_csv(combined_api_path, index=False)
    print(f"✓ Saved: {combined_api_path} ({len(combined_api)} PRs)")
    
    print("\nThese files can be used with the human/ module for test detection via GitHub API.")
    

if __name__ == "__main__":
    # Run extraction and classification
    ai_only_df, coauthor_df = extract_ai_prs_with_classification()
    
    # Generate GitHub API input files
    generate_github_api_input()
    
    print("\n" + "=" * 80)
    print(" DONE!")
    print("=" * 80)
    print("\nNext steps:")
    print("1. Use human/main.py to detect test files via GitHub API")
    print("2. Run coverage_analyzer on PRs with test files")

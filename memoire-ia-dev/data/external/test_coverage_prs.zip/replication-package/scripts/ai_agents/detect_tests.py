#!/usr/bin/env python3
"""
Detect test files in AI Agent PRs via GitHub API.
Generates CSV files compatible with coverage_analyzer.

This script processes PRs extracted from AIDev dataset and detects
which ones modify test files, similar to the human/ module.
"""

import logging
import sys
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional
import argparse

import pandas as pd

# Add parent directory for shared imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from ai_agents.config import (
    GITHUB_TOKEN,
    AI_ONLY_INPUT_CSV,
    COAUTHOR_INPUT_CSV,
    ALL_AI_INPUT_CSV,
    AI_ONLY_OUTPUT_CSV,
    COAUTHOR_OUTPUT_CSV,
    ALL_AI_OUTPUT_CSV,
    ERROR_LOG,
    PROGRESS_LOG,
    TEST_FRAMEWORKS,
    BATCH_SIZE,
    CHECKPOINT_INTERVAL,
    OUTPUT_DIR,
)
from human.utils import (
    parse_github_url,
    detect_test_frameworks,
    is_python_file,
    is_test_file,
    save_results_csv,
    log_error,
    log_progress,
)
from shared.github_api import GitHubAPIClient

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@dataclass
class AIPRAnalysis:
    """Result of analyzing a single AI agent PR."""
    pr_number: int
    html_url: str
    owner: str
    repo: str
    agent: str
    authorship_type: str  # ai_only or coauthor
    test_files_modified: int
    test_frameworks: str  # comma-separated
    python_files_modified: int
    total_commits: int
    test_additions: int
    test_deletions: int
    test_changes: int
    status: str  # success, error, no_tests
    error_message: Optional[str] = None


def analyze_ai_pr(
    api_client: GitHubAPIClient,
    pr_row: pd.Series,
    authorship_type: str,
    pr_index: int = 0,
) -> AIPRAnalysis:
    """
    Analyze a single AI agent PR for test file modifications.
    
    Args:
        api_client: GitHub API client instance
        pr_row: Pandas Series with PR data
        authorship_type: 'ai_only' or 'coauthor'
        pr_index: Index of PR for logging
        
    Returns:
        AIPRAnalysis result object
    """
    try:
        # Extract PR info
        pr_number = int(pr_row["pr_number"])
        html_url = pr_row["html_url"]
        owner = pr_row["repo_owner"]
        repo = pr_row["repo_name"]
        agent = pr_row["agent"]
        
        logger.debug(f"[PR {pr_index}] Analyzing PR {pr_number} ({agent}): {html_url}")
        
        # Fetch PR files via GitHub API
        files = api_client.get_pr_files(owner, repo, pr_number)
        
        if files is None:
            return AIPRAnalysis(
                pr_number=pr_number,
                html_url=html_url,
                owner=owner,
                repo=repo,
                agent=agent,
                authorship_type=authorship_type,
                test_files_modified=0,
                test_frameworks="",
                python_files_modified=0,
                total_commits=0,
                test_additions=0,
                test_deletions=0,
                test_changes=0,
                status="error",
                error_message="Failed to fetch PR files from GitHub API",
            )
        
        # Get commits count (for reference)
        commits = api_client.get_pr_commits(owner, repo, pr_number)
        total_commits = len(commits) if commits else 0
        
        # Analyze PR files for test modifications
        test_files_modified = 0
        test_frameworks_set = set()
        python_files_modified = 0
        test_additions = 0
        test_deletions = 0
        test_changes = 0
        
        for file_obj in files:
            # Check if Python file
            if not is_python_file(file_obj.filename):
                continue
            
            python_files_modified += 1
            
            # Check if test file (by name OR by imports in patch)
            is_test_by_name = is_test_file(file_obj.filename)
            is_test_by_patch = False
            
            # Check patch for test framework imports
            if file_obj.patch:
                frameworks = detect_test_frameworks(file_obj.patch, TEST_FRAMEWORKS)
                if frameworks:
                    is_test_by_patch = True
                    test_frameworks_set.update(frameworks)
            
            # Count as test if ANY method detects it
            if is_test_by_name or is_test_by_patch:
                test_files_modified += 1
                test_additions += file_obj.additions
                test_deletions += file_obj.deletions
                test_changes += file_obj.changes
        
        # Determine status
        if test_files_modified > 0:
            status = "success"
        else:
            status = "no_tests"
        
        return AIPRAnalysis(
            pr_number=pr_number,
            html_url=html_url,
            owner=owner,
            repo=repo,
            agent=agent,
            authorship_type=authorship_type,
            test_files_modified=test_files_modified,
            test_frameworks=",".join(sorted(test_frameworks_set)),
            python_files_modified=python_files_modified,
            total_commits=total_commits,
            test_additions=test_additions,
            test_deletions=test_deletions,
            test_changes=test_changes,
            status=status,
        )
    
    except Exception as e:
        pr_number = int(pr_row.get("pr_number", -1))
        html_url = pr_row.get("html_url", "unknown")
        owner = pr_row.get("repo_owner", "unknown")
        repo = pr_row.get("repo_name", "unknown")
        agent = pr_row.get("agent", "unknown")
        
        error_msg = f"Exception analyzing PR {pr_number}: {str(e)}"
        logger.error(error_msg)
        log_error(error_msg, ERROR_LOG)
        
        return AIPRAnalysis(
            pr_number=pr_number,
            html_url=html_url,
            owner=owner,
            repo=repo,
            agent=agent,
            authorship_type=authorship_type,
            test_files_modified=0,
            test_frameworks="",
            python_files_modified=0,
            total_commits=0,
            test_additions=0,
            test_deletions=0,
            test_changes=0,
            status="error",
            error_message=str(e),
        )


def process_prs(
    input_csv: Path,
    output_csv: Path,
    authorship_type: str,
    api_client: GitHubAPIClient,
    limit: Optional[int] = None,
) -> pd.DataFrame:
    """
    Process all PRs from input CSV and save results.
    
    Args:
        input_csv: Path to input CSV with PR data
        output_csv: Path to output CSV for results
        authorship_type: 'ai_only' or 'coauthor'
        api_client: GitHub API client
        limit: Optional limit on number of PRs to process
        
    Returns:
        DataFrame with analysis results
    """
    print(f"\n📂 Loading PRs from: {input_csv}")
    prs_df = pd.read_csv(input_csv)
    total_prs = len(prs_df)
    
    if limit:
        prs_df = prs_df.head(limit)
        total_prs = len(prs_df)
        print(f"   Limited to first {limit} PRs")
    
    print(f"   Total PRs to analyze: {total_prs}")
    
    # Check for existing progress (resume capability)
    if output_csv.exists():
        existing_df = pd.read_csv(output_csv)
        existing_urls = set(existing_df["html_url"].tolist())
        prs_df = prs_df[~prs_df["html_url"].isin(existing_urls)]
        remaining = len(prs_df)
        print(f"   Resuming: {total_prs - remaining} already processed, {remaining} remaining")
        total_prs = remaining
        
        if remaining == 0:
            print("   All PRs already processed!")
            return existing_df
    else:
        existing_df = None
    
    results = []
    errors = 0
    no_tests = 0
    with_tests = 0
    
    print(f"\n[*] Analyzing {authorship_type} PRs...")
    
    for idx, (_, pr_row) in enumerate(prs_df.iterrows(), 1):
        # Check rate limit before processing
        if api_client.is_rate_limited:
            logger.warning(f"Rate limit approaching: {api_client.get_rate_limit_info()}")
            print(f"\n⚠️  WARNING: {api_client.get_rate_limit_info()}")
            print(f"   Processed {idx-1}/{total_prs} PRs")
            print(f"   Saving progress and pausing...")
            break
        
        # Print progress
        if idx % BATCH_SIZE == 0 or idx == 1:
            pct = (idx / total_prs) * 100 if total_prs > 0 else 0
            print(f"   [{idx}/{total_prs}] ({pct:.1f}%) - {api_client.get_rate_limit_info()}")
        
        # Analyze PR
        analysis = analyze_ai_pr(api_client, pr_row, authorship_type, idx)
        results.append(analysis)
        
        # Update counters
        if analysis.status == "error":
            errors += 1
        elif analysis.status == "no_tests":
            no_tests += 1
        else:
            with_tests += 1
        
        # Save checkpoint
        if idx % CHECKPOINT_INTERVAL == 0:
            checkpoint_df = pd.DataFrame([asdict(r) for r in results])
            if existing_df is not None:
                checkpoint_df = pd.concat([existing_df, checkpoint_df], ignore_index=True)
            save_results_csv(checkpoint_df, output_csv)
            log_progress(f"Checkpoint at PR {idx}/{total_prs} ({authorship_type})", PROGRESS_LOG)
    
    # Save final results
    results_df = pd.DataFrame([asdict(r) for r in results])
    if existing_df is not None:
        results_df = pd.concat([existing_df, results_df], ignore_index=True)
    save_results_csv(results_df, output_csv)
    
    # Print summary
    print(f"\n   Summary for {authorship_type}:")
    print(f"     ✓ With test files: {with_tests}")
    print(f"     ○ No test files: {no_tests}")
    print(f"     ✗ Errors: {errors}")
    print(f"   ✓ Saved: {output_csv}")
    
    return results_df


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Detect test files in AI Agent PRs")
    parser.add_argument(
        "--type",
        choices=["ai_only", "coauthor", "all"],
        default="all",
        help="Which PR type to process (default: all)",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Limit number of PRs to process (for testing)",
    )
    args = parser.parse_args()
    
    print("\n" + "=" * 80)
    print(" AI Agent PR Analysis - GitHub API Test Detection")
    print("=" * 80)
    
    # Validate setup
    if not GITHUB_TOKEN:
        print("❌ ERROR: GITHUB_TOKEN not set. Please set it in .env file")
        return
    
    # Initialize API client
    print(f"\n🔐 Initializing GitHub API client...")
    api_client = GitHubAPIClient(token=GITHUB_TOKEN)
    
    # Check rate limits
    rate_limit_info = api_client.check_rate_limit()
    if rate_limit_info:
        remaining = rate_limit_info.get("rate_limit", {}).get("remaining", "unknown")
        limit = rate_limit_info.get("rate_limit", {}).get("limit", "unknown")
        print(f"   Rate limit: {remaining}/{limit}")
    
    # Setup debug logging
    log_file = OUTPUT_DIR / "detect_tests_debug.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.setLevel(logging.DEBUG)
    
    # Process based on type
    all_results = []
    
    if args.type in ["ai_only", "all"]:
        if AI_ONLY_INPUT_CSV.exists():
            ai_only_results = process_prs(
                AI_ONLY_INPUT_CSV,
                AI_ONLY_OUTPUT_CSV,
                "ai_only",
                api_client,
                args.limit,
            )
            all_results.append(ai_only_results)
        else:
            print(f"⚠️  AI-Only input not found: {AI_ONLY_INPUT_CSV}")
    
    if args.type in ["coauthor", "all"]:
        if COAUTHOR_INPUT_CSV.exists():
            coauthor_results = process_prs(
                COAUTHOR_INPUT_CSV,
                COAUTHOR_OUTPUT_CSV,
                "coauthor",
                api_client,
                args.limit,
            )
            all_results.append(coauthor_results)
        else:
            print(f"⚠️  Coauthor input not found: {COAUTHOR_INPUT_CSV}")
    
    # Combine all results
    if args.type == "all" and all_results:
        combined_df = pd.concat(all_results, ignore_index=True)
        save_results_csv(combined_df, ALL_AI_OUTPUT_CSV)
        print(f"\n✓ Combined output saved: {ALL_AI_OUTPUT_CSV}")
    
    # Final summary
    print("\n" + "=" * 80)
    print(" FINAL SUMMARY")
    print("=" * 80)
    
    for result_df in all_results:
        if len(result_df) > 0:
            auth_type = result_df["authorship_type"].iloc[0]
            total = len(result_df)
            with_tests = len(result_df[result_df["status"] == "success"])
            no_tests = len(result_df[result_df["status"] == "no_tests"])
            errors = len(result_df[result_df["status"] == "error"])
            
            pct_with_tests = (with_tests / total * 100) if total > 0 else 0
            
            print(f"\n{auth_type.upper()}:")
            print(f"  Total PRs: {total}")
            print(f"  With tests: {with_tests} ({pct_with_tests:.1f}%)")
            print(f"  No tests: {no_tests}")
            print(f"  Errors: {errors}")
            
            # Agent breakdown
            agent_stats = result_df.groupby("agent").agg({
                "status": lambda x: (x == "success").sum(),
                "pr_number": "count",
            }).rename(columns={"status": "with_tests", "pr_number": "total"})
            agent_stats["pct"] = (agent_stats["with_tests"] / agent_stats["total"] * 100).round(1)
            
            print(f"\n  By Agent:")
            for agent, row in agent_stats.iterrows():
                print(f"    {agent}: {row['with_tests']}/{row['total']} ({row['pct']}%)")
    
    print("\n" + "=" * 80)
    print(" DONE!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()

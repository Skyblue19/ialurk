"""
Base configuration for MSR Coverage Analysis project.

Contains shared constants and configuration patterns used across modules.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Any, Optional
import os


# =============================================================================
# Test File Detection Patterns
# =============================================================================

TEST_FILE_PATTERNS: List[str] = [
    r"test_.*\.py$",           # test_foo.py
    r".*_test\.py$",           # foo_test.py
    r"tests?/.*\.py$",         # tests/foo.py or test/foo.py
    r".*tests?\.py$",          # footests.py or footest.py
    r"conftest\.py$",          # pytest configuration
    r".*_tests?/.*\.py$",      # foo_tests/bar.py
]

# Test framework detection patterns
TEST_FRAMEWORKS: Dict[str, List[str]] = {
    "pytest": ["pytest", "py.test", "@pytest.fixture", "pytest.mark"],
    "unittest": ["import unittest", "from unittest", "TestCase"],
    "nose": ["import nose", "from nose"],
    "hypothesis": ["from hypothesis", "@given"],
}


# =============================================================================
# Base Configuration Class
# =============================================================================

@dataclass
class BaseConfig:
    """
    Base configuration class with common settings.
    
    Subclass this for module-specific configurations.
    """
    
    # Project paths
    project_root: Path = field(default_factory=lambda: Path(__file__).parent.parent)
    
    # GitHub API settings
    github_token: Optional[str] = field(default_factory=lambda: os.getenv("GITHUB_TOKEN"))
    github_rate_limit_delay: float = 0.75  # seconds between requests
    github_request_timeout: int = 15  # seconds
    
    # Logging settings
    log_level: str = "INFO"
    log_format: str = "[%(asctime)s.%(msecs)03d] %(levelname)-8s | %(name)s | %(message)s"
    log_date_format: str = "%H:%M:%S"
    
    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        if isinstance(self.project_root, str):
            self.project_root = Path(self.project_root)
    
    def validate(self) -> List[str]:
        """
        Validate configuration and return list of errors.
        
        Returns:
            List of error messages (empty if valid).
        """
        errors: List[str] = []
        
        if not self.project_root.exists():
            errors.append(f"Project root does not exist: {self.project_root}")
        
        return errors
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "project_root": str(self.project_root),
            "github_token": "***" if self.github_token else None,
            "github_rate_limit_delay": self.github_rate_limit_delay,
            "github_request_timeout": self.github_request_timeout,
            "log_level": self.log_level,
        }


# =============================================================================
# Environment Detection
# =============================================================================

def is_running_in_docker() -> bool:
    """Check if code is running inside a Docker container."""
    # Check for .dockerenv file (most reliable)
    if Path("/.dockerenv").exists():
        return True
    # Check cgroup for docker
    try:
        with open("/proc/1/cgroup", "r") as f:
            return "docker" in f.read()
    except (FileNotFoundError, PermissionError):
        pass
    return False


def get_cache_directory() -> Path:
    """
    Get the appropriate cache directory based on environment.
    
    Returns:
        Path to cache directory.
    """
    if is_running_in_docker() and Path("/cache").exists():
        return Path("/cache")
    
    # Use /tmp to avoid polluting project directory
    cache_dir = Path("/tmp/coverage_analyzer_cache")
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir

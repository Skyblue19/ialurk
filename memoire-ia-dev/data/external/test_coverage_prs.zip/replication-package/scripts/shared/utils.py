"""
Utility functions for MSR Coverage Analysis project.

Contains common utilities for test file detection, URL parsing, and CSV I/O.
"""

import csv
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from shared.config import TEST_FILE_PATTERNS

logger = logging.getLogger(__name__)


# =============================================================================
# Test File Detection
# =============================================================================

# Pre-compile patterns for performance
_TEST_FILE_REGEXES = [re.compile(pattern) for pattern in TEST_FILE_PATTERNS]


def is_test_file(filename: str) -> bool:
    """
    Check if a filename matches test file patterns.
    
    Matches patterns like:
    - test_*.py
    - *_test.py
    - tests/*.py
    - conftest.py
    
    Args:
        filename: File path or name to check.
    
    Returns:
        True if the file appears to be a test file.
    
    Example:
        >>> is_test_file("test_utils.py")
        True
        >>> is_test_file("utils.py")
        False
        >>> is_test_file("tests/test_api.py")
        True
    """
    if not filename:
        return False
    
    # Normalize path separators
    normalized = filename.replace("\\", "/")
    
    for regex in _TEST_FILE_REGEXES:
        if regex.search(normalized):
            return True
    
    return False


def filter_test_files(filenames: List[str]) -> List[str]:
    """
    Filter a list of filenames to only include test files.
    
    Args:
        filenames: List of file paths to filter.
    
    Returns:
        List containing only test files.
    """
    return [f for f in filenames if is_test_file(f)]


# =============================================================================
# URL Parsing
# =============================================================================

def parse_repo_url(url: str) -> Optional[Tuple[str, str]]:
    """
    Extract owner and repo name from a GitHub URL.
    
    Supports formats:
    - https://github.com/owner/repo
    - https://github.com/owner/repo/pull/123
    - git@github.com:owner/repo.git
    
    Args:
        url: GitHub URL to parse.
    
    Returns:
        Tuple of (owner, repo) or None if URL couldn't be parsed.
    
    Example:
        >>> parse_repo_url("https://github.com/octocat/Hello-World")
        ('octocat', 'Hello-World')
        >>> parse_repo_url("https://github.com/octocat/Hello-World/pull/123")
        ('octocat', 'Hello-World')
    """
    if not url:
        return None
    
    # HTTPS format
    https_pattern = r"github\.com/([^/]+)/([^/]+?)(?:\.git)?(?:/|$)"
    match = re.search(https_pattern, url)
    if match:
        return match.group(1), match.group(2)
    
    # SSH format
    ssh_pattern = r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$"
    match = re.search(ssh_pattern, url)
    if match:
        return match.group(1), match.group(2)
    
    return None


def parse_pr_url(url: str) -> Optional[Tuple[str, str, int]]:
    """
    Extract owner, repo, and PR number from a GitHub PR URL.
    
    Args:
        url: GitHub PR URL.
    
    Returns:
        Tuple of (owner, repo, pr_number) or None if URL couldn't be parsed.
    
    Example:
        >>> parse_pr_url("https://github.com/octocat/Hello-World/pull/123")
        ('octocat', 'Hello-World', 123)
    """
    if not url:
        return None
    
    pattern = r"github\.com/([^/]+)/([^/]+)/pull/(\d+)"
    match = re.search(pattern, url)
    
    if match:
        return match.group(1), match.group(2), int(match.group(3))
    
    return None


# =============================================================================
# CSV I/O
# =============================================================================

def load_csv(
    filepath: Union[str, Path],
    required_columns: Optional[List[str]] = None,
) -> List[Dict[str, Any]]:
    """
    Load data from a CSV file.
    
    Args:
        filepath: Path to CSV file.
        required_columns: Optional list of columns that must exist.
    
    Returns:
        List of dictionaries, one per row.
    
    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If required columns are missing.
    """
    filepath = Path(filepath)
    
    if not filepath.exists():
        raise FileNotFoundError(f"CSV file not found: {filepath}")
    
    rows: List[Dict[str, Any]] = []
    
    with open(filepath, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        
        # Validate columns if required
        if required_columns and reader.fieldnames:
            missing = set(required_columns) - set(reader.fieldnames)
            if missing:
                raise ValueError(f"Missing required columns: {missing}")
        
        rows = list(reader)
    
    logger.info(f"Loaded {len(rows)} rows from {filepath}")
    return rows


def save_csv(
    filepath: Union[str, Path],
    rows: List[Dict[str, Any]],
    columns: Optional[List[str]] = None,
    append: bool = False,
) -> int:
    """
    Save data to a CSV file.
    
    Args:
        filepath: Path to CSV file.
        rows: List of dictionaries to write.
        columns: Column order (uses keys from first row if not specified).
        append: If True, append to existing file without header.
    
    Returns:
        Number of rows written.
    """
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    if not rows:
        logger.warning(f"No rows to write to {filepath}")
        return 0
    
    # Determine column order
    if columns is None:
        columns = list(rows[0].keys())
    
    mode = "a" if append and filepath.exists() else "w"
    write_header = not (append and filepath.exists())
    
    with open(filepath, mode, newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        
        if write_header:
            writer.writeheader()
        
        writer.writerows(rows)
    
    logger.info(f"Wrote {len(rows)} rows to {filepath}")
    return len(rows)


# =============================================================================
# Logging Setup
# =============================================================================

def setup_logging(
    level: str = "INFO",
    log_file: Optional[Path] = None,
    format_string: Optional[str] = None,
) -> None:
    """
    Configure logging for the application.
    
    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR).
        log_file: Optional file to write logs to.
        format_string: Optional custom format string.
    """
    if format_string is None:
        format_string = "[%(asctime)s.%(msecs)03d] %(levelname)-8s | %(name)s | %(message)s"
    
    handlers: List[logging.Handler] = [logging.StreamHandler()]
    
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_file))
    
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format=format_string,
        datefmt="%H:%M:%S",
        handlers=handlers,
        force=True,
    )


# =============================================================================
# Miscellaneous
# =============================================================================

def truncate_string(s: str, max_length: int = 500) -> str:
    """
    Truncate a string to a maximum length.
    
    Args:
        s: String to truncate.
        max_length: Maximum length.
    
    Returns:
        Truncated string with "..." if it was shortened.
    """
    if len(s) <= max_length:
        return s
    return s[:max_length - 3] + "..."

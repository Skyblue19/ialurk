"""
Shared library for MSR Coverage Analysis project.

This package contains common utilities used by both the coverage_analyzer
and human PR analysis modules.
"""

__version__ = "1.0.0"

from shared.github_api import GitHubAPIClient, Commit, CommitFile
from shared.utils import is_test_file, parse_repo_url, load_csv, save_csv
from shared.config import BaseConfig, TEST_FILE_PATTERNS

__all__ = [
    "GitHubAPIClient",
    "Commit", 
    "CommitFile",
    "is_test_file",
    "parse_repo_url",
    "load_csv",
    "save_csv",
    "BaseConfig",
    "TEST_FILE_PATTERNS",
]

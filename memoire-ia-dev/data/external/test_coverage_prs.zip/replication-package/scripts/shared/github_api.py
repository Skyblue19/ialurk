"""
GitHub API client for fetching PR, commit, and file data.

This module provides a rate-limited GitHub API client with support for
fetching PR details, commits, files, and content.
"""

import base64
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class CommitFile:
    """Represents a file changed in a commit or PR."""
    
    filename: str
    status: str  # added, removed, modified, renamed
    additions: int
    deletions: int
    changes: int
    patch: Optional[str] = None
    
    @property
    def is_test_file(self) -> bool:
        """Check if this file is a test file based on naming conventions."""
        from shared.utils import is_test_file
        return is_test_file(self.filename)


@dataclass
class Commit:
    """Represents a commit in a repository."""
    
    sha: str
    author: Optional[str]
    message: str
    files: List[CommitFile]
    
    @property
    def short_sha(self) -> str:
        """Return first 8 characters of SHA."""
        return self.sha[:8] if self.sha else ""
    
    @property
    def test_files(self) -> List[CommitFile]:
        """Return only test files from this commit."""
        return [f for f in self.files if f.is_test_file]


# =============================================================================
# API Client
# =============================================================================

class GitHubAPIClient:
    """
    GitHub API client with rate limiting and error handling.
    
    Provides methods for fetching PR details, commits, files, and content
    with automatic rate limiting and retry logic.
    
    Example:
        >>> client = GitHubAPIClient(token="ghp_xxx")
        >>> pr = client.get_pr_details("owner", "repo", 123)
        >>> files = client.get_pr_files("owner", "repo", 123)
    """
    
    BASE_URL = "https://api.github.com"
    
    def __init__(
        self,
        token: str,
        rate_limit_delay: float = 0.75,
        request_timeout: int = 15,
    ) -> None:
        """
        Initialize GitHub API client.
        
        Args:
            token: GitHub personal access token.
            rate_limit_delay: Seconds to wait between requests (default: 0.75).
            request_timeout: Request timeout in seconds (default: 15).
        """
        self.token = token
        self.rate_limit_delay = rate_limit_delay
        self.request_timeout = request_timeout
        
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
        })
        
        self._last_request_time: float = 0
        self._rate_limit_remaining: Optional[int] = None
        self._rate_limit_reset: Optional[int] = None
    
    # -------------------------------------------------------------------------
    # Rate Limiting
    # -------------------------------------------------------------------------
    
    def _wait_for_rate_limit(self) -> None:
        """Enforce rate limiting delay between requests."""
        elapsed = time.time() - self._last_request_time
        if elapsed < self.rate_limit_delay:
            wait_time = self.rate_limit_delay - elapsed
            logger.debug(f"Rate limiting: waiting {wait_time:.3f}s")
            time.sleep(wait_time)
    
    @property
    def rate_limit_remaining(self) -> Optional[int]:
        """Number of API requests remaining in current window."""
        return self._rate_limit_remaining
    
    @property
    def is_rate_limited(self) -> bool:
        """Check if we're close to being rate limited."""
        if self._rate_limit_remaining is not None:
            return self._rate_limit_remaining <= 10
        return False
    
    def get_rate_limit_info(self) -> str:
        """Get human-readable rate limit status."""
        if self._rate_limit_remaining is not None:
            return f"{self._rate_limit_remaining} requests remaining"
        return "Unknown"
    
    # -------------------------------------------------------------------------
    # HTTP Methods
    # -------------------------------------------------------------------------
    
    def _get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Make GET request with rate limiting and error handling.
        
        Args:
            endpoint: API endpoint (will be appended to BASE_URL).
            params: Optional query parameters.
        
        Returns:
            Response JSON as dict, or None if request failed.
        """
        url = f"{self.BASE_URL}{endpoint}"
        logger.debug(f"API GET: {url}")
        
        self._wait_for_rate_limit()
        
        try:
            response = self.session.get(
                url,
                params=params,
                timeout=self.request_timeout,
            )
            self._last_request_time = time.time()
            
            # Update rate limit tracking
            self._rate_limit_remaining = int(
                response.headers.get("X-RateLimit-Remaining", 0)
            )
            self._rate_limit_reset = int(
                response.headers.get("X-RateLimit-Reset", 0)
            )
            
            logger.debug(f"API Response: {response.status_code}")
            logger.debug(f"Rate Limit Remaining: {self._rate_limit_remaining}")
            
            # Handle error responses
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", "60")
                logger.error(f"429 Too Many Requests. Retry after: {retry_after}s")
                return None
            
            if response.status_code == 404:
                logger.warning(f"404 Not Found: {url}")
                return None
            
            if response.status_code == 403:
                logger.error(f"403 Forbidden: {url}")
                return None
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.Timeout:
            logger.error(f"Timeout ({self.request_timeout}s): {url}")
            return None
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error for {url}: {e}")
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error for {url}: {e}")
            return None
    
    # -------------------------------------------------------------------------
    # PR Methods
    # -------------------------------------------------------------------------
    
    def get_pr_details(
        self,
        owner: str,
        repo: str,
        pr_number: int,
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch PR metadata including base/head SHAs and merge status.
        
        Args:
            owner: Repository owner.
            repo: Repository name.
            pr_number: PR number.
        
        Returns:
            PR details dict with keys: state, merged, merged_at, base, head.
            Returns None if request failed.
        """
        endpoint = f"/repos/{owner}/{repo}/pulls/{pr_number}"
        data = self._get(endpoint)
        
        if data:
            logger.debug(f"PR #{pr_number}: state={data.get('state')}, "
                        f"merged={data.get('merged')}")
        
        return data
    
    def get_pr_files(
        self,
        owner: str,
        repo: str,
        pr_number: int,
    ) -> Optional[List[CommitFile]]:
        """
        Fetch all files modified in a PR.
        
        Args:
            owner: Repository owner.
            repo: Repository name.
            pr_number: PR number.
        
        Returns:
            List of CommitFile objects, or None if request failed.
        """
        endpoint = f"/repos/{owner}/{repo}/pulls/{pr_number}/files"
        data = self._get(endpoint)
        
        if not data:
            return None
        
        files = [
            CommitFile(
                filename=f.get("filename", ""),
                status=f.get("status", ""),
                additions=f.get("additions", 0),
                deletions=f.get("deletions", 0),
                changes=f.get("changes", 0),
                patch=f.get("patch"),
            )
            for f in data
        ]
        
        logger.debug(f"PR #{pr_number}: {len(files)} files")
        return files
    
    def get_pr_commits(
        self,
        owner: str,
        repo: str,
        pr_number: int,
    ) -> Optional[List[Commit]]:
        """
        Fetch all commits in a PR.
        
        Note: This endpoint does NOT return file details per commit.
        Use get_commit_detail() for full commit information.
        
        Args:
            owner: Repository owner.
            repo: Repository name.
            pr_number: PR number.
        
        Returns:
            List of Commit objects, or None if request failed.
        """
        endpoint = f"/repos/{owner}/{repo}/pulls/{pr_number}/commits"
        data = self._get(endpoint)
        
        if not data:
            return None
        
        commits = [
            Commit(
                sha=c.get("sha", ""),
                author=c.get("commit", {}).get("author", {}).get("name"),
                message=c.get("commit", {}).get("message", ""),
                files=[],  # Not available from this endpoint
            )
            for c in data
        ]
        
        logger.debug(f"PR #{pr_number}: {len(commits)} commits")
        return commits
    
    # -------------------------------------------------------------------------
    # Commit Methods
    # -------------------------------------------------------------------------
    
    def get_commit_detail(
        self,
        owner: str,
        repo: str,
        sha: str,
    ) -> Optional[Commit]:
        """
        Fetch detailed commit information including files.
        
        Args:
            owner: Repository owner.
            repo: Repository name.
            sha: Commit SHA.
        
        Returns:
            Commit object with files, or None if request failed.
        """
        endpoint = f"/repos/{owner}/{repo}/commits/{sha}"
        data = self._get(endpoint)
        
        if not data:
            return None
        
        files = [
            CommitFile(
                filename=f.get("filename", ""),
                status=f.get("status", ""),
                additions=f.get("additions", 0),
                deletions=f.get("deletions", 0),
                changes=f.get("changes", 0),
                patch=f.get("patch"),
            )
            for f in data.get("files", [])
        ]
        
        return Commit(
            sha=data.get("sha", ""),
            author=data.get("commit", {}).get("author", {}).get("name"),
            message=data.get("commit", {}).get("message", ""),
            files=files,
        )
    
    # -------------------------------------------------------------------------
    # File Content Methods
    # -------------------------------------------------------------------------
    
    def get_file_content(
        self,
        owner: str,
        repo: str,
        file_path: str,
        ref: str = "HEAD",
    ) -> Optional[str]:
        """
        Fetch file content from repository.
        
        Args:
            owner: Repository owner.
            repo: Repository name.
            file_path: Path to file in repository.
            ref: Git ref (branch, tag, or commit SHA).
        
        Returns:
            File content as string, or None if request failed.
        """
        endpoint = f"/repos/{owner}/{repo}/contents/{file_path}"
        data = self._get(endpoint, params={"ref": ref})
        
        if not data or "content" not in data:
            return None
        
        try:
            content = base64.b64decode(data["content"]).decode("utf-8")
            logger.debug(f"Got file content: {len(content)} bytes")
            return content
        except Exception as e:
            logger.error(f"Failed to decode file content: {e}")
            return None
    
    # -------------------------------------------------------------------------
    # Rate Limit Methods
    # -------------------------------------------------------------------------
    
    def check_rate_limit(self) -> Optional[Dict[str, Any]]:
        """
        Check current rate limit status.
        
        Returns:
            Rate limit status dict, or None if request failed.
        """
        return self._get("/rate_limit")

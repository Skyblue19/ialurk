"""Configuration for Human PR GitHub API Analyzer."""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add parent to path for shared imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Load environment variables
load_dotenv()

# Import from shared config
from shared.config import TEST_FRAMEWORKS as SHARED_TEST_FRAMEWORKS

# GitHub API Configuration
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# Paths - use relative paths from project root
PROJECT_ROOT = Path(__file__).parent
MSR_ROOT = PROJECT_ROOT.parent
DATA_DIR = MSR_ROOT / "notebooks"
OUTPUT_DIR = PROJECT_ROOT / "output"

# Input CSV from coauthorship analysis
INPUT_CSV = DATA_DIR / "02_human_prs_python_repos.csv"

# Output files
OUTPUT_CSV = OUTPUT_DIR / "human_prs_test_detection.csv"
ERROR_LOG = OUTPUT_DIR / "errors.log"
PROGRESS_LOG = OUTPUT_DIR / "progress.log"

# Re-export shared test frameworks (extended with more patterns)
TEST_FRAMEWORKS = {
    "pytest": [r"import pytest", r"from pytest", r"@pytest\.", r"pytest\."],
    "unittest": [r"import unittest", r"from unittest", r"TestCase"],
    "mock": [r"import mock", r"from mock", r"from unittest\.mock"],
    "hypothesis": [r"import hypothesis", r"from hypothesis", r"@hypothesis\."],
    "nose": [r"import nose", r"from nose"],
}

# Batch Processing
BATCH_SIZE = 50  # Process 50 PRs before saving checkpoint
CHECKPOINT_INTERVAL = 100  # Save progress every 100 PRs

# Create output directory if it doesn't exist
OUTPUT_DIR.mkdir(exist_ok=True)

"""GitHub API client for fetching PR commit data."""

import time
import requests
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class CommitFile:
    """Represents a file changed in a commit."""
    filename: str
    status: str  # added, removed, modified
    additions: int
    deletions: int
    changes: int
    patch: Optional[str] = None


@dataclass
class Commit:
    """Represents a commit in a PR."""
    sha: str
    author: Optional[str]
    message: str
    files: List[CommitFile]


class GitHubAPIClient:
    """Simple GitHub API client for PR analysis."""
    
    def __init__(self, token: str, rate_limit_delay: float = 0.75):
        """
        Initialize GitHub API client.
        
        Args:
            token: GitHub personal access token
            rate_limit_delay: Seconds to wait between requests (default: 0.75 = ~1.4 req/sec)
        """
        self.token = token
        self.rate_limit_delay = rate_limit_delay
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        self.last_request_time = 0
        self.rate_limit_remaining = None
        self.rate_limit_reset = None
    
    def _wait_for_rate_limit(self):
        """Enforce rate limiting delay."""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.rate_limit_delay:
            wait_time = self.rate_limit_delay - elapsed
            logger.debug(f"Rate limiting: waiting {wait_time:.3f}s")
            time.sleep(wait_time)
    
    def _get(self, url: str) -> Optional[Dict[str, Any]]:
        """Make GET request with rate limiting and error handling."""
        logger.debug(f"API GET: {url}")
        self._wait_for_rate_limit()
        
        try:
            response = self.session.get(url, timeout=15)
            self.last_request_time = time.time()
            
            # Update rate limit tracking
            self.rate_limit_remaining = int(response.headers.get("X-RateLimit-Remaining", 0))
            self.rate_limit_reset = int(response.headers.get("X-RateLimit-Reset", 0))
            
            logger.debug(f"API Response: {response.status_code} for {url}")
            logger.debug(f"   Rate Limit Remaining: {self.rate_limit_remaining}")
            
            # Check if rate limited
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", "60")
                logger.error(f"429 Too Many Requests: {url}")
                logger.error(f"   Retry after: {retry_after}s")
                logger.error(f"   Rate Limit Remaining: {self.rate_limit_remaining}")
                return None
            
            if response.status_code == 404:
                logger.warning(f"404 Not Found: {url}")
                return None
            
            if response.status_code == 403:
                logger.error(f"403 Forbidden: {url}")
                logger.error(f"   Rate Limit Remaining: {self.rate_limit_remaining}")
                logger.error(f"   Rate Limit Reset: {self.rate_limit_reset}")
                return None
            
            response.raise_for_status()
            data = response.json()
            logger.debug(f"API Success: got {len(data) if isinstance(data, list) else 'object'} items")
            return data
        
        except requests.exceptions.Timeout as e:
            logger.error(f"Timeout (15s): {url} - {str(e)}")
            return None
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error for {url}: {str(e)}")
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error for {url}: {str(e)}")
            return None
    
    def get_pr_commits(self, owner: str, repo: str, pr_number: int) -> Optional[List[Commit]]:
        """
        Fetch all commits for a PR.
        
        Args:
            owner: Repository owner
            repo: Repository name
            pr_number: PR number
            
        Returns:
            List of Commit objects or None if request failed
        """
        url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/commits"
        logger.debug(f"Fetching commits for {owner}/{repo} PR #{pr_number}")
        data = self._get(url)
        
        if not data:
            logger.warning(f"Failed to fetch commits for {owner}/{repo}#{pr_number}")
            return None
        
        logger.debug(f"Found {len(data)} commits in PR")
        commits = []
        for i, commit_data in enumerate(data):
            sha = commit_data.get("sha")
            author = commit_data.get("commit", {}).get("author", {}).get("name")
            message = commit_data.get("commit", {}).get("message", "")
            
            logger.debug(f"  Commit {i+1}: {sha[:8]} by {author}")
            
            files = []
            for file_data in commit_data.get("files", []):
                file_obj = CommitFile(
                    filename=file_data.get("filename", ""),
                    status=file_data.get("status", ""),
                    additions=file_data.get("additions", 0),
                    deletions=file_data.get("deletions", 0),
                    changes=file_data.get("changes", 0),
                    patch=file_data.get("patch"),
                )
                files.append(file_obj)
            
            logger.debug(f"    Files changed: {len(files)}")
            commits.append(Commit(sha=sha, author=author, message=message, files=files))
        
        return commits
    
    def get_commit_detail(self, owner: str, repo: str, sha: str) -> Optional[Commit]:
        """
        Fetch detailed commit information.
        
        Args:
            owner: Repository owner
            repo: Repository name
            sha: Commit SHA
            
        Returns:
            Commit object or None if request failed
        """
        url = f"https://api.github.com/repos/{owner}/{repo}/commits/{sha}"
        data = self._get(url)
        
        if not data:
            return None
        
        author = data.get("commit", {}).get("author", {}).get("name")
        message = data.get("commit", {}).get("message", "")
        
        files = []
        for file_data in data.get("files", []):
            file_obj = CommitFile(
                filename=file_data.get("filename", ""),
                status=file_data.get("status", ""),
                additions=file_data.get("additions", 0),
                deletions=file_data.get("deletions", 0),
                changes=file_data.get("changes", 0),
                patch=file_data.get("patch"),
            )
            files.append(file_obj)
        
        return Commit(sha=sha, author=author, message=message, files=files)
    
    def check_rate_limit(self) -> Optional[Dict[str, Any]]:
        """Check current rate limit status."""
        url = "https://api.github.com/rate_limit"
        return self._get(url)
    
    def is_rate_limited(self) -> bool:
        """Check if we're currently rate limited."""
        if self.rate_limit_remaining is not None:
            return self.rate_limit_remaining <= 10  # Consider limited if < 10 requests left
        return False
    
    def get_rate_limit_info(self) -> str:
        """Get human-readable rate limit info."""
        if self.rate_limit_remaining is not None:
            return f"{self.rate_limit_remaining} requests remaining"
        return "Unknown"
    
    def get_pr_files(self, owner: str, repo: str, pr_number: int) -> Optional[List[CommitFile]]:
        """
        Fetch all files modified in a PR (CORRECT endpoint).
        
        NOTE: /pulls/{pr}/commits doesn't return files array.
              Use /pulls/{pr}/files instead.
        
        Args:
            owner: Repository owner
            repo: Repository name
            pr_number: PR number
            
        Returns:
            List of CommitFile objects or None if request failed
        """
        url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"
        logger.debug(f"Fetching PR files for {owner}/{repo} PR #{pr_number}")
        data = self._get(url)
        
        if not data:
            logger.warning(f"Failed to fetch PR files for {owner}/{repo}#{pr_number}")
            return None
        
        logger.debug(f"Found {len(data)} files in PR")
        files = []
        for file_data in data:
            file_obj = CommitFile(
                filename=file_data.get("filename", ""),
                status=file_data.get("status", ""),
                additions=file_data.get("additions", 0),
                deletions=file_data.get("deletions", 0),
                changes=file_data.get("changes", 0),
                patch=file_data.get("patch"),
            )
            files.append(file_obj)
            logger.debug(f"  File: {file_obj.filename} ({file_obj.status})")
        
        return files
    
    def get_pr_details(self, owner: str, repo: str, pr_number: int) -> Optional[Dict[str, Any]]:
        """
        Fetch PR metadata including base and head commit SHAs, state and merged status.
        
        Args:
            owner: Repository owner
            repo: Repository name
            pr_number: PR number
            
        Returns:
            PR details dict with base/head information, state, and merged status or None if request failed.
            The dict includes:
            - state: "open" or "closed"
            - merged: True/False (only meaningful when state is "closed")
            - merged_at: timestamp if merged, None otherwise
        """
        url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}"
        logger.debug(f"Fetching PR details for {owner}/{repo} PR #{pr_number}")
        data = self._get(url)
        
        if not data:
            logger.warning(f"Failed to fetch PR details for {owner}/{repo}#{pr_number}")
            return None
        
        # Extract base and head commit info
        base_sha = data.get("base", {}).get("sha")
        head_sha = data.get("head", {}).get("sha")
        logger.debug(f"PR base SHA: {base_sha[:8] if base_sha else 'None'}")
        logger.debug(f"PR head SHA: {head_sha[:8] if head_sha else 'None'}")
        
        # Extract state and merged status
        # state: "open" or "closed"
        # merged: True if the PR was merged, False otherwise (rejected/closed without merge)
        pr_state = data.get("state", "unknown")
        pr_merged = data.get("merged", False)
        merged_at = data.get("merged_at")
        logger.debug(f"PR state: {pr_state}, merged: {pr_merged}, merged_at: {merged_at}")
        
        return data
    
    def get_file_content(self, owner: str, repo: str, file_path: str, ref: str = "HEAD") -> Optional[str]:
        """
        Fetch full file content from repository.
        
        Args:
            owner: Repository owner
            repo: Repository name
            file_path: Path to file in repository
            ref: Git ref (branch, tag, or commit SHA)
            
        Returns:
            File content as string or None if request failed
        """
        url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}?ref={ref}"
        logger.debug(f"Fetching file content: {owner}/{repo}/{file_path}")
        data = self._get(url)
        
        if not data:
            logger.warning(f"Failed to fetch file: {file_path}")
            return None
        
        # GitHub API returns base64 encoded content
        import base64
        try:
            if "content" in data:
                content = base64.b64decode(data["content"]).decode("utf-8")
                logger.debug(f"Got file content: {len(content)} bytes")
                return content
        except Exception as e:
            logger.error(f"Failed to decode file content: {str(e)}")
            return None
        
        return None

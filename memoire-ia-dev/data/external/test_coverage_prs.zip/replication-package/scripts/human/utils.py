"""Utility functions for GitHub PR analysis - wrapper around shared utilities."""

import re
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

import pandas as pd

# Import from shared library to avoid duplication
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from shared.utils import is_test_file, load_csv, save_csv, parse_pr_url
from shared.config import TEST_FILE_PATTERNS

logger = logging.getLogger(__name__)

# Re-export for backwards compatibility
__all__ = [
    "is_test_file",
    "is_python_file", 
    "parse_github_url",
    "detect_test_frameworks",
    "load_human_prs_csv",
    "save_results_csv",
    "log_error",
    "log_progress",
    "TEST_FILE_PATTERNS",
    "TEST_FRAMEWORKS",
]

# Framework detection patterns
TEST_FRAMEWORKS: Dict[str, List[str]] = {
    "pytest": [r"import pytest", r"from pytest", r"@pytest\.", r"pytest\."],
    "unittest": [r"import unittest", r"from unittest", r"TestCase", r"unittest\."],
    "mock": [r"import mock", r"from mock", r"from unittest\.mock"],
    "hypothesis": [r"import hypothesis", r"from hypothesis", r"@hypothesis\."],
    "nose": [r"import nose", r"from nose"],
}


def is_python_file(filename: str) -> bool:
    """
    Check if a file is a Python file.
    
    Args:
        filename: File path.
        
    Returns:
        True if file ends with .py.
    """
    return filename.lower().endswith(".py")


def parse_github_url(github_url: str) -> Tuple[str, str, int]:
    """
    Parse GitHub PR URL to extract owner, repo, and PR number.
    
    Uses shared.utils.parse_pr_url internally.
    
    Args:
        github_url: GitHub PR URL (e.g., "https://github.com/owner/repo/pull/123").
        
    Returns:
        (owner, repo, pr_number) tuple.
        
    Raises:
        ValueError: If URL cannot be parsed.
    """
    result = parse_pr_url(github_url)
    if result is None:
        raise ValueError(f"Invalid GitHub PR URL: {github_url}")
    return result


def detect_test_frameworks(
    content: str,
    frameworks_dict: Optional[Dict[str, List[str]]] = None,
) -> List[str]:
    """
    Detect test frameworks used in code content.
    
    Args:
        content: File content as string.
        frameworks_dict: Dict of framework names to patterns (default: TEST_FRAMEWORKS).
        
    Returns:
        List of detected framework names.
    """
    if frameworks_dict is None:
        frameworks_dict = TEST_FRAMEWORKS
    
    if not content:
        return []
    
    detected: Set[str] = set()
    content_lower = content.lower()
    
    for framework, patterns in frameworks_dict.items():
        for pattern in patterns:
            if re.search(pattern, content_lower):
                detected.add(framework)
                break
    
    return sorted(list(detected))


def load_human_prs_csv(csv_path: Union[str, Path]) -> pd.DataFrame:
    """
    Load human PRs from CSV file as DataFrame.
    
    Args:
        csv_path: Path to CSV file.
        
    Returns:
        DataFrame with PR data.
    """
    try:
        return pd.read_csv(csv_path)
    except FileNotFoundError:
        logger.error(f"CSV file not found: {csv_path}")
        return pd.DataFrame()
    except Exception as e:
        logger.error(f"Failed to load CSV from {csv_path}: {e}")
        return pd.DataFrame()


def save_results_csv(results_df: pd.DataFrame, output_path: Union[str, Path]) -> None:
    """
    Save analysis results DataFrame to CSV file.
    
    Args:
        results_df: DataFrame with results.
        output_path: Path to save CSV to.
    """
    try:
        results_df.to_csv(output_path, index=False)
        logger.info(f"Saved {len(results_df)} results to {output_path}")
    except Exception as e:
        logger.error(f"Failed to save results to {output_path}: {e}")


def log_error(error_msg: str, log_file: Optional[str] = None) -> None:
    """Log error message to file and console."""
    logger.error(error_msg)
    
    if log_file:
        try:
            with open(log_file, "a") as f:
                f.write(f"{error_msg}\n")
        except Exception as e:
            logger.warning(f"Failed to write error log: {e}")


def log_progress(progress_msg: str, log_file: Optional[str] = None) -> None:
    """Log progress message to file and console."""
    logger.info(progress_msg)
    
    if log_file:
        try:
            with open(log_file, "a") as f:
                f.write(f"{progress_msg}\n")
        except Exception as e:
            logger.warning(f"Failed to write progress log: {e}")

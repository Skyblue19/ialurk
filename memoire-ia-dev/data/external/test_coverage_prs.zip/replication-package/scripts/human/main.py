"""Main orchestrator for analyzing Human PRs via GitHub API."""

import logging
import sys
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Optional

import pandas as pd

# Add parent directory for shared imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from human.config import (
    GITHUB_TOKEN,
    INPUT_CSV,
    OUTPUT_CSV,
    OUTPUT_DIR,
    ERROR_LOG,
    PROGRESS_LOG,
    TEST_FRAMEWORKS,
    BATCH_SIZE,
    CHECKPOINT_INTERVAL,
)
from human.utils import (
    parse_github_url,
    detect_test_frameworks,
    is_python_file,
    is_test_file,
    load_human_prs_csv,
    save_results_csv,
    log_error,
    log_progress,
)
# Use shared GitHub API client
from shared.github_api import GitHubAPIClient

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@dataclass
class HumanPRAnalysis:
    """Result of analyzing a single human PR."""
    pr_id: int
    pr_number: int
    html_url: str
    repo_url: str
    owner: str
    repo: str
    test_files_modified: int
    test_frameworks: str  # comma-separated
    python_files_modified: int
    total_commits: int
    test_additions: int
    test_deletions: int
    test_changes: int
    status: str  # success, error, no_tests
    error_message: Optional[str] = None


def analyze_pr(
    api_client: GitHubAPIClient,
    pr_row: pd.Series,
    pr_index: int = 0,
) -> HumanPRAnalysis:
    """
    Analyze a single human PR for test file modifications.
    
    Args:
        api_client: GitHub API client instance
        pr_row: Pandas Series with PR data
        pr_index: Index of PR for logging
        
    Returns:
        HumanPRAnalysis result object
    """
    try:
        # Extract PR info
        pr_id = int(pr_row["pr_id"])
        pr_number = int(pr_row["pr_number"])
        html_url = pr_row["html_url"]
        repo_url = pr_row["repo_url"]
        
        logger.debug(f"[PR {pr_index}] Analyzing PR {pr_id} ({pr_number}): {html_url}")
        
        # Parse GitHub URL
        owner, repo, pr_num = parse_github_url(html_url)
        logger.debug(f"[PR {pr_index}] Parsed URL: owner={owner}, repo={repo}, pr_num={pr_num}")
        
        # Fetch PR files (CORRECT endpoint: /pulls/{pr}/files)
        files = api_client.get_pr_files(owner, repo, pr_num)
        
        if files is None:
            return HumanPRAnalysis(
                pr_id=pr_id,
                pr_number=pr_number,
                html_url=html_url,
                repo_url=repo_url,
                owner=owner,
                repo=repo,
                test_files_modified=0,
                test_frameworks="",
                python_files_modified=0,
                total_commits=0,
                test_additions=0,
                test_deletions=0,
                test_changes=0,
                status="error",
                error_message="Failed to fetch PR files from GitHub API",
            )
        
        # Get commits count (for reference)
        commits = api_client.get_pr_commits(owner, repo, pr_num)
        total_commits = len(commits) if commits else 0
        logger.debug(f"[PR {pr_index}] Total commits in PR: {total_commits}")
        
        # Analyze PR files for test modifications
        test_files_modified = 0
        test_frameworks_set = set()
        python_files_modified = 0
        test_additions = 0
        test_deletions = 0
        test_changes = 0
        
        for file_obj in files:
            # Check if Python file
            if not is_python_file(file_obj.filename):
                continue
            
            python_files_modified += 1
            
            # Check if test file (by name OR by imports in patch)
            is_test_by_name = is_test_file(file_obj.filename)
            is_test_by_patch = False
            
            # Check patch for test framework imports
            if file_obj.patch:
                frameworks = detect_test_frameworks(file_obj.patch, TEST_FRAMEWORKS)
                if frameworks:
                    is_test_by_patch = True
                    test_frameworks_set.update(frameworks)
            
            # Count as test if ANY method detects it
            if is_test_by_name or is_test_by_patch:
                test_files_modified += 1
                test_additions += file_obj.additions
                test_deletions += file_obj.deletions
                test_changes += file_obj.changes
                
                logger.debug(f"    {file_obj.filename}: Test file detected")
        
        # Determine status
        if test_files_modified > 0:
            status = "success"
        else:
            status = "no_tests"
        
        return HumanPRAnalysis(
            pr_id=pr_id,
            pr_number=pr_number,
            html_url=html_url,
            repo_url=repo_url,
            owner=owner,
            repo=repo,
            test_files_modified=test_files_modified,
            test_frameworks=",".join(sorted(test_frameworks_set)),
            python_files_modified=python_files_modified,
            total_commits=len(commits),
            test_additions=test_additions,
            test_deletions=test_deletions,
            test_changes=test_changes,
            status=status,
        )
    
    except Exception as e:
        pr_id = int(pr_row.get("pr_id", -1))
        pr_number = int(pr_row.get("pr_number", -1))
        html_url = pr_row.get("html_url", "unknown")
        repo_url = pr_row.get("repo_url", "unknown")
        
        error_msg = f"Exception analyzing PR {pr_id}: {str(e)}"
        logger.error(error_msg)
        log_error(error_msg, ERROR_LOG)
        
        return HumanPRAnalysis(
            pr_id=pr_id,
            pr_number=pr_number,
            html_url=html_url,
            repo_url=repo_url,
            owner="unknown",
            repo="unknown",
            test_files_modified=0,
            test_frameworks="",
            python_files_modified=0,
            total_commits=0,
            test_additions=0,
            test_deletions=0,
            test_changes=0,
            status="error",
            error_message=str(e),
        )


def main():
    """Main entry point."""
    print("\n" + "="*80)
    print("Human PR Analysis - GitHub API")
    print("="*80)
    
    # Validate setup
    if not GITHUB_TOKEN:
        print("❌ ERROR: GITHUB_TOKEN not set. Please set it in .env file")
        return
    
    if not INPUT_CSV.exists():
        print(f"❌ ERROR: Input CSV not found: {INPUT_CSV}")
        return
    
    # Load input data
    print(f"\n📂 Loading human PRs from: {INPUT_CSV}")
    human_prs = load_human_prs_csv(INPUT_CSV)
    total_prs = len(human_prs)
    print(f"   Total PRs to analyze: {total_prs}")
    
    # Initialize API client
    print(f"\n🔐 Initializing GitHub API client...")
    api_client = GitHubAPIClient(token=GITHUB_TOKEN)
    
    # Check rate limits
    rate_limit_info = api_client.check_rate_limit()
    if rate_limit_info:
        remaining = rate_limit_info.get("rate_limit", {}).get("remaining", "unknown")
        limit = rate_limit_info.get("rate_limit", {}).get("limit", "unknown")
        print(f"   Rate limit: {remaining}/{limit}")
    
    # Process PRs
    log_file = OUTPUT_DIR / "debug.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.setLevel(logging.DEBUG)
    
    logger.info("="*80)
    logger.info("Starting Human PR Analysis")
    logger.info(f"Total PRs to analyze: {total_prs}")
    logger.info(f"Input CSV: {INPUT_CSV}")
    logger.info(f"Output CSV: {OUTPUT_CSV}")
    logger.info("="*80)
    
    print("\n[*] Analyzing PRs... (check debug.log for details)")
    results = []
    errors = 0
    no_tests = 0
    with_tests = 0
    
    for idx, (_, pr_row) in enumerate(human_prs.iterrows(), 1):
        # Check rate limit before processing
        if api_client.is_rate_limited():
            logger.warning(f"Rate limit approaching: {api_client.get_rate_limit_info()}")
            print(f"\n⚠️  WARNING: {api_client.get_rate_limit_info()}")
            print(f"   Processed {idx-1}/{total_prs} PRs")
            print(f"   Pausing to avoid rate limit...")
            break
        
        # Print progress
        if idx % BATCH_SIZE == 0 or idx == 1:
            pct = (idx / total_prs) * 100
            print(f"   [{idx}/{total_prs}] ({pct:.1f}%) - {api_client.get_rate_limit_info()}")
        
        # Analyze PR
        try:
            analysis = analyze_pr(api_client, pr_row, idx)
            results.append(analysis)
        except Exception as e:
            logger.error(f"[PR {idx}] Unexpected error: {str(e)}", exc_info=True)
            raise
        
        # Update counters
        if analysis.status == "error":
            errors += 1
        elif analysis.status == "no_tests":
            no_tests += 1
        else:
            with_tests += 1
        
        # Save checkpoint
        if idx % CHECKPOINT_INTERVAL == 0:
            checkpoint_df = pd.DataFrame([asdict(r) for r in results])
            save_results_csv(checkpoint_df, OUTPUT_CSV)
            log_progress(f"Checkpoint at PR {idx}/{total_prs}", PROGRESS_LOG)
    
    # Save final results
    print(f"\n💾 Saving results...")
    results_df = pd.DataFrame([asdict(r) for r in results])
    save_results_csv(results_df, OUTPUT_CSV)
    
    # Print summary
    print(f"\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    print(f"Total PRs analyzed: {total_prs}")
    print(f"  ✓ With test files: {with_tests}")
    print(f"  ○ No test files: {no_tests}")
    print(f"  ✗ Errors: {errors}")
    
    # Test files summary
    test_files_total = results_df[results_df["status"] == "success"]["test_files_modified"].sum()
    print(f"\nTest files modified: {test_files_total}")
    
    # Framework summary
    frameworks_counts = {}
    for _, row in results_df.iterrows():
        if row["test_frameworks"]:
            for fw in row["test_frameworks"].split(","):
                frameworks_counts[fw] = frameworks_counts.get(fw, 0) + 1
    
    if frameworks_counts:
        print(f"\nTest frameworks detected:")
        for fw, count in sorted(frameworks_counts.items(), key=lambda x: x[1], reverse=True):
            print(f"  {fw}: {count}")
    
    print(f"\n✓ Output saved to: {OUTPUT_CSV}")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()

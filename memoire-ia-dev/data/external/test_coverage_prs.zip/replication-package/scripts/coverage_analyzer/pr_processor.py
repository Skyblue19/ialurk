"""
PR processing workflow: orchestrates coverage analysis per PR.
"""

import csv
import fcntl
import logging
import subprocess
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from coverage_analyzer.config import (
    CSV_COLUMNS,
    ERROR_MESSAGE_MAX_LENGTH,
    ERRORS_LOG,
    MIN_DISK_SPACE_GB,
    OUTPUT_CSV,
    STATUS_CHECKOUT_FAILED,
    STATUS_CLONE_FAILED,
    STATUS_COVERAGE_PARSE_FAILED,
    STATUS_DISK_SPACE_ERROR,
    STATUS_INSTALL_FAILED,
    STATUS_SUCCESS,
    STATUS_TEST_FAILED,
    STATUS_TEST_FILE_NOT_FOUND,
    STATUS_TIMEOUT,
)
from coverage_analyzer.coverage_runner import CoverageRunner
from coverage_analyzer.diff_coverage import calculate_diff_coverage, DiffCoverageResult
from coverage_analyzer.failure_diagnosis import diagnose_failure, diagnosis_to_json
from coverage_analyzer.git_manager import GitRepositoryManager

logger = logging.getLogger(__name__)


class PRCoverageAnalyzer:
    """Analyzes test coverage changes across PR commits."""

    def __init__(self, git_manager: GitRepositoryManager, github_api, dry_run: bool = False, output_csv: Path = None):
        """
        Initialize PRCoverageAnalyzer.
        
        Args:
            git_manager: GitRepositoryManager instance.
            github_api: GitHubAPIClient instance.
            dry_run: If True, don't write outputs.
            output_csv: Path to output CSV file. Defaults to OUTPUT_CSV from config.
        """
        self.git_manager = git_manager
        self.github_api = github_api
        self.dry_run = dry_run
        self.output_csv = output_csv or OUTPUT_CSV
        self.output_lock = threading.Lock()
        self.stats = {
            "prs_processed": 0,
            "files_analyzed": 0,
            "successful_runs": 0,
            "failed_runs": 0,
            "clone_failures": 0,
            "install_failures": 0,
            "test_failures": 0,
            "timeouts": 0,
            "parse_failures": 0,
            "disk_space_errors": 0,
        }
        self.start_time = time.time()

    def load_existing_results(self) -> Set[Tuple[str, str, str]]:
        """
        Load existing results to support resume functionality.
        
        Returns:
            Set of (pr_id, test_file_path, after_commit_sha) tuples already processed.
        """
        existing = set()
        if self.output_csv.exists():
            try:
                with open(self.output_csv, "r") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        key = (row.get("pr_id", ""), row.get("test_file_path", ""), row.get("after_commit_sha", ""))
                        existing.add(key)
                logger.info(f"Loaded {len(existing)} existing results for resume")
            except Exception as e:
                logger.warning(f"Failed to load existing results: {e}")
        return existing

    def _append_result(self, result: Dict):
        """
        Append a result row to the output CSV with file locking.
        
        Args:
            result: Dictionary with result data.
        """
        if self.dry_run:
            logger.info(f"[DRY-RUN] Would write result: {result['pr_id']}")
            return

        with self.output_lock:
            try:
                # Write header if file doesn't exist
                if not self.output_csv.exists():
                    with open(self.output_csv, "w", newline="") as f:
                        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
                        writer.writeheader()

                # Filter result to only include columns in CSV_COLUMNS
                filtered_result = {col: result.get(col, "") for col in CSV_COLUMNS}

                # Append result with file lock
                with open(self.output_csv, "a", newline="") as f:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                    try:
                        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
                        writer.writerow(filtered_result)
                    finally:
                        fcntl.flock(f.fileno(), fcntl.LOCK_UN)

                logger.debug(f"Wrote result for PR {result['pr_id']}, file {result['test_file_path']}")
            except Exception as e:
                logger.error(f"Failed to append result: {e}")

    def _log_error(self, pr_id: str, error_msg: str, traceback_str: str = ""):
        """
        Log error with optional traceback.
        
        Args:
            pr_id: PR ID.
            error_msg: Error message.
            traceback_str: Full traceback.
        """
        if self.dry_run:
            return

        try:
            with open(ERRORS_LOG, "a") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                try:
                    f.write(f"\n[{datetime.now().isoformat()}] PR {pr_id}: {error_msg}\n")
                    if traceback_str:
                        f.write(f"Traceback:\n{traceback_str}\n")
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except Exception as e:
            logger.warning(f"Failed to write error log: {e}")

    def _get_disk_space_gb(self) -> float:
        """Get available disk space in GB."""
        import shutil

        usage = shutil.disk_usage("/")
        return usage.free / (1024**3)

    def analyze_pr(
        self,
        pr: Dict,
        test_file_commits: Dict[str, List[Tuple[int, str, str, str]]],
    ) -> int:
        """
        Analyze test coverage for a single PR across all test file modifications.
        
        Args:
            pr: PR metadata dictionary.
            test_file_commits: Dict mapping test_file_path -> [(seq_num, status, before_sha, after_sha)].
        
        Returns:
            Number of successful coverage runs.
        """
        pr_id = str(pr.get("pr_id", ""))
        pr_number = str(pr.get("pr_number", ""))
        # Support both naming conventions: repo_owner/owner and repo_name/repo
        repo_owner = str(pr.get("repo_owner", "") or pr.get("owner", ""))
        repo_name = str(pr.get("repo_name", "") or pr.get("repo", ""))
        html_url = str(pr.get("html_url", ""))

        if not all([pr_id, repo_owner, repo_name]):
            logger.warning(f"Invalid PR metadata: {pr}")
            return 0

        # Fetch all files changed in the PR (for diff-coverage calculation)
        pr_files = None
        if self.github_api:
            try:
                logger.info(f"📄 [PR FILES] Fetching files changed in PR #{pr_number}...")
                pr_files = self.github_api.get_pr_files(repo_owner, repo_name, int(pr_number))
                if pr_files:
                    python_files = [f for f in pr_files if f.filename.endswith('.py')]
                    logger.info(f"📄 [PR FILES] Found {len(pr_files)} files ({len(python_files)} Python files)")
                else:
                    logger.warning(f"📄 [PR FILES] Failed to fetch PR files")
            except Exception as e:
                logger.warning(f"📄 [PR FILES] Error fetching PR files: {e}")
                pr_files = None

        # Ensure repo is in cache first
        clone_start = time.time()
        logger.info(f"🔄 [CLONE] Ensuring {repo_owner}/{repo_name} is cached...")
        cache_path, retry_count = self.git_manager.clone_repository(repo_owner, repo_name)
        clone_time = time.time() - clone_start

        if not cache_path:
            clone_error_msg = f"Failed to clone repository {repo_owner}/{repo_name} after {retry_count} retries in {clone_time:.2f}s"
            logger.error(f"❌ [CLONE] {clone_error_msg}")
            for test_file, commits_list in test_file_commits.items():
                for seq_num, file_status, before_sha, after_sha in commits_list:
                    result = self._build_result(
                        pr, test_file, file_status, before_sha, after_sha or "",
                        status=STATUS_CLONE_FAILED,
                        error_message=clone_error_msg,
                    )
                    self._append_result(result)
            return 0

        logger.info(f"✅ [CLONE] Cache ready in {clone_time:.2f}s")
        
        # Create isolated working copy for this PR
        working_start = time.time()
        logger.info(f"📂 [WORKING] Creating isolated working copy for PR {pr_id}...")
        repo_path = self.git_manager.create_working_copy(repo_owner, repo_name, pr_id)
        working_time = time.time() - working_start
        
        if not repo_path:
            working_error_msg = f"Failed to create working copy for {repo_owner}/{repo_name} PR {pr_id} after {working_time:.2f}s"
            logger.error(f"❌ [WORKING] {working_error_msg}")
            for test_file, commits_list in test_file_commits.items():
                for seq_num, file_status, before_sha, after_sha in commits_list:
                    result = self._build_result(
                        pr, test_file, file_status, before_sha, after_sha or "",
                        status=STATUS_CLONE_FAILED,
                        error_message=working_error_msg,
                    )
                    self._append_result(result)
            return 0
        
        logger.info(f"✅ [WORKING] Working copy ready in {working_time:.2f}s")
        success_count = 0

        try:
            for test_file_path, commits_list in test_file_commits.items():
                logger.info(f"📋 [FILE] Processing {test_file_path} ({len(commits_list)} modification(s))")

                for seq_num, file_status, before_sha, after_sha in commits_list:
                    # Check disk space
                    disk_free = self._get_disk_space_gb()
                    if disk_free < MIN_DISK_SPACE_GB:
                        logger.error(f"Insufficient disk space: {disk_free:.2f}GB < {MIN_DISK_SPACE_GB}GB")
                        result = self._build_result(
                            pr,
                            test_file_path,
                            file_status,
                            before_sha,
                            after_sha,
                            status=STATUS_DISK_SPACE_ERROR,
                        )
                        self._append_result(result)
                        continue

                    # Analyze AFTER commit only (we only need diff-coverage of final state)
                    after_coverage = None
                    checkout_start = time.time()
                    logger.info(f"➡️  [COVERAGE] Checking out {after_sha[:8]} for {test_file_path}")
                    if self.git_manager.checkout_commit(repo_path, after_sha):
                        checkout_time = time.time() - checkout_start
                        logger.info(f"✅ [COVERAGE] Checkout done in {checkout_time:.2f}s")
                        logger.info(f"🧪 [COVERAGE] Running coverage at {after_sha[:8]}...")
                        after_coverage, after_time = self._run_coverage_at_commit(
                            repo_path, test_file_path, pr_id=pr_id, pr_files=pr_files
                        )
                        if after_coverage and after_coverage.get("status") == STATUS_SUCCESS:
                            diff_pct = after_coverage.get("diff_coverage_percent", "N/A")
                            logger.info(f"✅ [COVERAGE] Diff-coverage: {diff_pct}%")
                        else:
                            logger.warning(f"⚠️  [COVERAGE] Failed: {after_coverage.get('status') if after_coverage else 'None'}")
                    else:
                        logger.warning(f"❌ [COVERAGE] Failed to checkout {after_sha[:8]}")
                        checkout_diag = diagnose_failure(
                            status=STATUS_CHECKOUT_FAILED,
                            error_message=f"Failed to checkout commit {after_sha[:8]}",
                            stdout="",
                            stderr=f"Git checkout failed for commit {after_sha}. The commit may not exist in the repository or the working copy may be corrupted.",
                            pytest_exit_code=-1,
                        )
                        after_coverage = {
                            "status": STATUS_CHECKOUT_FAILED,
                            "error_message": f"Failed to checkout commit {after_sha[:8]}",
                            "failure_diagnosis": diagnosis_to_json(checkout_diag),
                        }
                    self.git_manager.cleanup_checkout(repo_path)

                    # Build result
                    if after_coverage and after_coverage.get("status") == STATUS_SUCCESS:
                        success_count += 1

                    result = self._build_result(
                        pr,
                        test_file_path,
                        file_status,
                        before_sha,
                        after_sha,
                        after_coverage=after_coverage,
                    )
                    self._append_result(result)

        finally:
            # Clean up the working copy (cache remains for future PRs)
            logger.info(f"🧹 [CLEANUP] Cleaning up working copy for PR {pr_id}...")
            self.git_manager.cleanup_working_copy(pr_id)
            logger.info(f"✨ [COMPLETE] PR {pr_id} analysis completed ({success_count} successful)")

        return success_count

    def _run_coverage_at_commit(
        self,
        repo_path: Path,
        test_file_path: str,
        pr_id: str = None,
        pr_files: List = None
    ) -> Tuple[Optional[Dict], float]:
        """
        Run coverage for a test file at the current commit.
        
        Args:
            repo_path: Path to repository.
            test_file_path: Path to test file.
            pr_id: PR ID for logging purposes.
            pr_files: List of files changed in the PR (for diff-coverage calculation).
        
        Returns:
            Tuple of (coverage_result_dict, execution_time_seconds).
        """
        runner = CoverageRunner(repo_path, pr_id=pr_id)
        start_time = time.time()

        try:
            # Check if test file exists in this commit
            test_file_full_path = repo_path / test_file_path
            if not test_file_full_path.exists():
                logger.warning(f"[COVERAGE] ❌ Test file not found: {test_file_path}")
                return {
                    "status": STATUS_TEST_FILE_NOT_FOUND,
                    "error_message": f"Test file not found: {test_file_path}",
                    "execution_time_seconds": time.time() - start_time,
                }, time.time() - start_time

            # Detect versions
            logger.info(f"[COVERAGE] Detecting Python version...")
            detect_start = time.time()
            detected_py, used_py = runner.detect_python_version()
            logger.info(f"[COVERAGE] ✅ Python detected in {time.time() - detect_start:.2f}s: {detected_py} / {used_py}")
            
            logger.info(f"[COVERAGE] Detecting test framework...")
            fw_start = time.time()
            detected_fw, used_fw = runner.detect_test_framework()
            logger.info(f"[COVERAGE] ✅ Framework detected in {time.time() - fw_start:.2f}s: {detected_fw} / {used_fw}")

            # Create venv
            logger.info(f"[COVERAGE] Getting HEAD commit SHA...")
            sha_start = time.time()
            sha = subprocess.run(
                ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                check=True,
                timeout=10,
            ).stdout.strip()
            logger.info(f"[COVERAGE] ✅ HEAD SHA retrieved in {time.time() - sha_start:.2f}s: {sha[:8]}")

            logger.info(f"[COVERAGE] Creating virtual environment...")
            venv_start = time.time()
            if not runner.create_venv(sha):
                venv_fail_time = time.time() - venv_start
                logger.error(f"[COVERAGE] ❌ venv creation failed after {venv_fail_time:.2f}s")
                return {
                    "status": STATUS_INSTALL_FAILED,
                    "error_message": "Failed to create venv",
                    "python_version_detected": detected_py,
                    "python_version_used": used_py,
                    "test_framework_detected": detected_fw,
                    "test_framework_used": used_fw,
                    "execution_time_seconds": time.time() - start_time,
                }, time.time() - start_time
            venv_time = time.time() - venv_start
            logger.info(f"[COVERAGE] ✅ venv created in {venv_time:.2f}s")

            # Install dependencies
            logger.info(f"[COVERAGE] Installing dependencies...")
            install_start = time.time()
            if not runner.install_dependencies(sha=sha):
                install_fail_time = time.time() - install_start
                logger.error(f"[COVERAGE] ❌ install failed after {install_fail_time:.2f}s")
                return {
                    "status": STATUS_INSTALL_FAILED,
                    "error_message": "Failed to install dependencies",
                    "python_version_detected": detected_py,
                    "python_version_used": used_py,
                    "test_framework_detected": detected_fw,
                    "test_framework_used": used_fw,
                    "execution_time_seconds": time.time() - start_time,
                }, time.time() - start_time
            install_time = time.time() - install_start
            logger.info(f"[COVERAGE] ✅ install completed in {install_time:.2f}s")

            # Run coverage
            logger.info(f"[COVERAGE] Running coverage on {test_file_path}...")
            test_start = time.time()
            success, coverage_data, warnings, stderr, stdout, pytest_exit_code = runner.run_coverage(test_file_path)
            test_time = time.time() - test_start
            logger.info(f"[COVERAGE] ✅ coverage run completed in {test_time:.2f}s (success={success}, pytest_exit={pytest_exit_code})")

            if not success or not coverage_data:
                # Use stdout if stderr is empty
                error_output = stderr if stderr.strip() else stdout[:500]
                
                # Determine the correct status based on pytest exit code
                # pytest exit codes: 0=passed, 1=tests failed, 2=interrupted, 3=internal error, 4=usage error, 5=no tests
                if pytest_exit_code == 0:
                    # Tests passed but coverage parsing failed
                    status = STATUS_COVERAGE_PARSE_FAILED
                    logger.warning(f"[COVERAGE] Tests passed (exit=0) but coverage parsing failed")
                elif pytest_exit_code == -2:
                    # Timeout
                    status = STATUS_TIMEOUT
                elif pytest_exit_code < 0:
                    # Other error (exception, etc)
                    status = STATUS_TEST_FAILED
                else:
                    # Tests actually failed (exit code 1-5)
                    status = STATUS_TEST_FAILED
                
                # Generate detailed failure diagnosis
                diagnosis = diagnose_failure(
                    status=status,
                    error_message=error_output,
                    stdout=stdout,
                    stderr=stderr,
                    pytest_exit_code=pytest_exit_code,
                    install_log_path=str(runner.install_log_path) if runner.install_log_path else "",
                )
                
                return {
                    "status": status,
                    "error_message": error_output[:ERROR_MESSAGE_MAX_LENGTH],
                    "failure_diagnosis": diagnosis_to_json(diagnosis),
                    "warnings": ",".join(warnings),
                    "python_version_detected": detected_py,
                    "python_version_used": used_py,
                    "test_framework_detected": detected_fw,
                    "test_framework_used": used_fw,
                    "execution_time_seconds": time.time() - start_time,
                }, time.time() - start_time

            # Build success result with diff-coverage only
            result_dict = {
                "status": STATUS_SUCCESS,
                "python_version_detected": detected_py,
                "python_version_used": used_py,
                "test_framework_detected": detected_fw,
                "test_framework_used": used_fw,
                "warnings": ",".join(warnings),
                "execution_time_seconds": time.time() - start_time,
            }
            
            # Calculate diff-coverage (the main metric for RQ)
            if pr_files and coverage_data.get("files"):
                try:
                    logger.info(f"[DIFF-COV] Calculating diff-coverage for {len(pr_files)} PR files...")
                    diff_result = calculate_diff_coverage(
                        coverage_data,
                        pr_files,
                        repo_path=str(repo_path)
                    )
                    # Add diff-coverage metrics to result
                    result_dict.update(diff_result.to_dict())
                    logger.info(
                        f"[DIFF-COV] ✅ Diff coverage: {diff_result.diff_coverage_percent:.1f}% "
                        f"({diff_result.total_covered_lines}/{diff_result.total_changed_lines} lines)"
                    )
                except Exception as e:
                    logger.warning(f"[DIFF-COV] Failed to calculate diff-coverage: {e}")
                    # Set empty diff-coverage values on failure
                    result_dict.update({
                        "diff_coverage_percent": None,
                        "diff_changed_lines": 0,
                        "diff_covered_lines": 0,
                        "diff_python_files": 0,
                        "diff_files_with_coverage": 0,
                        "diff_uncovered_files": "",
                    })
            else:
                logger.warning("[DIFF-COV] No PR files or coverage data available")
                result_dict.update({
                    "diff_coverage_percent": None,
                    "diff_changed_lines": 0,
                    "diff_covered_lines": 0,
                    "diff_python_files": 0,
                    "diff_files_with_coverage": 0,
                    "diff_uncovered_files": "",
                })
            
            return result_dict, time.time() - start_time

        except Exception as e:
            logger.error(f"Exception in coverage run: {e}", exc_info=True)
            # Generate diagnosis for exception
            diagnosis = diagnose_failure(
                status=STATUS_TEST_FAILED,
                error_message=str(e),
                stdout="",
                stderr=str(e),
                pytest_exit_code=-3,
            )
            return {
                "status": STATUS_TEST_FAILED,
                "error_message": str(e)[:ERROR_MESSAGE_MAX_LENGTH],
                "failure_diagnosis": diagnosis_to_json(diagnosis),
                "execution_time_seconds": time.time() - start_time,
            }, time.time() - start_time
        finally:
            runner.cleanup_venv()

    def _build_result(
        self,
        pr: Dict,
        test_file_path: str,
        file_status: str,
        before_sha: Optional[str],
        after_sha: str,
        after_coverage: Optional[Dict] = None,
        status: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> Dict:
        """
        Build a result dictionary for CSV output.
        
        Args:
            pr: PR metadata.
            test_file_path: Test file path.
            file_status: "created" or "modified".
            before_sha: Commit SHA before change (or None).
            after_sha: Commit SHA after change.
            after_coverage: Coverage dict with diff-coverage metrics.
            status: Override status.
            error_message: Override error message.
        
        Returns:
            Dictionary ready for CSV output.
        """
        result = {
            "pr_id": pr.get("pr_id", ""),
            "pr_number": pr.get("pr_number", ""),
            "repo_owner": pr.get("repo_owner", "") or pr.get("owner", ""),
            "repo_name": pr.get("repo_name", "") or pr.get("repo", ""),
            "html_url": pr.get("html_url", ""),
            "agent": pr.get("agent", ""),  # AI agent name (empty for human PRs)
            "authorship_type": pr.get("authorship_type", ""),  # ai_only, coauthor, or empty
            "pr_state": pr.get("pr_state", ""),  # open, closed
            "pr_merged": pr.get("pr_merged", ""),  # true, false
            "test_file_path": test_file_path,
            "file_status": file_status,
            "before_commit_sha": before_sha or "",
            "after_commit_sha": after_sha or "",
            "timestamp": datetime.now().isoformat(),
        }

        # Add coverage data (diff-coverage metrics and environment info)
        if after_coverage:
            for k, v in after_coverage.items():
                # Skip internal fields
                if k in ["status", "error_message", "warnings", "files", "failure_diagnosis"]:
                    continue
                result[k] = v

        # Set status, error, and diagnosis
        result["status"] = status or (after_coverage.get("status", STATUS_TEST_FAILED) if after_coverage else STATUS_TEST_FAILED)
        result["error_message"] = error_message or (after_coverage.get("error_message", "") if after_coverage else "")
        result["warnings"] = after_coverage.get("warnings", "") if after_coverage else ""
        result["failure_diagnosis"] = after_coverage.get("failure_diagnosis", "") if after_coverage else ""

        return result

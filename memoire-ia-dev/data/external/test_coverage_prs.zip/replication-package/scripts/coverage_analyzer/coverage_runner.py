"""
Coverage execution engine for running coverage.py on test files.
Detects Python versions, test frameworks, creates virtual environments, and parses coverage reports.
"""

import json
import logging
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from coverage_analyzer.config import (
    FRAMEWORK_PRIORITY,
    INCLUDE_BRANCH_COVERAGE,
    INSTALL_TIMEOUT,
    LOGS_DIR,
    PIP_CACHE_DIR,
    TEST_TIMEOUT,
    WARN_EMPTY,
    WARN_IMPORT_ERRORS,
    WARN_PARTIAL_COVERAGE,
    WARN_SKIPPED_TESTS,
)

logger = logging.getLogger(__name__)

# Global lock for venv creation to prevent race conditions
_venv_creation_locks = {}
_venv_lock_dict_lock = threading.Lock()


class CoverageRunner:
    """Runs coverage.py on test files and parses results."""

    def __init__(self, repo_path: Path, pr_id: str = None):
        """
        Initialize CoverageRunner.
        
        Args:
            repo_path: Path to repository.
            pr_id: PR ID for logging purposes.
        """
        self.repo_path = repo_path
        self.pr_id = pr_id or "unknown"
        self.venv_path = None
        self.python_version = None
        self.test_framework = None
        self.install_log_path = None
        self.freeze_log_path = None

    def detect_python_version(self) -> Tuple[Optional[str], str]:
        """
        Detect Python version from pyproject.toml, setup.py, .python-version.
        
        Returns:
            Tuple of (detected_version, used_version). detected_version is from metadata,
            used_version is the actual Python executable version.
        """
        detected = None

        # Check pyproject.toml
        pyproject = self.repo_path / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text()
                match = re.search(r'requires-python\s*=\s*["\']([^"\']+)["\']', content)
                if match:
                    detected = match.group(1)
                    logger.info(f"Detected Python requirement from pyproject.toml: {detected}")
            except Exception as e:
                logger.debug(f"Failed to parse pyproject.toml: {e}")

        # Check setup.py
        if not detected:
            setup_py = self.repo_path / "setup.py"
            if setup_py.exists():
                try:
                    content = setup_py.read_text()
                    match = re.search(r'python_requires\s*=\s*["\']([^"\']+)["\']', content)
                    if match:
                        detected = match.group(1)
                        logger.info(f"Detected Python requirement from setup.py: {detected}")
                except Exception as e:
                    logger.debug(f"Failed to parse setup.py: {e}")

        # Check .python-version
        if not detected:
            py_version_file = self.repo_path / ".python-version"
            if py_version_file.exists():
                try:
                    detected = py_version_file.read_text().strip().split("\n")[0]
                    logger.info(f"Detected Python version from .python-version: {detected}")
                except Exception as e:
                    logger.debug(f"Failed to read .python-version: {e}")

        # Get actual system Python version
        try:
            result = subprocess.run(
                ["python3", "--version"],
                capture_output=True,
                text=True,
                timeout=10,
                check=True,
            )
            used = result.stdout.strip().replace("Python ", "")
            logger.info(f"Using system Python version: {used}")
            return detected or "not-specified", used
        except Exception as e:
            logger.error(f"Failed to detect system Python: {e}")
            return detected or "not-specified", "unknown"

    def detect_test_framework(self) -> Tuple[Optional[str], str]:
        """
        Detect test framework by checking pytest.ini, tox.ini, setup.cfg, pyproject.toml.
        
        Returns:
            Tuple of (detected_framework, framework_to_use).
        """
        # Check pytest.ini
        if (self.repo_path / "pytest.ini").exists():
            logger.info("Detected pytest framework (pytest.ini found)")
            return "pytest", "pytest"

        # Check tox.ini
        tox_ini = self.repo_path / "tox.ini"
        if tox_ini.exists():
            try:
                content = tox_ini.read_text()
                if "pytest" in content:
                    logger.info("Detected pytest framework (tox.ini references pytest)")
                    return "pytest", "pytest"
                if "unittest" in content:
                    logger.info("Detected unittest framework (tox.ini references unittest)")
                    return "unittest", "unittest"
            except Exception as e:
                logger.debug(f"Failed to parse tox.ini: {e}")

        # Check setup.cfg
        setup_cfg = self.repo_path / "setup.cfg"
        if setup_cfg.exists():
            try:
                content = setup_cfg.read_text()
                if "[tool:pytest]" in content:
                    logger.info("Detected pytest framework (setup.cfg [tool:pytest])")
                    return "pytest", "pytest"
                if "[test]" in content:
                    logger.info("Detected unittest framework (setup.cfg [test])")
                    return "unittest", "unittest"
            except Exception as e:
                logger.debug(f"Failed to parse setup.cfg: {e}")

        # Check pyproject.toml
        pyproject = self.repo_path / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text()
                if "[tool.pytest" in content:
                    logger.info("Detected pytest framework (pyproject.toml [tool.pytest])")
                    return "pytest", "pytest"
            except Exception as e:
                logger.debug(f"Failed to parse pyproject.toml: {e}")

        # Try requirements files for framework clues
        for req_file in [self.repo_path / "requirements.txt", self.repo_path / "requirements-dev.txt"]:
            if req_file.exists():
                try:
                    content = req_file.read_text().lower()
                    for framework in FRAMEWORK_PRIORITY:
                        if framework in content:
                            logger.info(f"Detected {framework} in {req_file.name}")
                            return framework, framework
                except Exception as e:
                    logger.debug(f"Failed to read {req_file}: {e}")

        # Default to pytest
        logger.info("Defaulting to pytest framework")
        return None, "pytest"

    def create_venv(self, sha: str) -> bool:
        """
        Create a Python virtual environment for the commit.
        
        Args:
            sha: Commit SHA (used to name venv).
        
        Returns:
            True if successful, False otherwise.
        """
        venv_name = f".venv_cov_{sha[:8]}"
        # Store venv in the repo directory itself (not in shared output dir)
        # This avoids race conditions when multiple containers access same output dir
        self.venv_path = self.repo_path / venv_name

        try:
            logger.info(f"Creating venv: {venv_name}")
            subprocess.run(
                ["python3", "-m", "venv", str(self.venv_path)],
                timeout=60,
                capture_output=True,
                check=True,
                cwd=str(self.repo_path),
            )
            logger.info(f"Created venv: {self.venv_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to create venv: {e}")
            return False

    def get_venv_python(self) -> Path:
        """Get path to Python executable in venv."""
        return self.venv_path / "bin" / "python"

    def install_dependencies(self, sha: str = None) -> bool:
        """
        Install dependencies in venv with detailed logging.
        
        Args:
            sha: Commit SHA for naming log files.
        
        Returns:
            True if successful, False otherwise.
        """
        if not self.venv_path or not self.venv_path.exists():
            logger.error("venv not created yet")
            return False

        python_exe = self.get_venv_python()
        sha_short = (sha or "unknown")[:8]
        
        # Create log directory for this PR
        pr_log_dir = LOGS_DIR / str(self.pr_id)
        pr_log_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize log files
        self.install_log_path = pr_log_dir / f"install_{sha_short}.txt"
        self.freeze_log_path = pr_log_dir / f"freeze_{sha_short}.txt"
        
        install_log_content = []
        install_log_content.append(f"=== Install Log for PR {self.pr_id}, SHA {sha_short} ===")
        install_log_content.append(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        install_log_content.append(f"Repo path: {self.repo_path}")
        install_log_content.append("="*60)

        # Try pip install -e .[dev] or -e .[test] first (for test dependencies)
        # Note: [dev] is more common than [test], so try that first
        extras_to_try = [
            (".[dev]", "with dev extras"),
            (".[test]", "with test extras"),
            (".", "base package"),
        ]
        
        installed_package = False
        for extra, desc in extras_to_try:
            try:
                logger.info(f"⬇️ Installing package with 'pip install -e {extra}' ({desc})...")
                install_log_content.append(f"\n--- Attempting: pip install -e {extra} ({desc}) ---")
                install_start = time.time()
                result = subprocess.run(
                    [str(python_exe), "-m", "pip", "install", "-e", extra],
                    timeout=INSTALL_TIMEOUT,
                    capture_output=True,
                    text=True,
                    cwd=str(self.repo_path),
                    env={**dict(subprocess.os.environ), "PIP_CACHE_DIR": str(PIP_CACHE_DIR)},
                )
                install_time = time.time() - install_start
                install_log_content.append(f"Exit code: {result.returncode}")
                install_log_content.append(f"Time: {install_time:.1f}s")
                install_log_content.append(f"STDOUT:\n{result.stdout}")
                install_log_content.append(f"STDERR:\n{result.stderr}")
                
                if result.returncode == 0:
                    logger.info(f"✅ Package installed successfully {desc} ({install_time:.1f}s)")
                    installed_package = True
                    break
                else:
                    logger.debug(f"pip install -e {extra} failed: {result.stderr[:300]}")
            except subprocess.TimeoutExpired:
                install_log_content.append(f"TIMEOUT after {INSTALL_TIMEOUT}s")
                logger.debug(f"pip install -e {extra} timeout")
            except Exception as e:
                install_log_content.append(f"EXCEPTION: {e}")
                logger.debug(f"pip install -e {extra} error: {e}")

        # Fallback to requirements.txt if package install failed
        if not installed_package:
            req_files = [
                self.repo_path / "requirements.txt",
                self.repo_path / "requirements-dev.txt",
                self.repo_path / "requirements-test.txt",
            ]

            for req_file in req_files:
                if req_file.exists():
                    try:
                        logger.info(f"Installing from {req_file.name}")
                        install_log_content.append(f"\n--- Attempting: pip install -r {req_file.name} ---")
                        result = subprocess.run(
                            [str(python_exe), "-m", "pip", "install", "-r", str(req_file)],
                            timeout=INSTALL_TIMEOUT,
                            capture_output=True,
                            text=True,
                            cwd=str(self.repo_path),
                            env={**dict(subprocess.os.environ), "PIP_CACHE_DIR": str(PIP_CACHE_DIR)},
                        )
                        install_log_content.append(f"Exit code: {result.returncode}")
                        install_log_content.append(f"STDOUT:\n{result.stdout}")
                        install_log_content.append(f"STDERR:\n{result.stderr}")
                        
                        if result.returncode == 0:
                            logger.info(f"Dependencies installed from {req_file.name}")
                            installed_package = True
                            break
                        else:
                            logger.debug(f"Failed with {req_file.name}: {result.stderr[:300]}")
                    except Exception as e:
                        install_log_content.append(f"EXCEPTION: {e}")
                        logger.debug(f"Failed with {req_file.name}: {e}")

        # Now install test framework and coverage regardless
        # These are essential for our coverage analysis
        test_tools = [
            ("pytest", "pytest test framework"),
            ("coverage", "coverage tool"),
        ]
        
        for tool, desc in test_tools:
            try:
                logger.info(f"⬇️ Installing {desc}...")
                install_log_content.append(f"\n--- Installing essential: {tool} ---")
                result = subprocess.run(
                    [str(python_exe), "-m", "pip", "install", tool],
                    timeout=INSTALL_TIMEOUT,
                    capture_output=True,
                    text=True,
                    cwd=str(self.repo_path),
                    env={**dict(subprocess.os.environ), "PIP_CACHE_DIR": str(PIP_CACHE_DIR)},
                )
                install_log_content.append(f"Exit code: {result.returncode}")
                if result.returncode == 0:
                    logger.info(f"✅ {desc} installed successfully")
                else:
                    install_log_content.append(f"STDERR: {result.stderr}")
                    logger.warning(f"⚠️ Failed to install {desc}: {result.stderr[:200]}")
            except Exception as e:
                install_log_content.append(f"EXCEPTION: {e}")
                logger.warning(f"⚠️ Exception installing {desc}: {e}")

        # Capture pip freeze for reproducibility
        try:
            freeze_result = subprocess.run(
                [str(python_exe), "-m", "pip", "freeze"],
                timeout=30,
                capture_output=True,
                text=True,
                cwd=str(self.repo_path),
            )
            if freeze_result.returncode == 0:
                with open(self.freeze_log_path, "w") as f:
                    f.write(f"# pip freeze for PR {self.pr_id}, SHA {sha_short}\n")
                    f.write(f"# Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(freeze_result.stdout)
                logger.info(f"📦 Saved pip freeze to {self.freeze_log_path}")
                install_log_content.append(f"\n--- pip freeze saved to {self.freeze_log_path} ---")
        except Exception as e:
            logger.warning(f"Failed to capture pip freeze: {e}")
            install_log_content.append(f"\n--- pip freeze FAILED: {e} ---")

        # Write install log
        try:
            with open(self.install_log_path, "w") as f:
                f.write("\n".join(install_log_content))
            logger.info(f"📝 Saved install log to {self.install_log_path}")
        except Exception as e:
            logger.warning(f"Failed to write install log: {e}")

        # If we at least have pytest and coverage, success
        # (check for pytest module)
        try:
            result = subprocess.run(
                [str(python_exe), "-c", "import pytest; import coverage"],
                timeout=10,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                logger.info("✅ pytest and coverage successfully available")
                return True
            else:
                logger.error(f"pytest/coverage import failed: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Failed to verify pytest/coverage: {e}")
            return False

    def run_coverage(self, test_file_path: str) -> Tuple[bool, Optional[Dict], List[str], str, str, int]:
        """
        Run coverage.py on a specific test file.
        
        Args:
            test_file_path: Path to test file (relative to repo root).
        
        Returns:
            Tuple of (success, coverage_data_dict, warnings_list, stderr_str, stdout_str, pytest_exit_code).
            pytest_exit_code: 0=tests passed, 1=tests failed, other=error
        """
        if not self.venv_path or not self.venv_path.exists():
            logger.error("venv not created yet")
            return False, None, [], "venv not created", "", -1

        python_exe = self.get_venv_python()

        # Detect framework
        detected_framework, framework = self.detect_test_framework()
        self.test_framework = (detected_framework, framework)

        # Build coverage command
        coverage_cmd = [
            str(python_exe),
            "-m",
            "coverage",
            "run",
            "--branch",
            "-m",
            framework,
            test_file_path,
        ]

        logger.info(f"🧪 Running coverage for {test_file_path} with framework={framework}")
        test_start = time.time()

        try:
            result = subprocess.run(
                coverage_cmd,
                timeout=TEST_TIMEOUT,
                capture_output=True,
                text=True,
                cwd=str(self.repo_path),
            )
            test_time = time.time() - test_start
            pytest_exit_code = result.returncode
            logger.info(f"✅ Test execution completed in {test_time:.2f}s (return code: {pytest_exit_code})")

            logger.debug(f"Test execution stdout: {result.stdout[:500]}")
            logger.debug(f"Test execution stderr: {result.stderr[:500]}")
            
            # Log if test execution failed
            if pytest_exit_code != 0:
                logger.warning(f"Test execution failed (return code {pytest_exit_code})")
                logger.warning(f"Test stderr: {result.stderr[:300]}")
                logger.debug(f"Test stdout (first 500 chars): {result.stdout[:500]}")

            # Parse coverage reports
            coverage_data = self._parse_coverage_json(python_exe)
            warnings = self._detect_warnings(result.stdout, result.stderr)

            # Return success based on coverage data availability
            # pytest_exit_code is returned separately so caller can distinguish
            # between "tests failed" and "coverage parsing failed"
            if coverage_data:
                return True, coverage_data, warnings, result.stderr, result.stdout, pytest_exit_code
            else:
                return False, None, warnings, result.stderr, result.stdout, pytest_exit_code

        except subprocess.TimeoutExpired:
            logger.error(f"Coverage execution timeout for {test_file_path}")
            return False, None, [WARN_PARTIAL_COVERAGE], "Test execution timeout", "", -2
        except Exception as e:
            logger.error(f"Coverage execution failed: {e}")
            return False, None, [], str(e), "", -3

    def _parse_coverage_json(self, python_exe: Path) -> Optional[Dict]:
        """
        Generate and parse coverage JSON report.
        
        Args:
            python_exe: Path to Python executable in venv.
        
        Returns:
            Dictionary with coverage metrics including line-level data for diff-coverage.
            The 'files' key contains per-file line-level coverage data.
        """
        try:
            # Generate JSON report
            result = subprocess.run(
                [str(python_exe), "-m", "coverage", "json"],
                timeout=30,
                capture_output=True,
                text=True,
                cwd=str(self.repo_path),
            )
            
            # If coverage json fails, check if .coverage even exists
            if result.returncode != 0:
                coverage_file = self.repo_path / ".coverage"
                if not coverage_file.exists():
                    logger.warning(f"No .coverage data file found - tests may have failed to run. stderr: {result.stderr}")
                else:
                    logger.warning(f"coverage json generation failed: {result.stderr}")
                return None

            # Read coverage.json
            json_file = self.repo_path / "coverage.json"

            if not json_file.exists():
                logger.warning("coverage.json not found after json generation")
                return None

            with open(json_file) as f:
                data = json.load(f)

            # Extract summary metrics (project-wide)
            summary = data.get("totals", {})
            metrics = {
                "line_coverage_percent": summary.get("percent_covered", 0),
                "branch_coverage_percent": summary.get("percent_covered_branch", 0) if INCLUDE_BRANCH_COVERAGE else 0,
                "lines_covered": summary.get("covered_lines", 0),
                "total_lines": summary.get("num_statements", 0),
                "branches_covered": summary.get("covered_branches", 0) if INCLUDE_BRANCH_COVERAGE else 0,
                "total_branches": summary.get("num_branches", 0) if INCLUDE_BRANCH_COVERAGE else 0,
            }

            # Extract line-level data for diff-coverage calculation
            # This is the key addition for RQ1
            files_data = data.get("files", {})
            metrics["files"] = {}
            
            for filepath, file_info in files_data.items():
                metrics["files"][filepath] = {
                    "executed_lines": file_info.get("executed_lines", []),
                    "missing_lines": file_info.get("missing_lines", []),
                    "excluded_lines": file_info.get("excluded_lines", []),
                }
            
            logger.info(f"Coverage metrics: {metrics.get('line_coverage_percent', 0):.1f}% line coverage, {len(metrics['files'])} files")
            return metrics

        except Exception as e:
            logger.warning(f"Failed to parse coverage.json: {e}")
            return None

    def _detect_warnings(self, stdout: str, stderr: str) -> List[str]:
        """
        Detect partial coverage scenarios from stderr and stdout.
        
        Args:
            stdout: Test execution stdout.
            stderr: Test execution stderr.
        
        Returns:
            List of warning strings.
        """
        warnings = []

        if "ImportError" in stderr or "ModuleNotFoundError" in stderr:
            warnings.append(WARN_IMPORT_ERRORS)

        if "SKIPPED" in stdout or "skipped" in stderr:
            warnings.append(WARN_SKIPPED_TESTS)

        if "0%" in stdout or "no tests" in stderr.lower():
            warnings.append(WARN_EMPTY)

        if not stdout or (not stderr and "covered" not in stdout.lower()):
            warnings.append(WARN_PARTIAL_COVERAGE)

        return warnings

    def cleanup_venv(self):
        """Clean up virtual environment."""
        if self.venv_path and self.venv_path.exists():
            import shutil

            try:
                shutil.rmtree(self.venv_path)
                logger.info(f"Cleaned up venv: {self.venv_path}")
            except Exception as e:
                logger.warning(f"Failed to cleanup venv: {e}")

    def __del__(self):
        """Cleanup on deletion."""
        self.cleanup_venv()

#!/usr/bin/env python3
"""
CLI entry point for coverage analyzer.
Supports parallel PR processing with Docker or local execution.
"""

import argparse
import csv
import logging
import os
import signal
import sys
import threading
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from coverage_analyzer.config import (
    CACHE_DIR,
    DEFAULT_WORKERS,
    DEFAULT_CLONE_SEMAPHORE,
    MIN_DISK_SPACE_GB,
    OUTPUT_CSV,
    PROGRESS_LOG,
    ERRORS_LOG,
    OUTPUT_DIR,
)
from coverage_analyzer.git_manager import GitRepositoryManager
from coverage_analyzer.pr_processor import PRCoverageAnalyzer

# Import from shared library
try:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from shared.github_api import GitHubAPIClient
    from shared.utils import is_test_file
except ImportError:
    GitHubAPIClient = None
    is_test_file = None

logger = logging.getLogger(__name__)


def setup_logging(log_file: Path = None):
    """Setup logging configuration."""
    handlers = [logging.StreamHandler()]
    if log_file:
        handlers.append(logging.FileHandler(log_file))

    logging.basicConfig(
        level=logging.DEBUG,  # Changed to DEBUG for more visibility
        format="[%(asctime)s.%(msecs)03d] %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        handlers=handlers,
    )


def load_input_csv(input_file: Path, all_prs: bool = False) -> list:
    """
    Load PRs from input CSV.
    
    Args:
        input_file: Path to CSV file.
        all_prs: If True, load all PRs. If False, only load PRs with status="success".
    
    Returns:
        List of PR dictionaries.
    """
    prs = []
    try:
        with open(input_file, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if all_prs or row.get("status") == "success":
                    prs.append(row)
        logger.info(f"Loaded {len(prs)} PRs from {input_file} (all_prs={all_prs})")
        return prs
    except Exception as e:
        logger.error(f"Failed to load input CSV: {e}")
        return []


def _build_test_file_commits(
    github_api,
    repo_owner: str,
    repo_name: str,
    pr_number: str,
) -> tuple:
    """
    Fetch PR files and build test_file_commits mapping.
    
    Args:
        github_api: GitHubAPIClient instance.
        repo_owner: Repository owner.
        repo_name: Repository name.
        pr_number: PR number.
    
    Returns:
        Tuple of (test_file_commits dict, pr_info dict).
        test_file_commits maps test_file_path -> [(seq_num, file_status, before_sha, after_sha), ...]
        pr_info contains pr_state and pr_merged from the GitHub API.
    """
    test_file_commits = {}
    pr_info = {"pr_state": "", "pr_merged": ""}
    
    if not github_api or not is_test_file:
        logger.warning("GitHub API or test file detection not available")
        return test_file_commits, pr_info
    
    try:
        # Fetch PR files using /pulls/{pr}/files endpoint
        # This endpoint returns all files modified in the PR with their status
        files = github_api.get_pr_files(repo_owner, repo_name, int(pr_number))
        if not files:
            logger.warning(f"Failed to fetch files for {repo_owner}/{repo_name}#{pr_number}")
            return test_file_commits, pr_info
        
        logger.info(f"Fetched {len(files)} files modified in PR #{pr_number}")
        
        # Get PR details to get base commit SHA, state and merged status
        pr_data = github_api.get_pr_details(repo_owner, repo_name, int(pr_number))
        base_sha = pr_data.get("base", {}).get("sha") if pr_data else None
        head_sha = pr_data.get("head", {}).get("sha") if pr_data else None
        
        # Extract PR state and merged status
        if pr_data:
            pr_info["pr_state"] = pr_data.get("state", "unknown")
            pr_info["pr_merged"] = str(pr_data.get("merged", False)).lower()
            logger.info(f"PR #{pr_number} state: {pr_info['pr_state']}, merged: {pr_info['pr_merged']}")
        
        if not base_sha or not head_sha:
            logger.warning(f"Could not get PR base/head SHAs for {repo_owner}/{repo_name}#{pr_number}")
            return test_file_commits, pr_info
        
        # Filter for test files and build mapping
        for file_obj in files:
            # Check if this is a test file
            if not is_test_file(file_obj.filename):
                continue
            
            # Found a test file
            test_file_path = file_obj.filename
            file_status = file_obj.status  # "added", "modified", "removed"
            
            # For "added" files: before_sha=None (didn't exist before)
            # For "modified"/"removed" files: before_sha is the base commit
            before_sha = None if file_status == "added" else base_sha
            after_sha = head_sha
            
            test_file_commits[test_file_path] = [(1, file_status, before_sha, after_sha)]
            logger.info(f"  ✅ {test_file_path} ({file_status})")
        
        logger.info(f"Found {len(test_file_commits)} test files in PR")
        
    except Exception as e:
        logger.error(f"Error building test file commits: {e}")
    
    return test_file_commits, pr_info


def process_pr_worker(
    pr: dict,
    input_csv_path: Path,
    output_dir: Path,
    use_docker: bool = False,
    output_csv: Path = None,
) -> dict:
    """
    Worker function to process a single PR.
    
    Args:
        pr: PR metadata dictionary.
        input_csv_path: Path to input CSV (for API client).
        output_dir: Output directory path.
        use_docker: Whether to use Docker for execution.
        output_csv: Path to output CSV file. Defaults to config OUTPUT_CSV.
    
    Returns:
        Dictionary with processing results.
    """
    pr_id = pr.get("pr_id", "")
    pr_number = pr.get("pr_number", "")
    # Support both naming conventions: repo_owner/owner and repo_name/repo
    repo_owner = pr.get("repo_owner", "") or pr.get("owner", "")
    repo_name = pr.get("repo_name", "") or pr.get("repo", "")

    result = {
        "pr_id": pr_id,
        "status": "unknown",
        "files_analyzed": 0,
        "successful_runs": 0,
        "error": None,
    }

    step_start = time.time()
    
    try:
        # Initialize components
        logger.info(f"[STEP 1] Initializing git manager for PR#{pr_number} ({repo_owner}/{repo_name})")
        git_manager = GitRepositoryManager()

        if GitHubAPIClient is None or is_test_file is None:
            result["error"] = "GitHubAPIClient or test file detection not available"
            result["status"] = "failed"
            return result

        # Get GitHub token from environment
        logger.info(f"[STEP 2] Checking GITHUB_TOKEN...")
        github_token = os.getenv("GITHUB_TOKEN")
        if not github_token:
            result["error"] = "GITHUB_TOKEN environment variable not set"
            result["status"] = "failed"
            return result
        logger.info(f"[STEP 2] ✅ GITHUB_TOKEN found")

        # Fetch PR commits and build test_file_commits mapping
        logger.info(f"[STEP 3] Creating GitHub API client...")
        github_api = GitHubAPIClient(token=github_token)
        
        logger.info(f"[STEP 4] Fetching test files from PR#{pr_number}...")
        fetch_start = time.time()
        test_file_commits, pr_info = _build_test_file_commits(
            github_api, repo_owner, repo_name, pr_number
        )
        fetch_time = time.time() - fetch_start
        logger.info(f"[STEP 4] ✅ Fetch completed in {fetch_time:.2f}s - {len(test_file_commits)} test files found")
        
        if not test_file_commits:
            logger.info(f"No test files found in PR #{pr_number}")
            result["status"] = "no_test_files"
            result["files_analyzed"] = 0
            return result

        # Add PR state info to PR dict for passing to analyzer
        pr["pr_state"] = pr_info.get("pr_state", "")
        pr["pr_merged"] = pr_info.get("pr_merged", "")

        # Initialize analyzer
        logger.info(f"[STEP 5] Initializing PR analyzer...")
        analyzer = PRCoverageAnalyzer(git_manager, github_api, dry_run=False, output_csv=output_csv)

        # Analyze PR
        logger.info(f"[STEP 6] Starting analysis for {len(test_file_commits)} test files...")
        analyze_start = time.time()
        success_count = analyzer.analyze_pr(pr, test_file_commits)
        analyze_time = time.time() - analyze_start
        logger.info(f"[STEP 6] ✅ Analysis completed in {analyze_time:.2f}s")

        result["status"] = "success" if success_count > 0 else "partial"
        result["successful_runs"] = success_count
        result["files_analyzed"] = len(test_file_commits)
        
        total_time = time.time() - step_start
        logger.info(f"[COMPLETE] PR#{pr_number} processed in {total_time:.2f}s ({result['status']}, {success_count} successful)")

    except Exception as e:
        elapsed = time.time() - step_start
        logger.error(f"[ERROR] Processing PR {pr_id} failed after {elapsed:.2f}s: {e}", exc_info=True)
        result["status"] = "failed"
        result["error"] = str(e)

    return result


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Test Coverage Analysis for Python PRs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process all PRs sequentially
  python -m coverage_analyzer.main --input human_prs_test_detection.csv

  # Process first 10 PRs with 2 workers
  python -m coverage_analyzer.main --input human_prs_test_detection.csv --limit 10 --workers 2

  # Use Docker for execution
  python -m coverage_analyzer.main --input human_prs_test_detection.csv --use-docker

  # Resume from checkpoint
  python -m coverage_analyzer.main --input human_prs_test_detection.csv --resume

  # Dry-run to see what would be processed
  python -m coverage_analyzer.main --input human_prs_test_detection.csv --dry-run --limit 5
        """,
    )

    parser.add_argument(
        "--input",
        type=Path,
        default=Path("human_prs_test_detection.csv"),
        help="Input CSV file with PRs (default: human_prs_test_detection.csv)",
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR,
        help="Output directory for results (default: coverage_analyzer/output)",
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Maximum number of PRs to process (default: all)",
    )

    parser.add_argument(
        "--workers",
        type=int,
        default=DEFAULT_WORKERS,
        help=f"Number of parallel workers (default: {DEFAULT_WORKERS})",
    )

    parser.add_argument(
        "--clone-timeout",
        type=int,
        default=300,
        help="Git clone timeout in seconds (default: 300)",
    )

    parser.add_argument(
        "--install-timeout",
        type=int,
        default=600,
        help="pip install timeout in seconds (default: 600)",
    )

    parser.add_argument(
        "--test-timeout",
        type=int,
        default=600,
        help="Test execution timeout in seconds (default: 600)",
    )

    parser.add_argument(
        "--cache-max-size",
        type=int,
        default=50,
        help="Maximum cache size in GB (default: 50)",
    )

    parser.add_argument(
        "--min-disk-space",
        type=int,
        default=10,
        help="Minimum required disk space in GB (default: 10)",
    )

    parser.add_argument(
        "--max-repo-size",
        type=int,
        default=5,
        help="Maximum repository size in GB (default: 5)",
    )

    parser.add_argument(
        "--use-docker",
        action="store_true",
        help="Use Docker for test execution (experimental)",
    )

    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume from last checkpoint",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be processed without writing outputs",
    )

    parser.add_argument(
        "--keep-coverage-data",
        action="store_true",
        help="Preserve raw coverage JSON files",
    )

    parser.add_argument(
        "--sampling-strategy",
        choices=["sequential", "random", "recent-first"],
        default="sequential",
        help="Strategy for selecting PRs when using --limit (default: sequential)",
    )

    parser.add_argument(
        "--all-prs",
        action="store_true",
        help="Process all PRs (including those without detected tests). If False, only process PRs with status=success",
    )

    args = parser.parse_args()

    # Setup logging
    setup_logging(ERRORS_LOG)
    logger.info(f"Starting coverage analyzer with args: {args}")

    # Validate input file
    if not args.input.exists():
        logger.error(f"Input file not found: {args.input}")
        sys.exit(1)

    # Create output directory
    args.output_dir.mkdir(parents=True, exist_ok=True)

    # Clean output CSV if not resuming
    output_csv_path = args.output_dir / OUTPUT_CSV.name
    if not args.resume and output_csv_path.exists():
        logger.info(f"🧹 Cleaning existing output CSV (resume=False): {output_csv_path}")
        output_csv_path.unlink()
        logger.info(f"✅ Removed: {output_csv_path}")

    # Load PRs
    prs = load_input_csv(args.input, all_prs=args.all_prs)
    if not prs:
        logger.error("No PRs to process")
        sys.exit(1)

    # Apply limit and sampling
    if args.limit:
        if args.limit <= 0:
            logger.error("--limit must be positive")
            sys.exit(1)
        prs = prs[: args.limit]

    logger.info(f"Processing {len(prs)} PRs with {args.workers} workers")

    # Dry-run mode
    if args.dry_run:
        logger.info("[DRY-RUN MODE]")
        for i, pr in enumerate(prs[:5], 1):
            logger.info(f"  [{i}] PR#{pr.get('pr_number', 'N/A')} - {pr.get('repo_owner', 'N/A')}/{pr.get('repo_name', 'N/A')}")
        if len(prs) > 5:
            logger.info(f"  ... and {len(prs) - 5} more PRs")
        sys.exit(0)

    # Process PRs
    start_time = time.time()
    total_successful = 0
    total_files = 0
    failed_prs = []

    try:
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            futures = {
                executor.submit(
                    process_pr_worker,
                    pr,
                    args.input,
                    args.output_dir,
                    args.use_docker,
                ): pr
                for pr in prs
            }

            with tqdm(total=len(prs), desc="Processing PRs") as pbar:
                for future in as_completed(futures):
                    pr = futures[future]
                    try:
                        result = future.result()
                        total_successful += result.get("successful_runs", 0)
                        total_files += result.get("files_analyzed", 0)

                        if result.get("status") == "failed":
                            failed_prs.append((pr.get("pr_id"), result.get("error")))

                        pbar.update(1)

                    except Exception as e:
                        logger.error(f"Worker exception for PR {pr.get('pr_id')}: {e}")
                        failed_prs.append((pr.get("pr_id"), str(e)))
                        pbar.update(1)

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        sys.exit(1)

    elapsed = time.time() - start_time

    # Summary
    logger.info("=" * 60)
    logger.info("SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Total PRs processed: {len(prs)}")
    logger.info(f"Total files analyzed: {total_files}")
    logger.info(f"Successful coverage runs: {total_successful}")
    logger.info(f"Failed PRs: {len(failed_prs)}")
    if failed_prs:
        logger.info("Failed PR details:")
        for pr_id, error in failed_prs[:5]:
            logger.info(f"  - PR {pr_id}: {error}")
        if len(failed_prs) > 5:
            logger.info(f"  ... and {len(failed_prs) - 5} more")
    logger.info(f"Total execution time: {elapsed:.2f}s ({elapsed / 60:.2f}m)")
    logger.info(f"Output written to: {args.output_dir}")
    logger.info("=" * 60)


if __name__ == "__main__":
    main()

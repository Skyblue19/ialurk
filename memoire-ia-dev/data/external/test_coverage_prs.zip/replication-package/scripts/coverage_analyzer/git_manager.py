"""
Git repository manager with caching, retry logic, and resource management.
"""

import json
import logging
import shutil
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Dict, Optional, Tuple

from coverage_analyzer.config import (
    CACHE_DIR,
    CACHE_METADATA_FILE,
    MAX_CACHE_SIZE_GB,
    MAX_REPO_SIZE_GB,
    MIN_DISK_SPACE_GB,
    REPOS_CACHE_DIR,
    RETRY_CLONE_ATTEMPTS,
    RETRY_DELAYS,
)

logger = logging.getLogger(__name__)

# Working directory for temporary repo copies (isolated per analysis)
WORKING_DIR = CACHE_DIR / "working"
WORKING_DIR.mkdir(parents=True, exist_ok=True)


class GitRepositoryManager:
    """Manages repository cloning, checkout, and cleanup with caching and retry logic."""

    def __init__(self, semaphore: Optional[threading.Semaphore] = None):
        """
        Initialize GitRepositoryManager.
        
        Args:
            semaphore: Threading semaphore to limit concurrent clones.
        """
        self.semaphore = semaphore or threading.Semaphore(8)
        self.cache_lock = threading.Lock()
        self.retry_count = 0
        self.working_copies = {}  # Track working copies for cleanup
        self._load_cache_metadata()

    def _load_cache_metadata(self):
        """Load cache metadata from disk."""
        self.cache_metadata = {}
        if CACHE_METADATA_FILE.exists():
            try:
                with open(CACHE_METADATA_FILE, "r") as f:
                    self.cache_metadata = json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load cache metadata: {e}")

    def _save_cache_metadata(self):
        """Save cache metadata to disk."""
        try:
            with open(CACHE_METADATA_FILE, "w") as f:
                json.dump(self.cache_metadata, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save cache metadata: {e}")

    def _check_disk_space(self) -> bool:
        """Check if sufficient disk space is available."""
        import shutil

        usage = shutil.disk_usage(str(REPOS_CACHE_DIR))
        available_gb = usage.free / (1024**3)
        if available_gb < MIN_DISK_SPACE_GB:
            logger.error(
                f"Insufficient disk space: {available_gb:.2f}GB available, "
                f"need {MIN_DISK_SPACE_GB}GB"
            )
            return False
        return True

    def _get_repo_size(self, repo_path: Path) -> int:
        """Get repository size in bytes."""
        try:
            result = subprocess.run(
                ["du", "-sb", str(repo_path)],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                return int(result.stdout.split()[0])
        except Exception as e:
            logger.warning(f"Failed to get repo size: {e}")
        return 0

    def _evict_oldest_repos(self):
        """
        Evict oldest repos if cache exceeds max size.
        
        IMPORTANT: This method assumes self.cache_lock is already held by the caller!
        Do not call this method without holding the cache_lock.
        """
        total_size = 0
        for repo_key, meta in self.cache_metadata.items():
            total_size += meta.get("size_bytes", 0)

        max_bytes = MAX_CACHE_SIZE_GB * (1024**3)
        if total_size > max_bytes:
            logger.debug(f"Cache size {total_size / (1024**3):.2f}GB exceeds max {MAX_CACHE_SIZE_GB}GB, evicting...")
            sorted_repos = sorted(
                self.cache_metadata.items(),
                key=lambda x: x[1].get("last_accessed", 0),
            )
            for repo_key, meta in sorted_repos:
                if total_size <= max_bytes * 0.9:
                    break
                repo_path = Path(meta["path"])
                try:
                    logger.info(f"🗑️  Evicting repo from cache: {repo_key}")
                    shutil.rmtree(repo_path)
                    del self.cache_metadata[repo_key]
                    total_size -= meta.get("size_bytes", 0)
                except Exception as e:
                    logger.warning(f"Failed to evict {repo_key}: {e}")
        self._save_cache_metadata()

    def clone_repository(self, owner: str, repo: str, retry_count: int = 0) -> Tuple[Optional[Path], int]:
        """
        Clone a repository with retry logic and caching.
        
        Args:
            owner: Repository owner (GitHub username).
            repo: Repository name.
            retry_count: Current retry attempt (internal).
        
        Returns:
            Tuple of (repo_path, retry_attempts) or (None, retry_attempts) if failed.
        """
        if not self._check_disk_space():
            return None, retry_count

        repo_key = f"{owner}/{repo}"
        repo_path = REPOS_CACHE_DIR / owner / repo

        # Check cache
        with self.cache_lock:
            # Try to use cached repo - check both metadata path and current repo_path location
            # (repo_path handles Docker mount changes where old paths in metadata become invalid)
            if repo_path.exists() and (repo_path / ".git").exists():
                # Directory exists and has .git - it's a valid cached repo
                if repo_key in self.cache_metadata:
                    self.cache_metadata[repo_key]["last_accessed"] = time.time()
                else:
                    # Update metadata with current path for future reference
                    size_bytes = self._get_repo_size(repo_path)
                    self.cache_metadata[repo_key] = {
                        "path": str(repo_path),
                        "size_bytes": size_bytes,
                        "last_accessed": time.time(),
                    }
                self._save_cache_metadata()
                logger.info(f"Using cached repo: {repo_key}")
                return repo_path, retry_count
            elif repo_key in self.cache_metadata:
                # Metadata exists but directory doesn't - clear stale metadata
                del self.cache_metadata[repo_key]
                self._save_cache_metadata()

        with self.semaphore:
            clone_url = f"https://github.com/{owner}/{repo}.git"

            logger.info(f"🔄 Cloning {clone_url} (no timeout)...")
            clone_start = time.time()
            
            try:
                # Perform full clone (not shallow) so all commits are available for checkout
                # No timeout - allow large repos to complete
                result = subprocess.run(
                    ["git", "clone", clone_url, str(repo_path)],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                clone_time = time.time() - clone_start
                logger.info(f"✅ Clone completed in {clone_time:.2f}s")

                # Measure repo size
                logger.info(f"📊 [SIZE] Measuring repository size...")
                size_start = time.time()
                size_bytes = self._get_repo_size(repo_path)
                size_time = time.time() - size_start
                size_gb = size_bytes / (1024**3)
                logger.info(f"📊 [SIZE] Size measurement completed in {size_time:.2f}s: {size_gb:.2f}GB")

                if size_gb > MAX_REPO_SIZE_GB:
                    logger.warning(
                        f"Repo {repo_key} exceeds max size: {size_gb:.2f}GB > {MAX_REPO_SIZE_GB}GB"
                    )
                    shutil.rmtree(repo_path)
                    return None, retry_count

                # Update cache metadata
                logger.info(f"🔐 [CACHE] Updating cache metadata...")
                with self.cache_lock:
                    self.cache_metadata[repo_key] = {
                        "path": str(repo_path),
                        "size_bytes": size_bytes,
                        "last_accessed": time.time(),
                    }
                    self._save_cache_metadata()
                    logger.info(f"🔐 [CACHE] Cache metadata saved")
                    logger.info(f"🧹 [CACHE] Evicting old repos if needed...")
                    self._evict_oldest_repos()
                    logger.info(f"🧹 [CACHE] Eviction complete")

                logger.info(f"✨ Successfully cloned {repo_key} ({size_gb:.2f}GB)")
                return repo_path, retry_count

            except subprocess.CalledProcessError as e:
                logger.error(f"Clone failed for {repo_key}: {e.stderr}")
                if retry_count < RETRY_CLONE_ATTEMPTS:
                    delay = RETRY_DELAYS[retry_count]
                    logger.info(f"Retrying clone in {delay}s...")
                    time.sleep(delay)
                    return self.clone_repository(owner, repo, retry_count + 1)
                return None, retry_count + 1

    def checkout_commit(self, repo_path: Path, sha: str) -> bool:
        """
        Checkout a specific commit SHA.
        
        Args:
            repo_path: Path to repository.
            sha: Commit SHA to checkout.
        
        Returns:
            True if successful, False otherwise.
        """
        try:
            # First, reset any local changes to avoid conflicts
            logger.debug(f"[CHECKOUT] Resetting local changes in {repo_path.name}...")
            subprocess.run(
                ["git", "-C", str(repo_path), "reset", "--hard", "HEAD"],
                timeout=30,
                capture_output=True,
                text=True,
                check=False,
            )
            subprocess.run(
                ["git", "-C", str(repo_path), "clean", "-fdx"],
                timeout=30,
                capture_output=True,
                text=True,
                check=False,
            )
            
            logger.info(f"🔄 [CHECKOUT] Fetching {sha[:8]} from origin...")
            fetch_start = time.time()
            # No timeout for fetch - allow large operations to complete
            subprocess.run(
                ["git", "-C", str(repo_path), "fetch", "origin", sha],
                capture_output=True,
                text=True,
                check=False,  # Don't fail if fetch doesn't find it
            )
            fetch_time = time.time() - fetch_start
            logger.info(f"✅ [CHECKOUT] Fetch completed in {fetch_time:.2f}s")
            
            logger.info(f"✔️  [CHECKOUT] Checking out {sha[:8]}...")
            checkout_start = time.time()
            subprocess.run(
                ["git", "-C", str(repo_path), "checkout", "-f", sha],
                timeout=30,
                capture_output=True,
                text=True,
                check=True,
            )
            checkout_time = time.time() - checkout_start
            logger.info(f"✅ [CHECKOUT] Checkout completed in {checkout_time:.2f}s")
            return True
        except subprocess.TimeoutExpired:
            logger.error(f"❌ [CHECKOUT] Timeout for {sha[:8]} in {repo_path.name}")
            return False
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ [CHECKOUT] Failed for {sha[:8]}: {e.stderr}")
            return False

    def create_working_copy(self, owner: str, repo: str, pr_id: str) -> Optional[Path]:
        """
        Create an isolated working copy of a repository for concurrent analysis.
        This avoids conflicts when multiple workers analyze different PRs from the same repo.
        
        Args:
            owner: Repository owner.
            repo: Repository name.
            pr_id: PR ID (used for unique working directory).
        
        Returns:
            Path to the working copy, or None if failed.
        """
        repo_key = f"{owner}/{repo}"
        cache_path = REPOS_CACHE_DIR / owner / repo
        
        # First, ensure we have the repo in cache
        if not cache_path.exists() or not (cache_path / ".git").exists():
            logger.info(f"Repository {repo_key} not in cache, cloning first...")
            cache_path, _ = self.clone_repository(owner, repo)
            if not cache_path:
                return None
        
        # Prune stale worktrees first to avoid accumulation
        logger.info(f"🧹 [WORKING] Pruning stale worktrees for {repo_key}...")
        try:
            subprocess.run(
                ["git", "-C", str(cache_path), "worktree", "prune"],
                timeout=60,
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception as e:
            logger.warning(f"⚠️  [WORKING] Worktree prune failed: {e}")
        
        # Fetch all branches and refs to ensure we have all commits
        logger.info(f"📥 [WORKING] Fetching latest refs for {repo_key}...")
        try:
            fetch_result = subprocess.run(
                ["git", "-C", str(cache_path), "fetch", "--all", "--prune"],
                timeout=300,
                capture_output=True,
                text=True,
                check=False,  # Don't fail if fetch has issues
            )
            if fetch_result.returncode == 0:
                logger.info(f"✅ [WORKING] Fetch completed successfully")
            else:
                logger.warning(f"⚠️  [WORKING] Fetch had issues: {fetch_result.stderr[:100]}")
        except Exception as e:
            logger.warning(f"⚠️  [WORKING] Fetch failed: {e}")
        
        # Create unique working directory for this PR
        work_id = f"{pr_id}_{uuid.uuid4().hex[:8]}"
        working_path = WORKING_DIR / owner / f"{repo}_{work_id}"
        
        try:
            # Use git worktree for efficient isolated working copies
            # This shares the object database but has independent working trees
            logger.info(f"📂 [WORKING] Creating working copy for PR {pr_id} using git worktree...")
            working_path.parent.mkdir(parents=True, exist_ok=True)
            
            clone_start = time.time()
            
            # First try with git worktree (more efficient)
            try:
                # Get the default branch or HEAD
                head_result = subprocess.run(
                    ["git", "-C", str(cache_path), "rev-parse", "HEAD"],
                    capture_output=True, text=True, timeout=30, check=True
                )
                head_sha = head_result.stdout.strip()
                
                # Add worktree at HEAD (detached)
                result = subprocess.run(
                    ["git", "-C", str(cache_path), "worktree", "add", "--detach", 
                     str(working_path), head_sha],
                    timeout=120,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                clone_time = time.time() - clone_start
                logger.info(f"✅ [WORKING] Worktree created in {clone_time:.2f}s: {working_path}")
                
                # Worktrees inherit the remote from the main repo
                # Make sure we can fetch from GitHub
                remote_url = f"https://github.com/{owner}/{repo}.git"
                subprocess.run(
                    ["git", "-C", str(working_path), "remote", "set-url", "origin", remote_url],
                    timeout=30,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                
            except subprocess.CalledProcessError as worktree_err:
                # Fallback to regular clone if worktree fails
                logger.warning(f"Worktree failed ({worktree_err.stderr.strip()}), falling back to clone...")
                if working_path.exists():
                    shutil.rmtree(working_path, ignore_errors=True)
                
                result = subprocess.run(
                    ["git", "clone", "--no-hardlinks", str(cache_path), str(working_path)],
                    timeout=600,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                clone_time = time.time() - clone_start
                logger.info(f"✅ [WORKING] Clone copy created in {clone_time:.2f}s: {working_path}")
                
                # Set the remote to point to GitHub for fetching specific commits
                remote_url = f"https://github.com/{owner}/{repo}.git"
                subprocess.run(
                    ["git", "-C", str(working_path), "remote", "set-url", "origin", remote_url],
                    timeout=30,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                logger.info(f"✅ [WORKING] Remote origin set to {remote_url}")
            
            # Track for cleanup
            self.working_copies[pr_id] = working_path
            
            return working_path
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ [WORKING] Failed to create working copy: {e.stderr}")
            # Cleanup partial copy
            if working_path.exists():
                shutil.rmtree(working_path, ignore_errors=True)
            return None
        except Exception as e:
            logger.error(f"❌ [WORKING] Exception creating working copy: {e}")
            if working_path.exists():
                shutil.rmtree(working_path, ignore_errors=True)
            return None

    def cleanup_working_copy(self, pr_id: str, cache_path: Optional[Path] = None):
        """
        Clean up a working copy after PR analysis is complete.
        
        Args:
            pr_id: PR ID whose working copy should be cleaned up.
            cache_path: Path to the cache repo (for worktree cleanup).
        """
        if pr_id in self.working_copies:
            working_path = self.working_copies[pr_id]
            try:
                # Try to remove as a worktree first
                if cache_path:
                    try:
                        subprocess.run(
                            ["git", "-C", str(cache_path), "worktree", "remove", 
                             "--force", str(working_path)],
                            timeout=60,
                            capture_output=True,
                            check=False,  # Don't fail if not a worktree
                        )
                        # Also prune stale worktrees to clean up orphaned entries
                        subprocess.run(
                            ["git", "-C", str(cache_path), "worktree", "prune"],
                            timeout=30,
                            capture_output=True,
                            check=False,
                        )
                    except Exception:
                        pass
                
                # Then remove the directory if it still exists
                if working_path.exists():
                    shutil.rmtree(working_path)
                    logger.info(f"🧹 [WORKING] Cleaned up working copy for PR {pr_id}")
                del self.working_copies[pr_id]
            except Exception as e:
                logger.warning(f"Failed to cleanup working copy for PR {pr_id}: {e}")

    def cleanup_checkout(self, repo_path: Path):
        """
        Clean up repository after checkout (remove artifacts and caches).
        
        Args:
            repo_path: Path to repository.
        """
        cleanup_dirs = [
            "__pycache__",
            ".pytest_cache",
            ".tox",
            ".coverage*",
            "htmlcov",
            ".venv_cov_*",
        ]
        
        try:
            # Run git clean
            subprocess.run(
                ["git", "-C", str(repo_path), "clean", "-fdx"],
                timeout=30,
                capture_output=True,
                check=False,
            )
        except Exception as e:
            logger.warning(f"git clean failed: {e}")

        # Remove Python caches
        import glob as glob_module

        for pattern in cleanup_dirs:
            for path in glob_module.glob(str(repo_path / "**" / pattern), recursive=True):
                try:
                    if Path(path).is_dir():
                        shutil.rmtree(path)
                    else:
                        Path(path).unlink()
                except Exception as e:
                    logger.debug(f"Failed to remove {path}: {e}")

        logger.debug(f"Cleaned up repository: {repo_path.name}")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup on exit."""
        pass

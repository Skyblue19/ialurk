"""
Diff coverage calculation module.

Calculates what percentage of changed lines in a PR are covered by tests.
This answers the RQ: "What is the test coverage of CODE CHANGES in PRs?"

Unlike project-wide coverage which measures total lines covered across the entire codebase,
diff-coverage only considers lines that were added or modified in the PR.
"""

import logging
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Any

logger = logging.getLogger(__name__)


@dataclass
class FileDiffCoverage:
    """Diff coverage metrics for a single file."""
    filename: str
    status: str  # added, modified, renamed
    changed_lines: Set[int] = field(default_factory=set)
    covered_lines: Set[int] = field(default_factory=set)
    uncovered_lines: Set[int] = field(default_factory=set)
    
    @property
    def num_changed(self) -> int:
        return len(self.changed_lines)
    
    @property
    def num_covered(self) -> int:
        return len(self.covered_lines)
    
    @property
    def num_uncovered(self) -> int:
        return len(self.uncovered_lines)
    
    @property
    def coverage_percent(self) -> float:
        if self.num_changed == 0:
            return 0.0
        return (self.num_covered / self.num_changed) * 100


@dataclass
class DiffCoverageResult:
    """Overall diff coverage result for a PR."""
    total_changed_lines: int = 0
    total_covered_lines: int = 0
    total_python_files: int = 0
    files_with_coverage: int = 0
    file_results: Dict[str, FileDiffCoverage] = field(default_factory=dict)
    
    @property
    def diff_coverage_percent(self) -> float:
        if self.total_changed_lines == 0:
            return 0.0
        return (self.total_covered_lines / self.total_changed_lines) * 100
    
    @property
    def uncovered_files_list(self) -> str:
        """Return list of files with 0% diff-coverage (changed lines not covered)."""
        uncovered_files = []
        for filename, file_cov in self.file_results.items():
            if file_cov.num_covered == 0 and file_cov.num_changed > 0:
                uncovered_files.append(filename)
        return "; ".join(uncovered_files)[:500]  # Limit total length
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for CSV output."""
        return {
            "diff_coverage_percent": round(self.diff_coverage_percent, 2),
            "diff_changed_lines": self.total_changed_lines,
            "diff_covered_lines": self.total_covered_lines,
            "diff_python_files": self.total_python_files,
            "diff_files_with_coverage": self.files_with_coverage,
            "diff_uncovered_files": self.uncovered_files_list,
        }


def parse_unified_diff_patch(patch: str) -> Set[int]:
    """
    Parse a unified diff patch to extract added/modified line numbers.
    
    GitHub API provides patches in unified diff format:
    @@ -old_start,old_count +new_start,new_count @@ optional context
    -deleted line
    +added line
     context line (unchanged)
    
    Args:
        patch: Unified diff patch string from GitHub API
    
    Returns:
        Set of line numbers that were added (in the new file)
    
    Example:
        >>> patch = '''@@ -10,5 +12,7 @@ def foo():
        ...  context
        ... -removed
        ... +added line 1
        ... +added line 2
        ...  context'''
        >>> parse_unified_diff_patch(patch)
        {13, 14}  # Lines 13 and 14 were added
    """
    added_lines: Set[int] = set()
    current_line = 0
    
    if not patch:
        return added_lines
    
    for line in patch.split('\n'):
        # Parse hunk header: @@ -old_start,old_count +new_start,new_count @@ [context]
        # Examples:
        #   @@ -10,5 +12,7 @@ def foo():
        #   @@ -0,0 +1,50 @@  (new file)
        #   @@ -1 +1,2 @@     (single line format)
        hunk_match = re.match(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@', line)
        if hunk_match:
            current_line = int(hunk_match.group(1))
            continue
        
        if current_line == 0:
            # Haven't seen a hunk header yet, skip
            continue
        
        if line.startswith('+') and not line.startswith('+++'):
            # This is an added line in the new file
            added_lines.add(current_line)
            current_line += 1
        elif line.startswith('-') and not line.startswith('---'):
            # Deleted line - exists only in old file, don't increment new file line
            pass
        elif line.startswith(' ') or line == '':
            # Context line (unchanged) or empty line
            current_line += 1
        # Note: Lines starting with '\' (like "\ No newline at end of file") are ignored
    
    return added_lines


def find_matching_coverage_file(
    coverage_files: Dict[str, Any],
    pr_filename: str,
    repo_path: str = ""
) -> Optional[str]:
    """
    Find the coverage file path that matches a PR filename.
    
    Coverage.py uses absolute paths, GitHub API uses relative paths.
    We need to match them.
    
    Args:
        coverage_files: Dict from coverage.json with absolute file paths as keys
        pr_filename: Relative file path from GitHub API (e.g., "src/module.py")
        repo_path: Repository root path (to help with matching)
    
    Returns:
        Matching coverage file path, or None if not found
    """
    # Normalize PR filename (remove leading ./ if present)
    pr_filename = pr_filename.lstrip('./')
    
    for cov_file in coverage_files:
        # Try exact suffix match (most common case)
        if cov_file.endswith('/' + pr_filename) or cov_file.endswith('\\' + pr_filename):
            return cov_file
        
        # Try matching full path
        if cov_file.endswith(pr_filename):
            return cov_file
        
        # Try matching just the basename (less reliable, but useful for simple repos)
        cov_basename = cov_file.split('/')[-1].split('\\')[-1]
        pr_basename = pr_filename.split('/')[-1].split('\\')[-1]
        if cov_basename == pr_basename and '/' not in pr_filename:
            return cov_file
    
    return None


def calculate_diff_coverage(
    coverage_data: Dict[str, Any],
    pr_files: List[Any],
    repo_path: str = ""
) -> DiffCoverageResult:
    """
    Calculate diff coverage for a PR by cross-referencing coverage data with changed lines.
    
    This is the core function that answers:
    "What percentage of the CHANGED lines in this PR are covered by tests?"
    
    Args:
        coverage_data: Coverage data dict with 'files' key containing line-level info.
                      Expected format from coverage.json:
                      {
                          "files": {
                              "/path/to/file.py": {
                                  "executed_lines": [1, 2, 3, ...],
                                  "missing_lines": [4, 5, ...],
                                  ...
                              }
                          }
                      }
        pr_files: List of files changed in the PR. Each should have:
                  - filename: str
                  - status: str (added, modified, removed, renamed)
                  - patch: str (unified diff)
        repo_path: Repository root path (for path matching)
    
    Returns:
        DiffCoverageResult with overall and per-file metrics
    """
    result = DiffCoverageResult()
    
    # Get coverage files dict
    coverage_files = coverage_data.get("files", {})
    
    if not coverage_files:
        logger.warning("No coverage file data available for diff-coverage calculation")
        return result
    
    for pr_file in pr_files:
        # Handle both dict and dataclass/object
        if hasattr(pr_file, 'filename'):
            filename = pr_file.filename
            status = pr_file.status
            patch = pr_file.patch or ""
        else:
            filename = pr_file.get("filename", "")
            status = pr_file.get("status", "")
            patch = pr_file.get("patch", "") or ""
        
        # Skip non-Python files
        if not filename.endswith('.py'):
            continue
        
        # Skip deleted files (no coverage to measure)
        if status == "removed":
            continue
        
        result.total_python_files += 1
        
        # Parse patch to get changed line numbers
        changed_lines = parse_unified_diff_patch(patch)
        
        if not changed_lines:
            logger.debug(f"No changed lines found in patch for {filename}")
            continue
        
        # Find matching file in coverage data
        matched_cov_file = find_matching_coverage_file(coverage_files, filename, repo_path)
        
        file_result = FileDiffCoverage(
            filename=filename,
            status=status,
            changed_lines=changed_lines,
        )
        
        if matched_cov_file:
            file_data = coverage_files[matched_cov_file]
            executed_lines = set(file_data.get("executed_lines", []))
            
            # Calculate intersection: which changed lines are covered?
            file_result.covered_lines = changed_lines & executed_lines
            file_result.uncovered_lines = changed_lines - executed_lines
            
            result.files_with_coverage += 1
            logger.debug(
                f"Diff coverage for {filename}: "
                f"{file_result.num_covered}/{file_result.num_changed} lines "
                f"({file_result.coverage_percent:.1f}%)"
            )
        else:
            # File not in coverage - all changed lines are uncovered
            file_result.uncovered_lines = changed_lines
            logger.debug(f"File {filename} not found in coverage data")
        
        result.file_results[filename] = file_result
        result.total_changed_lines += file_result.num_changed
        result.total_covered_lines += file_result.num_covered
    
    logger.info(
        f"Diff coverage calculated: {result.total_covered_lines}/{result.total_changed_lines} "
        f"lines ({result.diff_coverage_percent:.1f}%) across {result.total_python_files} Python files"
    )
    
    return result


def calculate_diff_coverage_from_patches(
    coverage_data: Dict[str, Any],
    file_patches: Dict[str, str],
    file_statuses: Dict[str, str] = None,
    repo_path: str = ""
) -> DiffCoverageResult:
    """
    Alternative interface: calculate diff coverage from a dict of filename -> patch.
    
    Useful when you already have patches parsed from the GitHub API.
    
    Args:
        coverage_data: Coverage data dict with line-level info
        file_patches: Dict mapping filename to unified diff patch
        file_statuses: Optional dict mapping filename to status (added, modified, etc.)
        repo_path: Repository root path
    
    Returns:
        DiffCoverageResult
    """
    # Convert to list format expected by calculate_diff_coverage
    pr_files = []
    for filename, patch in file_patches.items():
        status = (file_statuses or {}).get(filename, "modified")
        pr_files.append({
            "filename": filename,
            "status": status,
            "patch": patch,
        })
    
    return calculate_diff_coverage(coverage_data, pr_files, repo_path)

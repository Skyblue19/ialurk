"""
Failure diagnosis module - analyzes test output to determine root cause of failures.
Produces structured JSON with detailed failure analysis.
"""

import json
import re
from typing import Dict, List, Optional, Tuple


# Failure categories
CATEGORY_IMPORT_ERROR = "import_error"
CATEGORY_MISSING_DEPENDENCY = "missing_dependency"
CATEGORY_SYNTAX_ERROR = "syntax_error"
CATEGORY_ASSERTION_ERROR = "assertion_error"
CATEGORY_FIXTURE_ERROR = "fixture_error"
CATEGORY_COLLECTION_ERROR = "collection_error"
CATEGORY_TIMEOUT = "timeout"
CATEGORY_ENVIRONMENT_ERROR = "environment_error"
CATEGORY_CONFIGURATION_ERROR = "configuration_error"
CATEGORY_TEST_FAILURE = "test_failure"
CATEGORY_COVERAGE_PARSE_ERROR = "coverage_parse_error"
CATEGORY_NO_TESTS_COLLECTED = "no_tests_collected"
CATEGORY_PERMISSION_ERROR = "permission_error"
CATEGORY_FILE_NOT_FOUND = "file_not_found"
CATEGORY_MEMORY_ERROR = "memory_error"
CATEGORY_DATABASE_ERROR = "database_error"
CATEGORY_NETWORK_ERROR = "network_error"
CATEGORY_GIT_ERROR = "git_error"
CATEGORY_CHECKOUT_FAILED = "checkout_failed"
CATEGORY_UNKNOWN = "unknown"


# Pattern definitions for error detection
PATTERNS = {
    # Import errors - with specific module extraction
    CATEGORY_IMPORT_ERROR: [
        (r"ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]", "module"),
        (r"ImportError: cannot import name ['\"]([^'\"]+)['\"]", "name"),
        (r"ImportError: No module named ['\"]([^'\"]+)['\"]", "module"),
        (r"ImportError: DLL load failed", "dll"),
        (r"E\s+ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]", "module"),
        (r"E\s+ImportError: cannot import name ['\"]([^'\"]+)['\"]", "name"),
    ],
    
    # Missing dependencies - pip/package related
    CATEGORY_MISSING_DEPENDENCY: [
        (r"pkg_resources\.DistributionNotFound: The ['\"]([^'\"]+)['\"] distribution was not found", "package"),
        (r"No matching distribution found for ([^\s]+)", "package"),
        (r"Could not find a version that satisfies the requirement ([^\s]+)", "package"),
        (r"ERROR: Could not find a version that satisfies the requirement ([^\s]+)", "package"),
        (r"pip._vendor.packaging.requirements.InvalidRequirement", "invalid_requirement"),
        (r"ResolutionImpossible", "resolution_conflict"),
        (r"Failed to build ([^\s]+)", "build_failed"),
    ],
    
    # Syntax errors
    CATEGORY_SYNTAX_ERROR: [
        (r"SyntaxError: ([^\n]+)", "message"),
        (r"IndentationError: ([^\n]+)", "message"),
        (r"TabError: ([^\n]+)", "message"),
    ],
    
    # Assertion errors (actual test failures)
    CATEGORY_ASSERTION_ERROR: [
        (r"AssertionError: ([^\n]+)?", "message"),
        (r"assert\s+.+\s*==\s*.+", "comparison"),
        (r"E\s+AssertionError", "assertion"),
        (r"FAILED.*::.*- AssertionError", "failed_test"),
    ],
    
    # Fixture errors
    CATEGORY_FIXTURE_ERROR: [
        (r"fixture ['\"]([^'\"]+)['\"] not found", "fixture_name"),
        (r"E\s+fixture ['\"]([^'\"]+)['\"] not found", "fixture_name"),
        (r"ScopeMismatch", "scope_mismatch"),
        (r"FixtureLookupError", "lookup_error"),
    ],
    
    # Collection errors
    CATEGORY_COLLECTION_ERROR: [
        (r"collected 0 items", "no_items"),
        (r"no tests ran", "no_tests"),
        (r"ERROR collecting", "collection_error"),
        (r"import file mismatch", "file_mismatch"),
    ],
    
    # No tests collected (pytest exit code 5)
    CATEGORY_NO_TESTS_COLLECTED: [
        (r"no tests ran in", "no_tests"),
        (r"collected 0 items / 0 errors", "zero_collected"),
        (r"= no tests ran in", "no_tests"),
    ],
    
    # Environment errors
    CATEGORY_ENVIRONMENT_ERROR: [
        (r"CUDA.*not available", "cuda"),
        (r"GPU.*not available", "gpu"),
        (r"torch\.cuda\.is_available\(\) is False", "cuda"),
        (r"EnvironmentError", "environment"),
        (r"OSError: \[Errno \d+\]", "os_error"),
    ],
    
    # Configuration errors
    CATEGORY_CONFIGURATION_ERROR: [
        (r"pytest\.ini.*not found", "pytest_ini"),
        (r"conftest\.py.*error", "conftest"),
        (r"pyproject\.toml.*error", "pyproject"),
        (r"setup\.cfg.*error", "setup_cfg"),
        (r"InvalidConfigError", "invalid_config"),
    ],
    
    # Permission errors
    CATEGORY_PERMISSION_ERROR: [
        (r"PermissionError: \[Errno 13\]", "permission_denied"),
        (r"Permission denied", "permission_denied"),
        (r"Access is denied", "access_denied"),
    ],
    
    # File not found
    CATEGORY_FILE_NOT_FOUND: [
        (r"FileNotFoundError: \[Errno 2\].*['\"]([^'\"]+)['\"]", "file"),
        (r"No such file or directory: ['\"]([^'\"]+)['\"]", "file"),
    ],
    
    # Memory errors
    CATEGORY_MEMORY_ERROR: [
        (r"MemoryError", "oom"),
        (r"Cannot allocate memory", "allocation"),
        (r"Killed", "killed"),
        (r"std::bad_alloc", "bad_alloc"),
    ],
    
    # Database errors
    CATEGORY_DATABASE_ERROR: [
        (r"OperationalError.*database", "operational"),
        (r"sqlite3\.OperationalError", "sqlite"),
        (r"psycopg2\.OperationalError", "postgres"),
        (r"Connection refused.*\d+", "connection_refused"),
    ],
    
    # Network errors
    CATEGORY_NETWORK_ERROR: [
        (r"ConnectionError", "connection"),
        (r"requests\.exceptions\.", "requests"),
        (r"urllib\.error\.", "urllib"),
        (r"TimeoutError", "timeout"),
        (r"socket\.timeout", "socket_timeout"),
    ],
    
    # Timeout
    CATEGORY_TIMEOUT: [
        (r"Test execution timeout", "test_timeout"),
        (r"timed out", "timeout"),
        (r"TIMEOUT", "timeout"),
    ],
}


# Common missing packages and their pip names
COMMON_MISSING_PACKAGES = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "yaml": "PyYAML",
    "bs4": "beautifulsoup4",
    "dateutil": "python-dateutil",
    "dotenv": "python-dotenv",
    "jwt": "PyJWT",
    "psycopg2": "psycopg2-binary",
    "MySQLdb": "mysqlclient",
    "Crypto": "pycryptodome",
    "_pytest": "pytest",
    "setuptools_scm": "setuptools-scm",
}


def diagnose_failure(
    status: str,
    error_message: str,
    stdout: str = "",
    stderr: str = "",
    pytest_exit_code: int = -1,
    install_log_path: str = "",
) -> Dict:
    """
    Analyze test output and produce structured failure diagnosis.
    
    Args:
        status: Status code from the analysis
        error_message: Error message captured
        stdout: Full stdout from test run
        stderr: Full stderr from test run
        pytest_exit_code: Exit code from pytest (-1 if not available)
        install_log_path: Path to install log for additional context
    
    Returns:
        Dictionary with structured diagnosis:
        {
            "category": str,  # Primary failure category
            "subcategory": str,  # More specific classification
            "summary": str,  # Human-readable one-line summary
            "details": {
                "missing_modules": [...],  # List of missing imports
                "missing_packages": [...],  # List of missing pip packages  
                "failed_tests": [...],  # List of failed test names
                "error_type": str,  # Exception type if detected
                "suggestion": str,  # Suggested fix
            },
            "pytest_exit_code": int,
            "confidence": float,  # 0-1 confidence in diagnosis
        }
    """
    combined_output = f"{stdout}\n{stderr}\n{error_message}"
    
    diagnosis = {
        "category": CATEGORY_UNKNOWN,
        "subcategory": None,
        "summary": "Unknown failure",
        "details": {
            "missing_modules": [],
            "missing_packages": [],
            "failed_tests": [],
            "error_type": None,
            "suggestion": None,
        },
        "pytest_exit_code": pytest_exit_code,
        "confidence": 0.0,
    }
    
    # Special case: checkout/clone failures
    if status in ("checkout_failed", "clone_failed"):
        diagnosis["category"] = CATEGORY_CHECKOUT_FAILED
        diagnosis["subcategory"] = status
        diagnosis["summary"] = f"Git {status.replace('_', ' ')}: could not checkout commit"
        diagnosis["details"]["suggestion"] = "The commit SHA may not exist or the repository clone is incomplete"
        diagnosis["confidence"] = 0.95
        return diagnosis
    
    # Special case: install failed
    if status == "install_failed":
        # Check for specific install issues
        dep_issues = _check_dependency_issues(combined_output)
        if dep_issues:
            diagnosis["category"] = CATEGORY_MISSING_DEPENDENCY
            diagnosis["subcategory"] = dep_issues["type"]
            diagnosis["summary"] = dep_issues["summary"]
            diagnosis["details"]["missing_packages"] = dep_issues.get("packages", [])
            diagnosis["details"]["suggestion"] = dep_issues.get("suggestion")
            diagnosis["confidence"] = 0.85
            return diagnosis
        
        diagnosis["category"] = CATEGORY_MISSING_DEPENDENCY
        diagnosis["subcategory"] = "install_failed"
        diagnosis["summary"] = "Dependency installation failed"
        diagnosis["confidence"] = 0.7
        return diagnosis
    
    # Special case: pytest exit code 5 = no tests collected
    if pytest_exit_code == 5:
        diagnosis["category"] = CATEGORY_NO_TESTS_COLLECTED
        diagnosis["subcategory"] = "pytest_exit_5"
        diagnosis["summary"] = "No tests were collected by pytest"
        diagnosis["details"]["suggestion"] = "Check test file naming and pytest configuration"
        diagnosis["confidence"] = 0.95
        return diagnosis
    
    # Special case: pytest exit code 4 = usage error
    if pytest_exit_code == 4:
        diagnosis["category"] = CATEGORY_CONFIGURATION_ERROR
        diagnosis["subcategory"] = "pytest_usage_error"
        diagnosis["summary"] = "Pytest command usage error"
        diagnosis["confidence"] = 0.9
        return diagnosis
    
    # Check for import errors first (most common)
    missing_modules = _extract_missing_modules(combined_output)
    if missing_modules:
        diagnosis["category"] = CATEGORY_IMPORT_ERROR
        diagnosis["subcategory"] = "missing_import"
        diagnosis["details"]["missing_modules"] = missing_modules
        
        # Map to pip packages
        pip_packages = []
        for mod in missing_modules:
            base_mod = mod.split(".")[0]
            if base_mod in COMMON_MISSING_PACKAGES:
                pip_packages.append(COMMON_MISSING_PACKAGES[base_mod])
            else:
                pip_packages.append(base_mod)
        diagnosis["details"]["missing_packages"] = list(set(pip_packages))
        
        diagnosis["summary"] = f"Import error: missing {', '.join(missing_modules[:3])}"
        if len(missing_modules) > 3:
            diagnosis["summary"] += f" (+{len(missing_modules)-3} more)"
        
        diagnosis["details"]["suggestion"] = f"pip install {' '.join(pip_packages[:5])}"
        diagnosis["confidence"] = 0.9
        return diagnosis
    
    # Check for dependency resolution issues
    dep_issues = _check_dependency_issues(combined_output)
    if dep_issues:
        diagnosis["category"] = CATEGORY_MISSING_DEPENDENCY
        diagnosis["subcategory"] = dep_issues["type"]
        diagnosis["summary"] = dep_issues["summary"]
        diagnosis["details"]["missing_packages"] = dep_issues.get("packages", [])
        diagnosis["details"]["suggestion"] = dep_issues.get("suggestion")
        diagnosis["confidence"] = 0.85
        return diagnosis
    
    # Check for syntax errors
    syntax_match = re.search(r"(SyntaxError|IndentationError|TabError): ([^\n]+)", combined_output)
    if syntax_match:
        diagnosis["category"] = CATEGORY_SYNTAX_ERROR
        diagnosis["subcategory"] = syntax_match.group(1).lower()
        diagnosis["summary"] = f"{syntax_match.group(1)}: {syntax_match.group(2)[:50]}"
        diagnosis["details"]["error_type"] = syntax_match.group(1)
        diagnosis["confidence"] = 0.95
        return diagnosis
    
    # Check for fixture errors
    fixture_match = re.search(r"fixture ['\"]([^'\"]+)['\"] not found", combined_output, re.IGNORECASE)
    if fixture_match:
        diagnosis["category"] = CATEGORY_FIXTURE_ERROR
        diagnosis["subcategory"] = "missing_fixture"
        diagnosis["summary"] = f"Missing pytest fixture: {fixture_match.group(1)}"
        diagnosis["details"]["suggestion"] = "Check conftest.py and fixture definitions"
        diagnosis["confidence"] = 0.9
        return diagnosis
    
    # Check for collection errors
    if "collected 0 items" in combined_output or "no tests ran" in combined_output.lower():
        diagnosis["category"] = CATEGORY_NO_TESTS_COLLECTED
        diagnosis["subcategory"] = "zero_collected"
        diagnosis["summary"] = "No tests were collected"
        diagnosis["details"]["suggestion"] = "Check test file naming (test_*.py) and test function naming (test_*)"
        diagnosis["confidence"] = 0.85
        return diagnosis
    
    # Check for actual test failures (assertions)
    failed_tests = _extract_failed_tests(combined_output)
    if failed_tests:
        diagnosis["category"] = CATEGORY_TEST_FAILURE
        diagnosis["subcategory"] = "assertion_failure"
        diagnosis["details"]["failed_tests"] = failed_tests
        diagnosis["summary"] = f"Test failure: {len(failed_tests)} test(s) failed"
        if failed_tests:
            diagnosis["summary"] = f"Test failure: {failed_tests[0]}"
            if len(failed_tests) > 1:
                diagnosis["summary"] += f" (+{len(failed_tests)-1} more)"
        diagnosis["confidence"] = 0.85
        return diagnosis
    
    # Check for environment errors (CUDA, GPU, etc.)
    for pattern, subcat in [(r"CUDA.*not available", "cuda"), (r"GPU.*not available", "gpu")]:
        if re.search(pattern, combined_output, re.IGNORECASE):
            diagnosis["category"] = CATEGORY_ENVIRONMENT_ERROR
            diagnosis["subcategory"] = subcat
            diagnosis["summary"] = f"Environment requirement not met: {subcat.upper()}"
            diagnosis["details"]["suggestion"] = "Tests require GPU/CUDA which is not available"
            diagnosis["confidence"] = 0.9
            return diagnosis
    
    # Check for permission errors
    if re.search(r"PermissionError|Permission denied", combined_output, re.IGNORECASE):
        diagnosis["category"] = CATEGORY_PERMISSION_ERROR
        diagnosis["subcategory"] = "permission_denied"
        diagnosis["summary"] = "Permission denied error"
        diagnosis["confidence"] = 0.9
        return diagnosis
    
    # Check for memory errors
    if re.search(r"MemoryError|Cannot allocate memory|Killed|bad_alloc", combined_output, re.IGNORECASE):
        diagnosis["category"] = CATEGORY_MEMORY_ERROR
        diagnosis["subcategory"] = "out_of_memory"
        diagnosis["summary"] = "Out of memory error"
        diagnosis["confidence"] = 0.9
        return diagnosis
    
    # Check for database/network errors
    if re.search(r"Connection refused|ConnectionError|psycopg2|sqlite3.*Error", combined_output, re.IGNORECASE):
        diagnosis["category"] = CATEGORY_DATABASE_ERROR
        diagnosis["subcategory"] = "connection_error"
        diagnosis["summary"] = "Database connection error"
        diagnosis["details"]["suggestion"] = "Tests require a database that is not available"
        diagnosis["confidence"] = 0.8
        return diagnosis
    
    # Fallback: try to extract any exception type
    exception_match = re.search(r"(\w+Error|\w+Exception): ([^\n]+)", combined_output)
    if exception_match:
        diagnosis["category"] = CATEGORY_TEST_FAILURE
        diagnosis["subcategory"] = "exception"
        diagnosis["details"]["error_type"] = exception_match.group(1)
        diagnosis["summary"] = f"{exception_match.group(1)}: {exception_match.group(2)[:50]}"
        diagnosis["confidence"] = 0.6
        return diagnosis
    
    # Very low confidence fallback
    if pytest_exit_code == 1:
        diagnosis["category"] = CATEGORY_TEST_FAILURE
        diagnosis["subcategory"] = "unknown_test_failure"
        diagnosis["summary"] = "Tests failed (exit code 1)"
        diagnosis["confidence"] = 0.3
    elif pytest_exit_code == 2:
        diagnosis["category"] = CATEGORY_CONFIGURATION_ERROR
        diagnosis["subcategory"] = "interrupted"
        diagnosis["summary"] = "Test execution was interrupted"
        diagnosis["confidence"] = 0.5
    elif pytest_exit_code == 3:
        diagnosis["category"] = CATEGORY_CONFIGURATION_ERROR
        diagnosis["subcategory"] = "internal_error"
        diagnosis["summary"] = "Pytest internal error"
        diagnosis["confidence"] = 0.5
    
    return diagnosis


def _extract_missing_modules(text: str) -> List[str]:
    """Extract missing module names from error output."""
    modules = set()
    
    patterns = [
        r"ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]",
        r"ImportError: No module named ['\"]([^'\"]+)['\"]",
        r"ImportError: cannot import name ['\"]([^'\"]+)['\"]",
        r"E\s+ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]",
    ]
    
    for pattern in patterns:
        for match in re.finditer(pattern, text):
            modules.add(match.group(1))
    
    return sorted(list(modules))


def _extract_failed_tests(text: str) -> List[str]:
    """Extract names of failed tests from pytest output."""
    failed = []
    
    # FAILED tests/test_foo.py::test_bar - AssertionError
    for match in re.finditer(r"FAILED\s+([^\s]+::[^\s]+)", text):
        failed.append(match.group(1))
    
    # Short format: test_foo.py::test_bar FAILED
    for match in re.finditer(r"([^\s]+::[^\s]+)\s+FAILED", text):
        if match.group(1) not in failed:
            failed.append(match.group(1))
    
    return failed[:10]  # Limit to 10


def _check_dependency_issues(text: str) -> Optional[Dict]:
    """Check for pip/dependency related issues."""
    
    # Resolution impossible
    if "ResolutionImpossible" in text:
        return {
            "type": "resolution_conflict",
            "summary": "Dependency resolution conflict - incompatible package versions",
            "suggestion": "Check for conflicting version requirements in dependencies",
        }
    
    # Build failures
    build_match = re.search(r"Failed to build ([^\s,]+)", text)
    if build_match:
        pkg = build_match.group(1)
        return {
            "type": "build_failed",
            "summary": f"Failed to build package: {pkg}",
            "packages": [pkg],
            "suggestion": f"May need system dependencies to build {pkg}",
        }
    
    # Invalid requirement
    if "InvalidRequirement" in text:
        return {
            "type": "invalid_requirement",
            "summary": "Invalid requirement specification in dependencies",
            "suggestion": "Check requirements.txt or pyproject.toml for malformed entries",
        }
    
    # No matching distribution
    dist_match = re.search(r"No matching distribution found for ([^\s]+)", text)
    if dist_match:
        pkg = dist_match.group(1)
        return {
            "type": "no_distribution",
            "summary": f"Package not found: {pkg}",
            "packages": [pkg],
            "suggestion": f"Package '{pkg}' may not exist on PyPI or has wrong name",
        }
    
    return None


def diagnosis_to_json(diagnosis: Dict) -> str:
    """Convert diagnosis dict to JSON string for CSV storage."""
    return json.dumps(diagnosis, ensure_ascii=False, separators=(',', ':'))


def summarize_diagnosis(diagnosis: Dict) -> str:
    """Get a one-line summary of the diagnosis."""
    return diagnosis.get("summary", "Unknown failure")

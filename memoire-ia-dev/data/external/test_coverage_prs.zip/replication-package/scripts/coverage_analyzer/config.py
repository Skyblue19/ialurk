"""
Configuration module for coverage analyzer.
Stores coverage-specific settings: timeouts, cache directories, resource limits, etc.
"""

import os
from pathlib import Path


def _is_running_in_docker() -> bool:
    """Check if we're running inside a Docker container."""
    # Check for .dockerenv file (most reliable)
    if Path("/.dockerenv").exists():
        return True
    # Check cgroup for docker
    try:
        with open("/proc/1/cgroup", "r") as f:
            return "docker" in f.read()
    except (FileNotFoundError, PermissionError):
        pass
    return False


# Cache and data directories
# Use /cache if running in Docker, otherwise use /tmp/coverage_analyzer_cache (outside project dir)
if _is_running_in_docker() and Path("/cache").exists():
    # Running in Docker container
    CACHE_DIR = Path("/cache")
    REPOS_CACHE_DIR = CACHE_DIR / "repos"
    CACHE_METADATA_FILE = CACHE_DIR / "cache_metadata.json"
    PIP_CACHE_DIR = CACHE_DIR / "pip"
else:
    # Running locally - use /tmp to avoid polluting project directory with git repos
    CACHE_DIR = Path("/tmp/coverage_analyzer_cache")
    REPOS_CACHE_DIR = CACHE_DIR / "repos"
    CACHE_METADATA_FILE = CACHE_DIR / "cache_metadata.json"
    PIP_CACHE_DIR = CACHE_DIR / "pip"

# Timeouts (seconds)
CLONE_TIMEOUT = 600  # Increased to 10 min for large repos (crewAI ~25min needs time)
INSTALL_TIMEOUT = 600
TEST_TIMEOUT = 600

# Concurrency and resource limits
DEFAULT_WORKERS = 4
DEFAULT_CLONE_SEMAPHORE = 8  # 2x worker count
MAX_CACHE_SIZE_GB = 100
MIN_DISK_SPACE_GB = 20
MAX_REPO_SIZE_GB = 10

# Framework detection priority
FRAMEWORK_PRIORITY = ["pytest", "unittest", "nose", "hypothesis"]

# Retry configuration
RETRY_CLONE_ATTEMPTS = 3
RETRY_DELAYS = [5, 10, 20]  # exponential backoff in seconds

# Error and logging
ERROR_MESSAGE_MAX_LENGTH = 500

# Coverage settings
INCLUDE_BRANCH_COVERAGE = True
CHECKPOINT_INTERVAL = 10  # save checkpoint every N PRs

# Output paths
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_CSV = OUTPUT_DIR / "pr_coverage_analysis.csv"
ERRORS_LOG = OUTPUT_DIR / "errors.log"
PROGRESS_LOG = OUTPUT_DIR / "progress.log"
COVERAGE_DATA_DIR = OUTPUT_DIR / "coverage_data"
LOGS_DIR = OUTPUT_DIR / "logs"  # Directory for detailed pip install and freeze logs

# CSV columns - focused on diff-coverage (RQ: coverage of CODE CHANGES)
# Removed global coverage metrics (before/after_line_coverage, branch_coverage, etc.)
# as they don't answer the RQ about coverage of the changed code
CSV_COLUMNS = [
    # PR identification
    "pr_id",
    "pr_number",
    "repo_owner",
    "repo_name",
    "html_url",
    "agent",  # AI agent name (empty for human PRs)
    "authorship_type",  # ai_only, coauthor, or empty for human
    "pr_state",  # open, closed
    "pr_merged",  # true, false
    "test_file_path",
    "file_status",  # created, modified
    "before_commit_sha",
    "after_commit_sha",
    # Diff-coverage metrics (RQ: coverage of CODE CHANGES)
    "diff_coverage_percent",      # % of changed lines covered by tests
    "diff_changed_lines",         # Total lines added/modified in PR
    "diff_covered_lines",         # How many changed lines are covered
    "diff_python_files",          # Number of Python files changed in PR
    "diff_files_with_coverage",   # Files that have coverage data
    "diff_uncovered_files",       # List of files with 0% coverage
    # Environment info
    "python_version_detected",
    "python_version_used",
    "test_framework_detected",
    "test_framework_used",
    # Timing
    "execution_time_seconds",
    # Status and diagnostics
    "status",
    "warnings",
    "error_message",
    "failure_diagnosis",  # JSON with detailed failure analysis
    "timestamp",
]

# Status codes
STATUS_SUCCESS = "success"
STATUS_CLONE_FAILED = "clone_failed"
STATUS_CHECKOUT_FAILED = "checkout_failed"  # Failed to checkout specific commit
STATUS_INSTALL_FAILED = "install_failed"
STATUS_TEST_FAILED = "test_failed"
STATUS_TIMEOUT = "timeout"
STATUS_PARSE_FAILED = "parse_failed"
STATUS_COVERAGE_PARSE_FAILED = "coverage_parse_failed"  # Tests passed but coverage parsing failed
STATUS_TEST_FILE_NOT_FOUND = "test_file_not_found"  # Test file doesn't exist in commit
STATUS_DISK_SPACE_ERROR = "disk_space_error"
STATUS_PYTHON_VERSION_ERROR = "python_version_error"
STATUS_REPO_TOO_LARGE = "repo_too_large"

# Warning types
WARN_PARTIAL_COVERAGE = "partial_coverage"
WARN_IMPORT_ERRORS = "import_errors"
WARN_SKIPPED_TESTS = "skipped_tests"
WARN_EMPTY = "empty"

# Ensure directories exist
CACHE_DIR.mkdir(parents=True, exist_ok=True)
REPOS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
PIP_CACHE_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
COVERAGE_DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
